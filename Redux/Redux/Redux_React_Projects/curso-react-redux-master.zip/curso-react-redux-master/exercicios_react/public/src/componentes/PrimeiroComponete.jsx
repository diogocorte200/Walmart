import React from 'react'

function primeiro(){
    return <h1>Primeiro Componente!</h1>
}


export default primeiro