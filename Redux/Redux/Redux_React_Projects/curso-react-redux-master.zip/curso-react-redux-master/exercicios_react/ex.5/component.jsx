import React from 'react'

export default props => (
    <h1>{props.value}</h1>
)