const logger = require('./logger')
logger.info('Usando o padrão CommonJS!')