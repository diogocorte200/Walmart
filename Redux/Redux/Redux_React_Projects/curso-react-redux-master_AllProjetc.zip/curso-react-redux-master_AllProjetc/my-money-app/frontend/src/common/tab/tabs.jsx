import React from 'react'

export default props => (
    <div className='nav-tabs-custom'> 
        {props.children}
    </div> 
)