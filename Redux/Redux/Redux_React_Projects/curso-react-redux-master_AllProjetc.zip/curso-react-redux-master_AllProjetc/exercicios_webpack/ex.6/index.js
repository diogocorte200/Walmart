import Pessoa from './pessoa'

const pessoa = new Pessoa('Guilherme')
console.log(pessoa.toString())