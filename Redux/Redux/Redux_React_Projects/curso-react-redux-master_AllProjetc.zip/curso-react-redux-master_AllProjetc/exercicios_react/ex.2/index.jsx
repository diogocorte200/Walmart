import React from 'react'
import ReactDOM from 'react-dom'

import Component from './component.jsx'

ReactDOM.render(<Component />, document.getElementById('app'))