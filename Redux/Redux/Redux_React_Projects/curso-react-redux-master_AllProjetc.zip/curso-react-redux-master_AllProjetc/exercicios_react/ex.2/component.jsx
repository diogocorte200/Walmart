import React from 'react'

export default function() {
    return <h1>Primeiro Componente!</h1>
}