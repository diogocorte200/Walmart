﻿using AutomationServices.TesteService;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ZABIX
{
    public class ZabixClient
    {

        public void DoWork()
        {
            //var cliente = new List<Planilha>().ToList();
            //var listacliente = new List<Planilha>().ToList();
            //string arquivoXlSX = @"C:\zabix\planilha\AlertasZabbixWM.xlsx";

            //var datatable = ReadExcelHelper.Read(arquivoXlSX);
            //var novo = datatable;
            //foreach (System.Data.DataRow item in datatable.Rows)
            //{
            //    var obj = new Planilha()
            //    {

            //        Kb = !DBNull.Value.Equals(item["Kb"].ToString())
            //       ? (item["Kb"].ToString().Trim())
            //       : string.Empty,
            //        Email = !DBNull.Value.Equals(item["Email"].ToString())
            //        ? (item["Email"].ToString().Trim())
            //        : string.Empty,
            //        Erro = !DBNull.Value.Equals(item["Erro"].ToString())
            //       ? (item["Erro"].ToString().Trim())
            //       : string.Empty,

            //    };

            //    cliente.Add(obj);
            //}





            var directoryErro = @"C:\zabix\erro";
            var myListaPlan = ListarErro();
            var myListaArqui = ErroArquivo();

            string[] fileArray = System.IO.Directory.GetFiles(directoryErro, "*.txt");
            var teste = fileArray;
            foreach (var file in fileArray)
            {
                using (StreamReader sr = new StreamReader(file))
                {
                    string linha;
                    while ((linha = sr.ReadLine()) != null)
                    {
                        string[] dados = linha.Split('/');
                        List<Erro> listaErro = new List<Erro>();

                        var retorno = new Erro()
                        {
                            KbErro = !DBNull.Value.Equals(dados[0].ToString())
                           ? (dados[0].ToString().Trim())
                           : string.Empty,
                            IdLoja = !DBNull.Value.Equals(dados[1].ToString())
                           ? (dados[1].ToString().Trim())
                           : string.Empty,
                            Descricao = !DBNull.Value.Equals(dados[2].ToString())
                            ? (dados[2].ToString().Trim())
                            : string.Empty,
                        };

                        listaErro.Add(retorno);






                    }
                }
            }





        }


        public List<Erro> ErroArquivo()
        {
            var directoryErro = @"C:\zabix\erro";
            List<Erro> listaErro = new List<Erro>();

            string[] fileArray = System.IO.Directory.GetFiles(directoryErro, "*.txt");
            var teste = fileArray;
            foreach (var file in fileArray)
            {
                using (StreamReader sr = new StreamReader(file))
                {
                    string linha;
                    while ((linha = sr.ReadLine()) != null)
                    {
                        string[] dados = linha.Split('/');

                        var retorno = new Erro()
                        {
                            KbErro = !DBNull.Value.Equals(dados[0].ToString())
                           ? (dados[0].ToString().Trim())
                           : string.Empty,
                            IdLoja = !DBNull.Value.Equals(dados[1].ToString())
                           ? (dados[1].ToString().Trim())
                           : string.Empty,
                            Descricao = !DBNull.Value.Equals(dados[2].ToString())
                            ? (dados[2].ToString().Trim())
                            : string.Empty,
                        };

                        listaErro.Add(retorno);
                    }


                }
            }

            return listaErro;


        }
        public List<Planilha> ListarErro()
        {
            var cliente = new List<Planilha>().ToList();
            var listacliente = new List<Planilha>().ToList();
            var directoryErro = @"C:\zabix\erro";
            string arquivoXlSX = @"C:\zabix\planilha\AlertasZabbixWM.xlsx";

            var datatable = ReadExcelHelper.Read(arquivoXlSX);
            var novo = datatable;
            foreach (System.Data.DataRow item in datatable.Rows)
            {
                var obj = new Planilha()
                {

                    Kb = !DBNull.Value.Equals(item["Kb"].ToString())
                   ? (item["Kb"].ToString().Trim())
                   : string.Empty,
                    Email = !DBNull.Value.Equals(item["Email"].ToString())
                    ? (item["Email"].ToString().Trim())
                    : string.Empty,
                    Erro = !DBNull.Value.Equals(item["Erro"].ToString())
                   ? (item["Erro"].ToString().Trim())
                   : string.Empty,

                };

                cliente.Add(obj);
            }
            return cliente;
        }
    }
}
