﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.TesteService

{
    public static class ReadExcelHelper
    {
        private static string DataSource;

        public static DataTable Read(string filePath)
        {
            System.Data.DataTable dt = null;
            try
            {
                object rowIndex = 1;
                dt = new System.Data.DataTable();
                DataRow row;
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workBook = app.Workbooks.Open(filePath, 0, true, 5, "", "", true,
                    Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
                Microsoft.Office.Interop.Excel.Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.ActiveSheet;
                int temp = 1;
                while (((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, temp]).Value2 != null)
                {
                    dt.Columns.Add(Convert.ToString(((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, temp]).Value2));
                    temp++;
                }
                rowIndex = Convert.ToInt32(rowIndex) + 1;
                int columnCount = temp;
                temp = 1;
                while (((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, temp]).Value2 != null)
                {
                    row = dt.NewRow();
                    for (int i = 1; i < columnCount; i++)
                    {
                        row[i - 1] = Convert.ToString(((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, i]).Value2);
                    }
                    dt.Rows.Add(row);
                    rowIndex = Convert.ToInt32(rowIndex) + 1;
                    temp = 1;
                }
                app.Workbooks.Close();
            }
            catch (Exception exception)
            {
                throw exception;
            }

            return dt;
        }

        public static DataTable ReadExcel(string dataSource)
        {
            if (string.IsNullOrWhiteSpace(dataSource))
                //throw new Exception(Settings.NenhumRegistro);
                throw new  Exception(message:"Erro");
            var extension = Path.GetExtension(dataSource);
            if (extension != ".xls")
                throw new Exception("Arquivo inválido, por favor salve o mesmo com extensão .xls");

            DataSource = dataSource;
            var query = string.Format("select * from [{0}]", GetTableName);
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, CreateConnection.ConnectionString))
            {
                var dataSet = new DataSet();
                adapter.Fill(dataSet);
                return dataSet.Tables[0];
            }
        }

        #region Métodos Privados

        private static string GetTableName
        {
            get
            {
                try
                {
                    var _connection = new OleDbConnection(CreateConnection.ConnectionString);
                    _connection.Open();
                    var dataTable = _connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    string name = dataTable.Rows[0]["Table_Name"].ToString();

                    _connection.Dispose();
                    _connection.Close();

                    return name;
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Método de conexão com banco de dados
        /// </summary>
        private static OleDbConnection _connection;

        /// <summary>
        /// Método de conexão com banco de dados
        /// </summary>
        /// <returns>Retorna a string de conexão</returns>
        private static OleDbConnection CreateConnection
        {
            get
            {
                return new OleDbConnection(string.Format("Provider=Microsoft.Jet.Oledb.4.0; Data Source={0}; Extended Properties=Excel 8.0;", DataSource));
            }
        }

        /// <summary>
        /// Paramentros que serão enviados ao banco
        /// </summary>
        private static OleDbParameterCollection _parameterCollection = new OleDbCommand().Parameters;

        /// <summary>
        /// Criar comando que recebe o nome da procedure e os tipos
        /// </summary>
        /// <param name="commandType">Comandos</param>
        /// <param name="nomeProcedure">Nome da procedure</param>
        /// <returns>Retorna os comandos</returns>
        private static OleDbCommand CreateCommand(CommandType commandType, string procedure)
        {
            /* Criar conexão com banco de dados */
            _connection = CreateConnection;

            /* Abrir conexão */
            _connection.Open();

            /* Criar comando que vai enviar informações para o banco */
            OleDbCommand _command = _connection.CreateCommand();

            /* Adicionar as informações dentro do comando que vai enviar para o banco */
            _command.CommandType = commandType;

            /* Recebe o nome da procedure que esta sendo executada */
            _command.CommandText = procedure;

            /* Defini o tempo que a conexão ficará aberta (Em Segundos [7200] = 2 horas) */
            _command.CommandTimeout = 7200;

            /* Adicionar os paramentros no comando */
            foreach (OleDbParameter item in _parameterCollection)
            {
                /* Adicona o parametro e o valor */
                _command.Parameters.Add(new OleDbParameter(item.ParameterName, item.Value));
            }

            /* Executar o comando, manda o comando ate o banco com as informações */
            return _command;
        }

        /// <summary>
        /// Método que limpa os parametros
        /// </summary>
        private static void CleanParameter()
        {
            _parameterCollection.Clear();
        }

        /// <summary>
        /// Método adicona paramentros dentro da coleção de paramentro
        /// </summary>
        /// <param name="parametro">recebe os parametros passado na procedure</param>
        /// <param name="valor">valor passado na procedure</param>
        private static void AddParameter(string parameters, object value)
        {
            try
            {
                if (value == null)
                    _parameterCollection.AddWithValue(parameters, DBNull.Value);
                else
                    _parameterCollection.AddWithValue(parameters, value);
            }
            catch (System.Data.SqlClient.SqlException exception)
            {
                throw new Exception(message: exception.Number.ToString() + " - " + exception.Message.ToString() + " - " + exception.InnerException.ToString());
            }
            catch (Exception exception)
            {
                throw new Exception(exception.ToString());
            }
        }

        /// <summary>
        /// Método executa persistencia no banco de dados (Inserir, Atualiza e Excluir)
        /// Método executa a manipulação da procedure no banco
        /// Usado para insert, delete e update
        /// </summary>
        /// <param name="commandType">é um enum</param>
        /// <param name="nomeProcedure">recebe o nome da procedure</param>
        /// <returns>retorna um objeto</returns>
        private static object RunCommand(CommandType commandType, string query)
        {
            try
            {
                /* Recebe os paramentros en envia para o banco*/
                OleDbCommand _command = CreateCommand(commandType, query);

                var retorno = _command.ExecuteScalar();

                /* Finaliza Conexão com banco de Dados */
                _connection.Close();
                _connection.Dispose();

                /* Executar o comando, manda o comando ate o banco com as informações */
                return retorno;
            }
            catch (System.Data.SqlClient.SqlException exception)
            {
                throw new Exception(message: exception.Number.ToString() + " - " + exception.Message.ToString() + " - " + exception.InnerException.ToString());
            }
            catch (Exception exception)
            {
                throw new Exception(exception.ToString());
            }
        }

        /// <summary>
        /// Método consulta informações na base de dados
        /// </summary>
        /// <param name="commandType">é um enum</param>
        /// <param name="nomeProcedure">recebe o nome da procedure</param>
        /// <returns>retorna um objeto</returns>
        private static DataTable RunConsultation(CommandType commandType, string query)
        {
            try
            {
                /* Recebe os paramentros en envia para o banco*/
                OleDbCommand _command = CreateCommand(commandType, query);

                /* Criar um adptador */
                var sqlDataAdapter = new OleDbDataAdapter(_command);

                /* Criar datatable vasia aonde vou adicionar os valores que serão retornados do banco */
                var dataTable = new DataTable();

                /* Mandar comando ir ate o banco buscar os daods e o o adptador preencher a datatable */
                sqlDataAdapter.Fill(dataTable);

                /* Finaliza Conexão com banco de Dados */
                _connection.Close();
                _connection.Dispose();

                /* Retorna a tabela preenchida */
                return dataTable;
            }
            catch (System.Data.SqlClient.SqlException exception)
            {
                throw new Exception(message: exception.Number.ToString() + " - " + exception.Message.ToString() + " - " + exception.InnerException.ToString());
            }
            catch (Exception exception)
            {
                throw new Exception(exception.ToString());
            }
        }

        private static void Dispose()
        {
            CreateConnection.Close();
            CreateConnection.Dispose();
        }

        #endregion Métodos Publicos
    }
}
