﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.TesteService

{
    public class Email
    {
        public string server { get; set; }
        public string from { get; set; }
        public string to { get; set; }
        public string 
            cc { get; set; }
        public string bcc { get; set; }
        public string subject { get; set; }
        public string body { get; set; }

        public Email()
        {
            this.server = ConfigurationManager.AppSettings["EmailServer"];
            this.from = ConfigurationManager.AppSettings["EmailFrom"];
            this.bcc = ConfigurationManager.AppSettings["EmailBCC"];
        }

        public void Send(List<string> anexos = null)
        {
            if (!string.IsNullOrEmpty(this.to) && !string.IsNullOrEmpty(this.subject) && !string.IsNullOrEmpty(this.body))
            {
                SmtpClient client = new SmtpClient(this.server);
                MailMessage message = new MailMessage();
                message.From = new MailAddress(this.from);


                if (!string.IsNullOrEmpty(to))
                {
                    foreach (var email in to.Split(';').Where(e => !string.IsNullOrEmpty(e.Trim())).GroupBy(x => x.Trim()).Select(y => y.First()))
                    {
                        message.To.Add(email);
                    }
                }

                if (!string.IsNullOrEmpty(cc))
                {
                    foreach (var email in cc.Split(';').Where(e => !string.IsNullOrEmpty(e.Trim())).GroupBy(x => x.Trim()).Select(y => y.First()))
                    {
                        message.CC.Add(email);
                    }
                }

                //if (!string.IsNullOrEmpty(bcc))
                //{
                //    foreach (var email in bcc.Split(';').Where(e => !string.IsNullOrEmpty(e.Trim())).GroupBy(x => x.Trim()).Select(y => y.First()))
                //    {
                //        message.Bcc.Add(email);
                //    }
                //}


                if (anexos != null && anexos.Count > 0)
                {
                    foreach (var anexo in anexos)
                    {
                        message.Attachments.Add(new Attachment(@anexo));
                    }
                }


                message.Subject = this.subject;
                message.Body = this.body;
                message.IsBodyHtml = true;

                client.Send(message);
            }
        }

    }
}
