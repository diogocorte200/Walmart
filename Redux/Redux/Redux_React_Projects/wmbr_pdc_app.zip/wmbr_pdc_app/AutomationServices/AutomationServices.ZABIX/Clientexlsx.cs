﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ZABIX
{
    public class Clientexlsx
    {
        public string Codigo { get; set; }
        public string Descricao { get; set; }
        public void MoverDir(string dir)
        {
            var palavras = dir.Split('\\');
            var palavra = palavras[2];
            string destino = @"C:\arquivoxlsxdestino\" + palavra;
            System.IO.Directory.Move(dir, destino);
        }

    }
}
