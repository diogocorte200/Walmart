﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.TesteService
{
    public class Chamado
    {
        public string sys_id
        {
            get { return "ININ0098722";}
            set { sys_id = value; }
        }
        public string number
        {
            get { return "ININ0098722";}
            set { value = number; }

        }
        public string short_description {
            get { return "Teste Short Description";}
            set { value = short_description; }
        }
        public string description { get{return "Teste Descripton";}
            set { value = description; }
        }

        public string caller_id
        {
            get { return "19837373"; }
            set { value = caller_id; }
        }

        public string caller_id_user_name
        {
            get { return "Caller Id User Name"; }
            set { value = caller_id_user_name; }
        }

        public string caller_id_name { get; set; }
        public string caller_id_email
        {
            get { return "franciscodiogo11@gmail.com";}
            //get { return "26363733"; }
            set { caller_id_email = value; }
        }
        public string assignment_group
        {
            get { return "teste assignment_group"; }
            set { assignment_group = value; }
        }
        public string u_ci_class_name
        {
            get { return "teste u_ci_class_name"; }
            set { u_ci_class_name = value; }
        }
        public string u_serial_number
        {
            get { return "teste u_serial_number"; }
            set { u_serial_number = value; }
        }
        public string u_knowledge_id
        {
            get { return "teste u_knowledge_id"; }
            set { u_knowledge_id = value; }
        }
        public string work_notes
        {
            get { return "teste work_notes"; }
            set { work_notes = value; }
        }
        public string comments
        {
            get { return "teste comments"; }
            set { comments = value; }
        }

        private readonly string subject;
        public string assigned_to
        {
            get { return "teste assigned_to"; }
            set { assigned_to = value; }
        }
        public string state
        {
            get { return "teste state"; }
            set { state = value; }
        }
        public string priority
        {
            get { return "teste priority"; }
            set { priority = value; }
        }
        public string incident_state
        {
            get { return "teste incident_state"; }
            set { incident_state = value; }
        }
        public string resolved_by
        {
            get { return "teste resolved_by"; }
            set { resolved_by = value; }
        }
        public string resolved_at
        {
            get { return "teste resolved_at"; }
            set { resolved_at = value; }
        }
        public string comments_and_work_notes
        {
            get { return "teste comments_and_work_notes"; }
            set { comments_and_work_notes = value; }
        }
        public string reopened_time
        {
            get { return "teste reopened_time"; }
            set { reopened_time = value; }
        }
        public string u_department_id
        {
            get { return "teste reopened_time"; }
            set { reopened_time = value; }
        }
        public string erro
        {
            get { return "teste erro"; }
            set { erro = value; }
        }

    }
}
