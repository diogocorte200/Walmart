﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ZABIX
{
    public class Erro
    {
        public string KbErro { get; set; }
        public string IdLoja { get; set; }
        public string Descricao { get; set; }


        //public string MetodFucn()
        //{
        //    Clientexlsx cliente = new Clientexlsx();

        //    string arquivo = @"C:\arquivoxlsx";

        //    var data = new List<Clientexlsx>();

        //    string[] fileArray = System.IO.Directory.GetFiles(arquivo, "*.txt");

        //    var teste = fileArray;

        //    foreach (var file in fileArray)
        //    {
        //        var dataTable = ReadExcelHelper.Read(file);

        //        foreach (System.Data.DataRow item in dataTable.Rows)
        //        {

        //            var obj = new Clientexlsx
        //            {
        //                Codigo = !DBNull.Value.Equals(item["Codigo"].ToString())
        //                    ? (item["Codigo"].ToString().Trim())
        //                    : string.Empty,
        //                Descricao = !DBNull.Value.Equals(item["Descricao"].ToString())
        //                    ? (item["Descricao"].ToString().Trim())
        //                    : string.Empty,

        //            };

        //            data.Add(obj);

        //            //TODO

        //            cliente.MoverDir(file);
        //        }
        //    }
        //}
    }
}
