﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Data.OleDb;
using System.Runtime.CompilerServices;
using System.Security.Util;
using AutomationServices.Common;
using AutomationServices.ZABIX;

namespace AutomationServices.TesteService
{
    public class Program
    {
        #region Atributos
        public int[] hors;
        public int[] mins;
        public int hor_atual;
        public int min_atual;
        public int hor_executado;
        public int min_executado;
        public string ServiceName;
        private readonly string logfolder;
        private readonly string fila_automation;
        private readonly string artigo;
        private readonly string fila_15;
        private readonly string fValidaUSB;
        private readonly string erroGenerico;
        private readonly string anotacaoWorkNote;
        private readonly string resolucaoChamado;
        private readonly string fReiniciaPeriferico;
        private readonly string tzServiceNow;
        private readonly string tzLocal;
        private readonly string fConectividadePDV;
        private readonly string fInitBlidada;
        private readonly string fInitIBM;
        private readonly string pdvOffline;
        private readonly string subject;
        private readonly string perguntaPDV;
        private readonly string perguntaEmail;
        private readonly string semDestinatario;
        private readonly string pdvsNaoIdentificados;
        private readonly string userAssignedto;
        private readonly MenuAtendimento menuAtendimento;
        #endregion

        static void Main(string[] args)
        {
            var zabix = new ZabixClient();

            zabix.DoWork();

        }


        //var directoryErro = @"C:\zabix\erro";

        //var data = new List<Clientexlsx>();

        //string[] fileArray = System.IO.Directory.GetFiles(directoryErro, "*.txt");

        //var teste = fileArray;

        //    foreach (var file in fileArray)
        //    {
        //        using (StreamReader sr = new StreamReader(file))
        //        {
        //            string linha;
        //            while ((linha = sr.ReadLine()) != null)
        //            {
        //             Console.WriteLine(linha);
        //             var retorno = linha;
        //             Console.WriteLine(retorno);
        //             Console.ReadKey();
        //            }
        //        }


        //foreach (System.Data.DataRow item in dataTable.Rows)
        //{
        //    var retorno = item;

        //    Console.WriteLine(retorno);


        //    //var obj = new Clientexlsx
        //    //{
        //    //    Codigo = !DBNull.Value.Equals(item["Codigo"].ToString())
        //    //        ? (item["Codigo"].ToString().Trim())
        //    //        : string.Empty,
        //    //    Descricao = !DBNull.Value.Equals(item["Descricao"].ToString())
        //    //        ? (item["Descricao"].ToString().Trim())
        //    //        : string.Empty,

        //    //};

        //    //data.Add(obj);

        //    ////TODO

        //    //cliente.MoverDir(file);
        //}
    }





    //anterior funcionanado
    //     Clientexlsx cliente = new Clientexlsx();

    //string arquivo = @"C:\arquivoxlsx";

    //var data = new List<Clientexlsx>();

    //string[] fileArray = System.IO.Directory.GetFiles(arquivo,"*.txt");

    //var teste = fileArray;

    //    foreach (var file in fileArray)
    //    {
    //        var dataTable = ReadExcelHelper.Read(file);

    //        foreach (System.Data.DataRow item in dataTable.Rows)
    //        {

    //            var obj = new Clientexlsx
    //            {
    //                Codigo = !DBNull.Value.Equals(item["Codigo"].ToString())
    //                    ? (item["Codigo"].ToString().Trim())
    //                    : string.Empty,
    //                Descricao = !DBNull.Value.Equals(item["Descricao"].ToString())
    //                    ? (item["Descricao"].ToString().Trim())
    //                    : string.Empty,

    //            };

    //            data.Add(obj);

    //            //TODO

    //            cliente.MoverDir(file);
    //        }
    //    }




    //fuciona

    //Cliente cliente1 = new Cliente();

    //var model = new List<Cliente>();


    //foreach (var item in cliente1.MethodLerArquivo())
    //{
    //    var objeto = new Cliente
    //    {
    //        Nome = item.Nome,
    //        Endereco = item.Endereco,
    //        Teste = item.Teste,

    //    };
    //    model.Add(objeto);
    //}
    //Console.WriteLine(model);


    ////List<Cliente> listaData = new List<Cliente>().ToList();
    //var listaData = new List<Cliente>().ToList();
    //var retorno = cliente1.MethodLerArquivo();

    //cliente1.SendMail();
}




//public static MethodLerArquivo()
//{
//    var data = new List<Cliente>().ToList();


//    string arquivo = @"C:\arquivotxt\arquivo.xlsx";


//    var dataTable = ReadExcelHelper.Read(arquivo);

//    foreach (System.Data.DataRow item in dataTable.Rows)
//    {
//        var obj = new Cliente()
//        {
//            Nome = !DBNull.Value.Equals(item["Nome"].ToString())
//                ? (item["Nome"].ToString().Trim())
//                : string.Empty,
//            Endereco = !DBNull.Value.Equals(item["Endereco"].ToString())
//                ? (item["Endereco"].ToString().Trim())
//                : string.Empty,
//            Teste = !DBNull.Value.Equals(item["Teste"].ToString())
//                ? (item["Teste"].ToString().Trim())
//                : string.Empty,

//        };

//        data.Add(obj);
//        Console.WriteLine(obj.Nome, obj.Endereco, obj.Teste);
//        Console.ReadKey();
//    }

//}








