﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ZABIX
{
    public class Planilha
    {   public string Erro { get; set; }
        public string Kb { get; set; }
        public string Email { get; set; }



    }
}
