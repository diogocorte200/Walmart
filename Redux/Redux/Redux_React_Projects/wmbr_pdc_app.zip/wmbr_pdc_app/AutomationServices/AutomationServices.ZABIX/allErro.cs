﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.TesteService
{
    //class allErro
    //{

    //     string masculino = @"C:\arquivotxt\arquivo.xlsx";

    //        var data = new List<Cliente>();

    //        //string[] fileArray =
    //        //    System.IO.Directory.GetFiles((masculino)"*.xlsx");//? DiretorioArquivoMasculino : DiretorioArquivoFeminino,
    //        //        //"*.xlsx");
    //        string[] fileArray =
    //            System.IO.Directory.GetFiles(masculino); //? DiretorioArquivoMasculino : DiretorioArquivoFeminino,

    //        try
    //        {
    //            foreach (var file in fileArray)
    //            {
    //                var dataTable = ReadExcelHelper.Read(file);

    //                foreach (System.Data.DataRow item in dataTable.Rows)
    //                {
    //                    //var senha = CriptografiaSecurity.CreatePassword(5);
    //                    var obj = new Cliente()
    //                    {

    //                        //Nome = !DBNull.Value.Equals(item["Nome"].ToString())
    //                        //    ? System.Security.Util.ToTitleCase(item["Nome"].ToString().Trim())
    //                        //    : string.Empty,
    //                        //Endereco = !DBNull.Value.Equals(item["Endereço"].ToString())
    //                        //    ? System.Security.Util.ToTitleCase(item["Endereço"].ToString().Trim())
    //                        //    : string.Empty,
    //                        //Teste = !DBNull.Value.Equals(item["Teste"].ToString())
    //                        //    ? System.Security.Util.ToTitleCase(item["Teste"].ToString().Trim())
    //                        //    : string.Empty,
    //                        // = !DBNull.Value.Equals(item["Número"].ToString()) ? Util.ToTitleCase(item["Número"].ToString().Trim()) : string.Empty,
    //                        //Complemento = !DBNull.Value.Equals(item["Complemento"].ToString()) ? Util.ToTitleCase(item["Complemento"].ToString().Trim()) : string.Empty,
    //                        //Codigo = !DBNull.Value.Equals(item["CódigoN"].ToString()) ? Util.ToReplace(item["CódigoN"].ToString()) : string.Empty,
    //                        //Cidade = !DBNull.Value.Equals(item["Cidade"].ToString()) ? Util.ToTitleCase(item["Cidade"].ToString().Trim()) : string.Empty,
    //                        //Uf = !DBNull.Value.Equals(item["Estado"].ToString()) ? Util.ToUpper(item["Estado"].ToString().Trim()) : string.Empty,
    //                        //Cep = !DBNull.Value.Equals(item["Cep"].ToString()) ? item["Cep"].ToString().Trim() : string.Empty,
    //                        //SexoId = (int)((masculino) ? EnumSettings.Sexo.Masculino : EnumSettings.Sexo.Feminino),
    //                        //DataNascimento = !string.IsNullOrWhiteSpace(item["Nascimento"].ToString()) ? item["Nascimento"].ToString().Trim() : Util.DataHoraBrasilia.ToString(),
    //                        //Email = !DBNull.Value.Equals(item["Email"].ToString()) ? Util.ToLower(item["Email"].ToString().Trim()) : string.Empty,
    //                        //Telefone = !DBNull.Value.Equals(item["Telefone"].ToString()) ? item["Telefone"].ToString().Trim() : string.Empty,
    //                        //Celular = !DBNull.Value.Equals(item["Celular"].ToString()) ? item["Celular"].ToString().Trim() : string.Empty,
    //                        //Cpf = !DBNull.Value.Equals(item["C.P.F./C.N.P.J."].ToString()) ? item["C.P.F./C.N.P.J."].ToString().Trim() : string.Empty,
    //                        //Senha = senha,
    //                        //ConfirmarSenha = senha,
    //                        //AceitoReceberSms = true,
    //                        //AceitoReceberEmail = true,
    //                        //Pdv = true,
    //                        //AtualizadoPdv = true,
    //                        //MembroPaiId = LojaId,
    //                        //ResponsavelCadastroOuAlteracao = "FidelizarMais.WS.Process"
    //                    };

    //                    if (dataTable != null)
    //                    {
    //                        //var nome = obj.PrimeiroNome;
    //                        //obj.PrimeiroNome = Util.GetFirstName(nome);
    //                        //obj.Sobrenome = Util.GetLastName(nome);
    //                        //obj.Celular = string.Format("21{0}", (string.IsNullOrWhiteSpace(obj.Celular) && !string.IsNullOrWhiteSpace(obj.Telefone)) ? obj.Telefone : obj.Celular);
    //                        //obj.Telefone = string.Format("21{0}", obj.Telefone);
    //                        //obj.Email = !string.IsNullOrWhiteSpace(obj.Email) ? obj.Email : string.Format("{0}@{1}.com.br", Util.ToReplace(obj.Cpf), Util.ToReplace(obj.Cpf));
    //                        //obj.Cpf = Util.AddMascaraCpf(obj.Cpf);

    //                        data.Add(obj);
    //                    }
                        




    //                //private fucnio()
    //            //{

    //            //            //string arquivo = @"C:\arquivotxt\documento.txt";
    //            //            //using (StreamReader sr = new StreamReader(arquivo))
    //            //            //{


    //            //            //    var consulta = File.ReadAllLines(arquivo);

    //            //            //    var resu = JsonConvert.SerializeObject(consulta);


    //            //            //    var sss = resu;

    //            //            //    foreach (var v in sss)
    //            //            //    {
    //            //            //        var sssss = v;
    //            //            //    }
    //            //            //let clienteDados =
    //            //            //    linha.Split(',')
    //            //            //select new Cliente()
    //            //            //{

    //            //            //    Nome = clienteDados[0],
    //            //            //    Endereco = clienteDados[1],
    //            //            //    Teste = clienteDados[2],
    //            //            //};


    //            //            //foreach (var item in consulta)
    //            //            //{
    //            //            //    var lista = new Cliente
    //            //            //    {
    //            //            //        Nome = item.Nome,
    //            //            //        Endereco = item.Endereco,
    //            //            //        Teste = item.Teste
    //            //            //    }.Nome;

    //            //            //    Console.WriteLine(lista);
    //            //            //    Console.ReadKey();
    //            //            //}


    //            //            //string arquivo = @"C:\arquivotxt\documento.txt";
    //            //            //if (File.Exists(arquivo))
    //            //            //{
    //            //            //    try
    //            //            //    {
    //            //            //        using (StreamReader sr = new StreamReader(arquivo))
    //            //            //        {


    //            //            //            //string linha;
    //            //            //            //JoinsLine();


    //            //            //            //while ((linha = sr.ReadLine()) != null)
    //            //            //            //{
    //            //            //            //    JoinsLine();
    //            //            //            //    Console.WriteLine(linha);



    //            //            //            //}
    //            //            //        }
    //            //            //    }
    //            //            //    catch (Exception ex)
    //            //            //    {
    //            //            //        Console.WriteLine(ex.Message);
    //            //            //    }
    //            //            //}
    //            //            //else
    //            //            //{
    //            //            //    //var campos = arquivo.Split(":");
    //            //            //    //Console.WriteLine("Nome" + campos[0].Trim());
    //            //            //    //Console.WriteLine("Endereco" + campos[1].Trim());
    //            //            //    //Console.WriteLine("Teste" + campos[2].Trim());

    //            //            //    Console.WriteLine("O arquivo " + arquivo + "Não foi localidao!");
    //            //            //}
    //            //            //Console.ReadKey();

    //            //}

    //            //static  List<ClienteExcel> ObterDadosExcel(){

    //            //}


    //            //public static void JoinsLine()
    //            //{
    //            //    string arquivo = @"C:\arquivotxt\documento.txt";

    //            //    var consulta =
    //            //        from linha in
    //            //            File.ReadAllLines(arquivo)
    //            //        let clienteDados =
    //            //            linha.Split(',')
    //            //        select new Cliente()
    //            //        {

    //            //            Nome = clienteDados[0],
    //            //            Endereco = clienteDados[1],
    //            //            Teste = clienteDados[2],
    //            //        };


    //            //    foreach (var item in consulta)
    //            //    {
    //            //        var lista = new Cliente
    //            //        {
    //            //            Nome = item.Nome,
    //            //            Endereco = item.Endereco,
    //            //            Teste = item.Teste
    //            //        };

    //            //        Console.WriteLine(lista);
    //            //        Console.ReadKey();

    //            //        //Console.WriteLine(iteAdd(item.Nome +","+ item.Email + ","+ item.Cidade + ","+ 
    //            //        //                   item.Pais);


    //            //        //if (linha != null)
    //            //        //{
    //            //        //    String[] campos = linha.Split(":");
    //            //        //    Console.WriteLine("Nome" + campos[0].Trim());
    //            //        //    Console.WriteLine("Endereco" + campos[1].Trim());
    //            //        //    Console.WriteLine("Teste" + campos[2].Trim());


    //            //        //}
    //            //    }
    //            //}

    //            //class ClienteExcel
    //            //{
    //            //    public string Nome { get; set; }
    //            //    public string Endereco { get; set; }
    //            //    public string Teste { get; set; }
    //            //}
    //}

    








}


