﻿
TO INSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe "E:\SERVICES\AutomationServices\EODCore\AutomationServices.ARS.EODCore.exe"

TO UNINSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /u "E:\SERVICES\AutomationServices\EODCore\AutomationServices.ARS.EODCore.exe"


CHANGE FOLDERS TO FIT YOUR ENVIRONMENT

