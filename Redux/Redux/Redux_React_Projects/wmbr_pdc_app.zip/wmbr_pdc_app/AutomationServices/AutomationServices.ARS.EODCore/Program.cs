﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ARS.EODCore
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 

        static void Main()
        {
           
            if (IsDebug())
            {
                ServiceEODCore service = new ServiceEODCore(IsDebug());
                service.DoWork();
            }

            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new ServiceEODCore(IsDebug()) };
                ServiceBase.Run(ServicesToRun);
            }


        }

        public static bool IsDebug()
        {
            bool retorno = true;
#if (!DEBUG)
                retorno = false;
#endif
            return retorno;
        }
    }
}
