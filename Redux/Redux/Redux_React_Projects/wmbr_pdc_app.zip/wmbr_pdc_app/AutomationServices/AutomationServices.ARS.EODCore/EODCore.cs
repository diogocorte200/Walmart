﻿using System;
using System.IO;
using System.Linq;
using System.Configuration;
using AutomationServices.Common;
using System.Collections.Generic;
using System.Dynamic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Specialized;
using HtmlAgilityPack;


namespace AutomationServices.ARS.EODCore
{
    public class EODCore
    {
        #region Atributos
        public int[] hors;
        public int[] mins;
        public int hor_atual;
        public int min_atual;
        public int hor_executado;
        public int min_executado;
        public string ServiceName;
        private readonly string logfolder;
        private readonly string fila_automation;
        private readonly string artigo;
        private readonly string urlMenuAtendimento;
        private readonly string usuarioMenuAtendimento;
        private readonly string senhaMenuAtendimento;
        private readonly string fila_15;
        private readonly string fConsultaStatus;
        private readonly string fResetEODCore;
        private readonly string perguntaEmail;
        private readonly string InativoParaAtivo;
        private readonly string InativoParaInativo;
        private readonly string ativoParaAtivo;
        private readonly string nReativou;
        private readonly string semDestinatario;
        private readonly string redirecionamentoFila;
        private readonly string subjectOrientacao;
        private readonly string erroGenerico;
        private readonly List<string> anexosOrientacoes;
        private readonly MenuAtendimento menuAtendimento;
        #endregion

        public EODCore()
        {
            logfolder = AppDomain.CurrentDomain.BaseDirectory + "log\\";
            hors = string.IsNullOrEmpty(ConfigurationManager.AppSettings["EODCore_HorasExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["EODCore_MinutosExecucao"].Split(','), Convert.ToInt32);
            mins = string.IsNullOrEmpty(ConfigurationManager.AppSettings["EODCore_MinutosExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["EODCore_MinutosExecucao"].Split(','), Convert.ToInt32);
            fila_automation = ConfigurationManager.AppSettings["EODCore_Fila_Automation"];
            artigo = ConfigurationManager.AppSettings["EODCore_Artigo"];
            urlMenuAtendimento = ConfigurationManager.AppSettings["URLMenuAtendimento"];
            usuarioMenuAtendimento = ConfigurationManager.AppSettings["MenuAtendimentoUsuario"];
            senhaMenuAtendimento = ConfigurationManager.AppSettings["MenuAtendimentoSenha"];
            fila_15 = ConfigurationManager.AppSettings["EODCore_Fila_15"];
            fConsultaStatus = ConfigurationManager.AppSettings["FConsultaStatus"];
            fResetEODCore = ConfigurationManager.AppSettings["FResetEADCore"];
            InativoParaAtivo = string.Format(ConfigurationManager.AppSettings["InativoParaAtivo"], System.Environment.NewLine);
            InativoParaInativo = ConfigurationManager.AppSettings["InativoParaAtivo"];
            ativoParaAtivo = ConfigurationManager.AppSettings["AtivoParaAtivo"];
            nReativou = ConfigurationManager.AppSettings["NaoReativou"];
            subjectOrientacao = ConfigurationManager.AppSettings["SubjectOrientacao"];
            perguntaEmail = ConfigurationManager.AppSettings["EODCore_Pergunta_Email"];
            semDestinatario = ConfigurationManager.AppSettings["Semdestinatario"];
            erroGenerico = ConfigurationManager.AppSettings["ErroGenerico"];

            redirecionamentoFila = string.Format(ConfigurationManager.AppSettings["RedirecionamentoFila"], System.Environment.NewLine);
            anexosOrientacoes = new List<string>()
            {
                (string.Format(ConfigurationManager.AppSettings["PDFAcessoWebMaster"],AppDomain.CurrentDomain.BaseDirectory)),
                (string.Format(ConfigurationManager.AppSettings["PDFInstrucaoAcesso"],AppDomain.CurrentDomain.BaseDirectory))

            };
            menuAtendimento = new MenuAtendimento()
            {
                UrlMenuAtendimento = ConfigurationManager.AppSettings["URLMenuAtendimento"],
                UsuarioMenuAtendimento = ConfigurationManager.AppSettings["MenuAtendimentoUsuario"],
                SenhaMenuAtendimento = ConfigurationManager.AppSettings["MenuAtendimentoSenha"],
            };
            hor_executado = -1;
            min_executado = -1;
        }
        public void DoWork()
        {
            if ((this.hors.Contains(this.hor_atual) && !this.hor_atual.Equals(this.hor_executado)) || (this.mins.Contains(this.min_atual) && !this.min_atual.Equals(this.min_executado)))
            {
                this.hor_executado = this.hor_atual;
                this.min_executado = this.min_atual;

                List<Chamado> chamados = ServiceNow.RecuperaChamadosAbertos(this.fila_automation, this.artigo);

                if (chamados.Count > 0)
                {
                    foreach (Chamado chamado in chamados)
                    {
                        if (!string.IsNullOrEmpty(chamado.reopened_time))
                        {
                            chamado.assignment_group = this.fila_15;
                            chamado.work_notes = this.redirecionamentoFila;
                            chamado.comments = this.redirecionamentoFila;
                            ServiceNow.AtualizaChamado(chamado);
                        }
                        else
                            Processa(chamado);
                    }
                }
                else
                {
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "NENHUM INCIDENTE ENCONTRADO", true);
                }
            }

        }

        private void Processa(Chamado chamado)
        {
            try
            {
                //Obtendo os dados para o processamento
                var body = BodyOfEmailEODCore();
                var email = new Email();
                var destinatarios = ObterDestinatarios(chamado);
                var loja = new string(chamado.u_department_id.Where(char.IsDigit).ToArray());


                //Se não houver destinatario para o envio do email, direcionamos o chamado para a fila do 1.5
                if (string.IsNullOrEmpty(destinatarios))
                {
                    chamado.comments = this.semDestinatario;
                    chamado.work_notes = this.semDestinatario;
                    chamado.assignment_group = this.fila_15;
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, this.semDestinatario.Replace(System.Environment.NewLine, " "), true));
                }
                else
                {
                    //Realizamos a consulta do status antes da reinialização do servico.
                    var parameters = ObterParametros(loja, this.fConsultaStatus);
                    var servicoInicialmente = ObterStatusServicos(parameters);

                    //Reiniciamos o servico.
                    RestartServico(servicoInicialmente, loja);

                    //Consulta para ver status do servico após restart
                    var servicoAposRestart = ObterStatusServicos(parameters);

                    //Se o serviço esta inativo e ficou ativo, resolvemos o chamado
                    if (!servicoInicialmente.EODCore && servicoAposRestart.EODCore)
                    {
                        chamado.comments = string.Format(this.InativoParaAtivo, System.Environment.NewLine);
                        chamado.work_notes = string.Format(this.InativoParaAtivo, System.Environment.NewLine);
                        chamado.state = "6";
                        chamado.incident_state = "6";
                        chamado.resolved_at = DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");
                        email.subject = string.Format(this.subjectOrientacao, chamado.number);
                        email.to = destinatarios;
                        email.body = body;
                        email.Send(anexosOrientacoes);
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - RESOLVIDO", chamado.number), true);
                        Util.GravarLog(chamado, email, this.logfolder);
                    }

                    //Se o servico estava inativo e não conseguimos ativa-lo, direcionamos para a fila do 1.5.
                    else if (!servicoInicialmente.EODCore && !servicoAposRestart.EODCore)
                    {
                        chamado.comments = this.InativoParaInativo;
                        chamado.work_notes = this.InativoParaInativo;
                        chamado.assignment_group = this.fila_15;
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, this.InativoParaInativo.Replace(System.Environment.NewLine, " "), true));
                    }
                    
                    //Se estava ativo e permaneceu ativo, resolvemos o chamado.
                    else if (servicoInicialmente.EODCore && servicoAposRestart.EODCore)
                    {
                        chamado.comments = string.Format(this.ativoParaAtivo, System.Environment.NewLine);
                        chamado.work_notes = string.Format(this.ativoParaAtivo, System.Environment.NewLine);
                        chamado.state = "6";
                        chamado.incident_state = "6";
                        chamado.resolved_at = DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");
                        email.subject = string.Format(this.subjectOrientacao, chamado.number);
                        email.to = destinatarios;
                        email.body = body;
                        email.Send(anexosOrientacoes);
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - RESOLVIDO", chamado.number), true);
                        Util.GravarLog(chamado, email, this.logfolder);

                    }
                    
                    //Caso estava ativo e após o restart ficou inativo, direcionamos para a fila do 1.5.
                    else
                    {
                        chamado.comments = this.nReativou;
                        chamado.work_notes = this.nReativou;
                        chamado.assignment_group = this.fila_15;
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, this.nReativou.Replace(System.Environment.NewLine, " "), true));
                    }

                }

                ServiceNow.AtualizaChamado(chamado);
            }

            //Se ocorrer algum erro no processamento, logamos um erro generico e direcionamos para a fia do 1.5.
            catch (Exception e)
            {

                chamado.comments = this.erroGenerico;
                chamado.work_notes = this.erroGenerico;
                chamado.assignment_group = this.fila_15;
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, e.Message.Replace(System.Environment.NewLine, " "), true));
                ServiceNow.AtualizaChamado(chamado);
            }

        }

        #region Métodos Auxiliares
        private Servico ObterStatusServicos(NameValueCollection parameters)
        {
            var html = Request.ExecutarMenuAtendimento(menuAtendimento, parameters);
            return ServicosAtivos(html);
        }
        private NameValueCollection ObterParametros(string loja, string funcao)
        {
            var parameters = new NameValueCollection();
            parameters.Add("store", loja.ToLower().Trim());
            parameters.Add("pos", "0");
            parameters.Add("id", funcao.ToLower().Trim());
            parameters.Add("data", "0");
            parameters.Add("transacao", "0");

            return parameters;
        }
        private Servico ServicosAtivos(string html)
        {
            try
            {
                var doc = new HtmlDocument();
                doc.LoadHtml(html);
                var info = doc.DocumentNode.SelectSingleNode("//table//table/tr[2]/td").InnerHtml.Replace("<br>", "*").Split('*');
                if (info.Count() >= 10)
                    return new Servico()
                    {
                        PosServer = !info[4].Contains("no está activo"),
                        LU_LOOP = !info[5].Contains("no está activo"),
                        IMP_LOOP = !info[6].Contains("no está activo"),
                        FDS = !info[7].Contains("no está activo"),
                        ItemMaintenance = !info[8].Contains("no está activo"),
                        IDCReader = !info[9].Contains("no está activo"),
                        EODCore = !info[10].Contains("no está activo"),
                        Postgres = !info[11].Contains("no está activo")
                    };
                else
                    return new Servico();

            }
            catch (Exception)
            {

                throw;
            }



        }
        private void RestartServico(Servico servico, string loja)
        {
            var html = Request.ExecutarMenuAtendimento(menuAtendimento, ObterParametros(loja, this.fResetEODCore));

        }
        private string BodyOfEmailEODCore()
        {
            var response = "";
            try
            {
                response = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + @"Email\\Template.html");

            }
            catch (Exception)
            {

                throw;
            }

            return response.Replace("{0}", Util.Saudacao());
        }
        private string ObterDestinatarios(Chamado chamado)
        {
            var solicitante = chamado.caller_id_email;
            var destinatarios = Util.RecuperarValorEntre(chamado.description, this.perguntaEmail, System.Environment.NewLine).Trim();
            return destinatarios += ";" + solicitante;
        }
        #endregion

    }

    public class Servico
    {
        public bool PosServer { get; set; }
        public bool LU_LOOP { get; set; }
        public bool IMP_LOOP { get; set; }
        public bool FDS { get; set; }
        public bool ItemMaintenance { get; set; }
        public bool IDCReader { get; set; }
        public bool EODCore { get; set; }
        public bool Postgres { get; set; }
    }



}
