﻿using AutomationServices.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationServices.ARS.EODCore
{
    public partial class ServiceEODCore : ServiceBase
    {
        private Thread Worker;
        private ManualResetEvent StopRequest = new ManualResetEvent(false);
        private volatile bool _shouldStop;
        public bool IsDebug;
        private readonly int _timeSleep;
        EODCore wEODCore = new EODCore();
        public ServiceEODCore(bool _IsDebug)
        {
            _timeSleep = Convert.ToInt32(ConfigurationManager.AppSettings["TimeSleep"]);
            this.IsDebug = _IsDebug;
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (!IsDebug)
            {
                Log.Event(this.ServiceName, "Serviço iniciado", false);
                Worker = new Thread(DoWork);
                Worker.Name = this.ServiceName;
                Worker.IsBackground = true;
                Worker.Start();
            }
        }

        protected override void OnStop()
        {
            _shouldStop = true;
        }
        public void DoWork()
        {
            while (!_shouldStop)
            {
                int hor_atual = DateTime.Now.Hour;
                int min_atual = DateTime.Now.Minute;

                wEODCore.hor_atual = hor_atual;
                wEODCore.min_atual = min_atual;
                wEODCore.ServiceName = this.ServiceName;

                if (IsDebug)
                    wEODCore.DoWork();
                else
                {
                    Thread wrkEODCore = new Thread(wEODCore.DoWork);
                    wrkEODCore.Start();
                    Thread.Sleep(_timeSleep);
                    wrkEODCore.Join();
                }
            }


            if (!IsDebug)
            {
                Worker.Join();
                Log.Event(this.ServiceName, "Serviço finalizado", false);
                StopRequest.Set();
            }
        }
    }
}
