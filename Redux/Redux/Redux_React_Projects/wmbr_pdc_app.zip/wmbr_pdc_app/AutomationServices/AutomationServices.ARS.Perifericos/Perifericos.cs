﻿using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using AutomationServices.Common;
using System.Collections.Specialized;
using HtmlAgilityPack;
using System.Globalization;
namespace AutomationServices.ARS.Perifericos
{
    public class Perifericos
    {
        #region Atributos
        public int[] hors;
        public int[] mins;
        public int hor_atual;
        public int min_atual;
        public int hor_executado;
        public int min_executado;
        public string ServiceName;
        private readonly string logfolder;
        private readonly string fila_automation;
        private readonly string artigo;
        private readonly string fila_15;
        private readonly string fValidaUSB;
        private readonly string erroGenerico;
        private readonly string anotacaoWorkNote;
        private readonly string resolucaoChamado;
        private readonly string fReiniciaPeriferico;
        private readonly string tzServiceNow;
        private readonly string tzLocal;
        private readonly string fConectividadePDV;
        private readonly string fInitBlidada;
        private readonly string fInitIBM;
        private readonly string pdvOffline;
        private readonly string subject;
        private readonly string perguntaPDV;
        private readonly string perguntaEmail;
        private readonly string semDestinatario;
        private readonly string pdvsNaoIdentificados;
        private readonly string userAssignedto;
        private readonly MenuAtendimento menuAtendimento;
        #endregion
        public Perifericos()
        {
            logfolder = AppDomain.CurrentDomain.BaseDirectory + "log\\";
            hors = string.IsNullOrEmpty(ConfigurationManager.AppSettings["Perifericos_HorasExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["Perifericos_MinutosExecucao"].Split(','), Convert.ToInt32);
            mins = string.IsNullOrEmpty(ConfigurationManager.AppSettings["Perifericos_MinutosExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["Perifericos_MinutosExecucao"].Split(','), Convert.ToInt32);
            fila_automation = ConfigurationManager.AppSettings["Perifericos_Fila_Automation"];
            artigo = ConfigurationManager.AppSettings["Perifericos_Artigo"];

            fila_15 = ConfigurationManager.AppSettings["Perifericos_Fila_15"];
            fValidaUSB = ConfigurationManager.AppSettings["FValidaUSB"];
            erroGenerico = ConfigurationManager.AppSettings["ErroGenerico"];
            anotacaoWorkNote = ConfigurationManager.AppSettings["AnotacaoWorkNote"];
            resolucaoChamado = string.Format(ConfigurationManager.AppSettings["ResolucaoChamado"], System.Environment.NewLine);
            fReiniciaPeriferico = ConfigurationManager.AppSettings["FReiniciaPeriferico"];
            tzServiceNow = ConfigurationManager.AppSettings["TZBentonville"];
            tzLocal = ConfigurationManager.AppSettings["TZSaoPaulo"];
            fConectividadePDV = ConfigurationManager.AppSettings["FConectividadePDV"];
            pdvOffline = ConfigurationManager.AppSettings["PDVOffline"];
            fInitBlidada = ConfigurationManager.AppSettings["FInitBlidada"];
            fInitIBM = ConfigurationManager.AppSettings["FInitIBM"];
            subject = ConfigurationManager.AppSettings["Subject"];
            perguntaPDV = ConfigurationManager.AppSettings["PerguntaPDV"];
            perguntaEmail = ConfigurationManager.AppSettings["PerguntaEmail"];
            semDestinatario = ConfigurationManager.AppSettings["Semdestinatario"];
            pdvsNaoIdentificados = ConfigurationManager.AppSettings["PdvsNaoIdentificados"];
            userAssignedto = ConfigurationManager.AppSettings["UserAssignedto"];
            menuAtendimento = new MenuAtendimento()
            {
                UrlMenuAtendimento = ConfigurationManager.AppSettings["URLMenuAtendimento"],
                UsuarioMenuAtendimento = ConfigurationManager.AppSettings["MenuAtendimentoUsuario"],
                SenhaMenuAtendimento = ConfigurationManager.AppSettings["MenuAtendimentoSenha"],
            };
            hor_executado = -1;
            min_executado = -1;
        }

        public void DoWork()
        {
            if ((this.hors.Contains(this.hor_atual) && !this.hor_atual.Equals(this.hor_executado)) || (this.mins.Contains(this.min_atual) && !this.min_atual.Equals(this.min_executado)))
            {
                this.hor_executado = this.hor_atual;
                this.min_executado = this.min_atual;
                List<Chamado> chamados = ServiceNow.RecuperaChamadosAbertos(this.fila_automation, this.artigo);

                if (chamados.Count > 0)
                {
                    foreach (Chamado chamado in chamados)
                    {
                        Processa(chamado);
                    }
                }
                else
                {
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "NENHUM INCIDENTE ENCONTRADO", true);
                }
            }
        }

        public void Processa(Chamado chamado)
        {

            try
            {
                //Obtendo os dados para o processamento
                var loja = new string(chamado.u_department_id.Where(char.IsDigit).ToArray());
                var pdvs = Util.RecuperarValorEntre(chamado.description, this.perguntaPDV, System.Environment.NewLine).Trim().TrimStart('0');
                var destinatarios = ObterDestinatarios(chamado);
                var logs = chamado.comments_and_work_notes.Split(new[] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries);


                //Se não houver destinatario para o envio do email, direcionamos o chamado para a fila do 1.5
                if (string.IsNullOrEmpty(destinatarios))
                {
                    chamado.comments = this.semDestinatario;
                    chamado.work_notes = this.semDestinatario;
                    chamado.assignment_group = this.fila_15;
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, this.semDestinatario.Replace(System.Environment.NewLine, " "), true));
                }

                //Se nao for identificado os PDVs no chamado, direcionamos o chamado para a fila do 1.5
                else if (string.IsNullOrEmpty(pdvs))
                {
                    chamado.comments = this.pdvsNaoIdentificados;
                    chamado.work_notes = this.pdvsNaoIdentificados;
                    chamado.assignment_group = this.fila_15;
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, this.pdvsNaoIdentificados.Replace(System.Environment.NewLine, " "), true));
                }

                //Se o chamado está em "In Progress" e contém uma descrição que logamos e faz 10 minutos ou mais que foi logado
                else if (chamado.state == "Work in Progress" && chamado.comments_and_work_notes.Contains(this.anotacaoWorkNote) && IntervaloParaExecucao(logs))
                {
                    var offlines = string.Empty;
                    var hasOffine = false;

                    //Verificando se há PDVs offline
                    foreach (var pdv in pdvs.Split(','))
                    {
                        if (PdvOnline(loja, pdv.Trim())) continue;
                        offlines += "," + pdv;
                        hasOffine = true;
                    }

                    //Se entre os PDVs listados houver pdv offline, direcionamos o chamado para a fila do 1.5
                    if (hasOffine)
                    {
                        chamado.assignment_group = this.fila_15;
                        chamado.comments = string.Format(this.pdvOffline, offlines.TrimStart(',').TrimEnd(','));
                        chamado.work_notes = string.Format(this.pdvOffline, offlines.TrimStart(',').TrimEnd(','));
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, this.pdvOffline.Replace(Environment.NewLine, " "), true));
                    }

                    // Senão, reiniciamos o serviço especifico para cada impressora configurada no PDV
                    else
                    {

                        ResetServicoEspecificoImpressoras(pdvs.Split(','), loja);

                        //Apos restart fechamos o chamado e mandamos o email com as orientações
                        chamado.comments = this.resolucaoChamado;
                        chamado.work_notes = this.resolucaoChamado;
                        chamado.state = "6";
                        chamado.incident_state = "6";
                        chamado.resolved_at = DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");

                        var email = new Email()
                        {
                            to = destinatarios,
                            subject = string.Format(this.subject, chamado.number),
                            body = BodyOfEmail().Replace("{saudacao}", Util.Saudacao())
                                                .Replace("{chamado}", chamado.number)
                                                .Replace("{pdvs}", pdvs)
                                                .Replace("{descricao}", chamado.description),

                        };

                        email.Send();
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - RESOLVIDO", chamado.number), true);
                        Util.GravarLog(chamado, email, this.logfolder);
                    }

                }

                //Se o chamado ja esta em InProgress, contem nosso log, mas não deu o tempo para executar o segundo passo 
                else if (chamado.state == "Work in Progress" && chamado.comments_and_work_notes.Contains(this.anotacaoWorkNote) && !IntervaloParaExecucao(logs))
                {
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - AGUARDANDO INTERVALO", chamado.number, true));
                    return;
                }

                //Reinicia os perifericos e colocar o chamado para In progress
                else
                {
                    foreach (var pdv in pdvs.Split(','))
                    {
                        var result = Request.ExecutarMenuAtendimento(menuAtendimento, ObterParametros(loja, pdv.Trim(), this.fReiniciaPeriferico));
                    }

                    chamado.state = "2";
                    chamado.assigned_to = this.userAssignedto;
                    chamado.comments = this.anotacaoWorkNote;
                    chamado.work_notes = this.anotacaoWorkNote;
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - IN PROGRESS - {1}", chamado.number, this.anotacaoWorkNote.Replace(System.Environment.NewLine, " "), true));
                }


                //Depois de todo processamento o chamado é atualizado.
                ServiceNow.AtualizaChamado(chamado);

            }

            //Caso ocorra algum erro durante o processameto, iremos informa um erro generico no chamado e encaminha para o 1.5
            catch (Exception ex)
            {
                chamado.comments = this.erroGenerico;
                chamado.work_notes = this.erroGenerico;
                chamado.assignment_group = this.fila_15;
                var erro = Util.ObterInformacoesErro(ex);
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, erro.Replace(System.Environment.NewLine, " "), true));
                ServiceNow.AtualizaChamado(chamado);
            }

        }

        #region Métodos Auxiliares
        private NameValueCollection ObterParametros(string loja, string pdv, string funcao)
        {
            var parameters = new NameValueCollection();
            parameters.Add("store", loja.ToLower().Trim());
            parameters.Add("pos", pdv.ToLower().Trim());
            parameters.Add("id", funcao.ToLower().Trim());
            parameters.Add("data", "0");
            parameters.Add("transacao", "0");

            return parameters;
        }
        private Impressora ConsultarValidacaoUsb(NameValueCollection parameters)
        {
            var html = Request.ExecutarMenuAtendimento(menuAtendimento, parameters);

            var impressora = new Impressora();
            var doc = new HtmlDocument();
            doc.LoadHtml(html);
            var nodes = doc.DocumentNode.SelectSingleNode("//table//table/tr[2]/td").InnerHtml.Replace("<br>", "*").Split('*');

            if (!string.IsNullOrEmpty(nodes.FirstOrDefault(n => n.Contains("Seiko Epson Corp."))))
                impressora.Epson = true;

            else
                impressora.IbmOuSat = true;

            return impressora;
        }
        private bool IntervaloParaExecucao(string[] logs)
        {
            try
            {
                if (logs == null) return false;
                var dtHrServiceNow = logs.FirstOrDefault(l => l.Contains(this.anotacaoWorkNote)).Substring(0, 19).Replace("-", "/").Trim();
                var culture = new CultureInfo("en-US", true);
                var dthrLog = DateTime.ParseExact(dtHrServiceNow, "MM/dd/yyyy HH:mm:ss", culture);
                var gmtServiceNow = Util.GetGMT(this.tzServiceNow);
                var gmtLocal = Util.GetGMT(this.tzLocal);

                var dataAtual = DateTime.Now.AddHours(gmtServiceNow - gmtLocal);
                return dataAtual >= dthrLog.AddMinutes(10);

            }
            catch (Exception)
            {

                throw;
            }
        }
        private bool PdvOnline(string loja, string pdv)
        {
            var html = Request.ExecutarMenuAtendimento(menuAtendimento, ObterParametros(loja, pdv, this.fConectividadePDV));
            var doc = new HtmlDocument();
            doc.LoadHtml(html);
            var nodes = doc.DocumentNode.SelectSingleNode("//table//table/tr[2]/td").InnerHtml.Replace("<br>", "*").Split('*');
            var result = nodes.FirstOrDefault(n => n.Contains("0% packet loss"));
            return !string.IsNullOrEmpty(result);
        }
        private string BodyOfEmail()
        {
            var response = "";
            try
            {
                response = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + @"Email\\Template.html");

            }
            catch (Exception)
            {

                throw;
            }

            return response;
        }
        private string ObterDestinatarios(Chamado chamado)
        {
            var solicitante = chamado.caller_id_email;
            var destinatarios = Util.RecuperarValorEntre(chamado.description, this.perguntaEmail, System.Environment.NewLine).Trim();
            return destinatarios += ";" + solicitante;
        }
        private void ResetServicoEspecificoImpressoras(string[] pdvs, string loja)
        {
            foreach (var pdv in pdvs)
            {
                var impressora = ConsultarValidacaoUsb(ObterParametros(loja, pdv.Trim(), this.fValidaUSB));

                if (impressora.Epson)
                    Request.ExecutarMenuAtendimento(menuAtendimento, ObterParametros(loja, pdv.Trim(), this.fInitBlidada));

                else if (impressora.IbmOuSat)
                    Request.ExecutarMenuAtendimento(menuAtendimento, ObterParametros(loja, pdv.Trim(), this.fInitIBM));
            }
        }

        #endregion
    }

    public class Impressora
    {
        public bool Epson { get; set; }
        public bool IbmOuSat { get; set; }
    }
}
