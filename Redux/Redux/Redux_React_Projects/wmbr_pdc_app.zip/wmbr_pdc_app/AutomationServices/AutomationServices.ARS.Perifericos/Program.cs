﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ARS.Perifericos
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main()
        {
            if (IsDebug())
            {
                ServicePerifericos service = new ServicePerifericos(IsDebug());
                service.DoWork();
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new ServicePerifericos(IsDebug()) };
                ServiceBase.Run(ServicesToRun);
            }
        }

        public static bool IsDebug()
        {
            bool retorno = true;
            #if (!DEBUG)
                retorno = false;
            #endif
            
            return retorno;
        }
    }
}
