﻿using AutomationServices.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationServices.ARS.Perifericos
{
    public partial class ServicePerifericos : ServiceBase
    {
        private Thread Worker;
        private ManualResetEvent StopRequest = new ManualResetEvent(false);
        private volatile bool _shouldStop;
        private readonly int _timeSleep;
        public bool IsDebug;

        Perifericos wPerifericos = new Perifericos();
        public ServicePerifericos(bool _IsDebug)
        {
            _timeSleep = Convert.ToInt32(ConfigurationManager.AppSettings["TimeSleep"]);
            this.IsDebug = _IsDebug;
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (!IsDebug)
            {
                Log.Event(this.ServiceName, "Serviço iniciado", false);
                Worker = new Thread(DoWork);
                Worker.Name = this.ServiceName;
                Worker.IsBackground = true;
                Worker.Start();
            }
        }

        protected override void OnStop()
        {
            _shouldStop = true;
        }

        public void DoWork()
        {
            while (!_shouldStop)
            {
                wPerifericos.hor_atual = DateTime.Now.Hour;
                wPerifericos.min_atual = DateTime.Now.Minute;
                wPerifericos.ServiceName = this.ServiceName;

                if (IsDebug)
                {
                    wPerifericos.DoWork();
                }
                else
                {
                    Thread wrkRPerifericos = new Thread(wPerifericos.DoWork);
                    wrkRPerifericos.Start();
                    Thread.Sleep(_timeSleep);
                    wrkRPerifericos.Join();
                }
            }

            if (!IsDebug)
            {
                Worker.Join();
                Log.Event(this.ServiceName, "Serviço finalizado", false);
                StopRequest.Set();
            }
        }
    }
}
