﻿
TO INSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe "E:\SERVICES\AutomationServices\ARS.Perifericos\AutomationServices.ARS.Perifericos.exe"

TO UNINSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /u "E:\SERVICES\AutomationServices\ARS.Perifericos\AutomationServices.ARS.Perifericos.exe"


CHANGE FOLDERS TO FIT YOUR ENVIRONMENT

