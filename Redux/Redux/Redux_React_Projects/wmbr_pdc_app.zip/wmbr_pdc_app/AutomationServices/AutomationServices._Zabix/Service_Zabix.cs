﻿using AutomationServices.Common;
using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationServices._Zabix
{
    public partial class Service_Zabix : ServiceBase
    {
        

        private Thread Worker;
        private ManualResetEvent StopRequest = new ManualResetEvent(false);
        private volatile bool _shouldStop;
        private readonly int _timeSleep;
        private bool IsDebug;

        Zabix zabix = new Zabix();

        public Service_Zabix(bool _IsDebug)
        {
            _timeSleep = Convert.ToInt32(ConfigurationManager.AppSettings["TimeSleep"]);
            this.IsDebug = _IsDebug;
            InitializeComponent();
        }

        public Service_Zabix()
        {
            // TODO: Complete member initialization
        }


        protected override void OnStart(string[] args)
        {
            if (IsDebug)
            {
                Log.Event(this.ServiceName, "Servi;o inicializado", false);
                Worker = new Thread(DoWork);
                Worker.Name = this.ServiceName;
                Worker.IsBackground = true;
                Worker.Start();
            }
        }

        protected override void OnStop()
        {
            _shouldStop = true;
        }

        public void DoWork()
        {
            while (!_shouldStop)
            {
                int hor_atual = DateTime.Now.Hour;
                int min_atual = DateTime.Now.Minute;

               //TODO
               //


                               
                return; 
            }
        }
}
}
