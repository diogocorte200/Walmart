﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutomationServices.Common;

namespace AutomationServices._Zabix
{
    public class Zabix
    {
        public Zabix()
        {

            logfolder = AppDomain.CurrentDomain.BaseDirectory + "log\\";
            subject = ConfigurationManager.AppSettings["Subject"];

        }


        public int[] hors;
        public int[] mins;
        public int hor_atual;
        public int min_atual;
        public int hor_executado;
        public int min_executado;
        public string ServiceName;
        private readonly string logfolder;
        private readonly string fila_automation;
        private readonly string artigo;
        private readonly string fila_15;
        private readonly string fValidaUSB;
        private readonly string erroGenerico;
        private readonly string anotacaoWorkNote;
        private readonly string resolucaoChamado;
        private readonly string fReiniciaPeriferico;
        private readonly string tzServiceNow;
        private readonly string tzLocal;
        private readonly string fConectividadePDV;
        private readonly string fInitBlidada;
        private readonly string fInitIBM;
        private readonly string pdvOffline;
        private readonly string subject;
        private readonly string perguntaPDV = "Teste";
        private readonly string perguntaEmail = "1";
        private readonly string semDestinatario;
        private readonly string pdvsNaoIdentificados;
        private readonly string userAssignedto;
        private readonly MenuAtendimento menuAtendimento;


        public string ObterDestinatarios(Chamado chamado)
        {
            var solicitante = chamado.caller_id_email;
            var destinatarios = Util.RecuperarValorEntre(chamado.description, this.perguntaEmail, System.Environment.NewLine).Trim();
            return destinatarios += ";" + solicitante;
        }

        public string BodyOfEmail()
        {
            var response = "";
            try
            {
                response = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + @"Email\\Template.html");

            }
            catch (Exception)
            {

                throw;
            }

            return response;
        }

        public void SendMail()
        {
            
            Chamado chamado = new  Chamado();

            var destinatarios = ObterDestinatarios(chamado);
            var pdvs = Util.RecuperarValorEntre(chamado.description, this.perguntaPDV, System.Environment.NewLine).Trim().TrimStart('0');
            
            var email = new Email()
            {
                //string destinatarios = "franciscodiogo11@gmail.com",
                to = destinatarios,
                subject = string.Format(this.subject, chamado.number),
                //subject = string.Format(chamado.number),
                body = BodyOfEmail().Replace("{saudacao}", Util.Saudacao())
                    .Replace("{chamado}", chamado.number)
                    .Replace("{pdvs}", pdvs)
                    .Replace("{descricao}", chamado.description),

            };

            email.Send();
            Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - RESOLVIDO", chamado.number), true);
           // Util.GravarLog(chamado, email, this.logfolder);
        }
        
        public List<Arquivo> MethodLerArquivo()
        {
            var data = new List<Arquivo>().ToList();


            string arquivo = @"C:\arquivotxt\arquivo.xlsx";


            var dataTable = ReadExcelHelper.Read(arquivo);

            foreach (System.Data.DataRow item in dataTable.Rows)
            {
                var obj = new Arquivo()
                {
                    Nome = !DBNull.Value.Equals(item["Nome"].ToString())
                        ? (item["Nome"].ToString().Trim())
                        : string.Empty,
                    Endereco = !DBNull.Value.Equals(item["Endereco"].ToString())
                        ? (item["Endereco"].ToString().Trim())
                        : string.Empty,
                    Teste = !DBNull.Value.Equals(item["Teste"].ToString())
                        ? (item["Teste"].ToString().Trim())
                        : string.Empty,

                };

                data.Add(obj);
                // Console.WriteLine(obj.Nome, obj.Endereco, obj.Teste);
            }

            return data.ToList();

        }

    }
}
