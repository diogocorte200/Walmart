﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutomationServices.Common;
using System.Configuration;

namespace AutomationServices.LimpezaDesktop
{
    public partial class ServiceLimpezaDesktop : ServiceBase
    {
        private Thread Worker;
        //private AutoResetEvent StopRequest = new AutoResetEvent(false);
        private ManualResetEvent StopRequest = new ManualResetEvent(false);
        private volatile bool _shouldStop;
        public bool IsDebug;
        private readonly int _timeSleep;
        LimpezaDesktop wLimpezaDesktop = new LimpezaDesktop();

        public ServiceLimpezaDesktop(bool _IsDebug)
        {
            _timeSleep = Convert.ToInt32(ConfigurationManager.AppSettings["TimeSleep"]);
            this.IsDebug = _IsDebug;
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (!IsDebug)
            {
                Log.Event(this.ServiceName, "Serviço iniciado", false);
                Worker = new Thread(DoWork);
                Worker.Name = this.ServiceName;
                Worker.IsBackground = true;
                Worker.Start();
            }
        }

        protected override void OnStop()
        {
            _shouldStop = true;
        }

        public void DoWork()
        {
            while (!_shouldStop)
            {
                wLimpezaDesktop.hor_atual = DateTime.Now.Hour;
                wLimpezaDesktop.min_atual = DateTime.Now.Minute;
                wLimpezaDesktop.ServiceName = this.ServiceName;

                if (IsDebug)
                {
                    wLimpezaDesktop.DoWork(IsDebug);
                }
                else
                {
                    Thread wrkLimpezaDesktop = new Thread(() => wLimpezaDesktop.DoWork(IsDebug));
                    wrkLimpezaDesktop.Start();
                    Thread.Sleep(_timeSleep);
                    wrkLimpezaDesktop.Join();
                }
            }

            if (!IsDebug)
            {
                Worker.Join();
                Log.Event(this.ServiceName, "Serviço finalizado", false);
                StopRequest.Set();
            }
        }

    }
}
