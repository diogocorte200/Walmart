﻿param (
   [Parameter(Mandatory=$true)][string]$INC = $Args[0],
   [Parameter(Mandatory=$true)][string]$COMPUTER = $Args[1],
	[Parameter(Mandatory=$true)][string]$user = $Args[2],
	[Parameter(Mandatory=$true)][string]$pass = $Args[3],
	[Parameter(Mandatory=$true)][string]$OrigShare = $Args[4],
	[Parameter(Mandatory=$true)][string]$OrigFolder = $Args[5],
	[Parameter(Mandatory=$true)][string]$FileName = $Args[6]
)

cls

#$INC = "INC0001"
#$COMPUTER = "LEUS71609550783"
#$user = "br\wnprimo"
#$pass = "D4rkn!ght"
#$OrigShare = "\\brnts850\data15"
#$OrigFolder = "\HDInstall\SOFTWARE\C\CC_job para limpar arquivos temporários\ClearCacheRemotely\ClearCacheBatch"
#$FileName = "ClearCacheBatch.bat"

$ERRORACTIONPREFERENCE = "silentlycontinue"
$DOMAIN_NAME = [System.Net.Dns]::gethostentry($COMPUTER)
$TMP_DIR = "\\$COMPUTER\c$\ClearCacheBatch"
$TMP_BATCH = "$TMP_DIR\$FileName"
$SCRIPT_BATCH = "$OrigShare$OrigFolder\$FileName"

$secureString = ConvertTo-SecureString -AsPlainText -Force -String $pass
$encryptedString = ConvertFrom-SecureString -SecureString $secureString
$secureString = ConvertTo-SecureString -String $encryptedString
$cred = $null
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $user, $secureString

Get-Job|Remove-Job -Force
Write-Host "$INC"

If (Test-Connection $COMPUTER -count 1 -quiet) {
    if (!(Test-Path -path $TMP_DIR)) { New-Item $TMP_DIR -Type Directory 2>> $NULL }
    if (!(Test-Path $TMP_BATCH)) { Copy-Item $SCRIPT_BATCH $TMP_DIR 2>> $NULL;Start-Sleep -s 1 }
    $CUSTOM_JOB_NAME = "$COMPUTER.$INC"

    Invoke-Command -ComputerName $COMPUTER -Credential $cred -ScriptBlock {param($FileName) Trace-Command NativeCommandParameterBinder -Expression { & cmd.exe /c "C:\ClearCacheBatch\$FileName"}} -Authentication negotiate -ArgumentList $FileName -AsJob -JobName $CUSTOM_JOB_NAME >> $NULL

    #Invoke-Command -ComputerName $COMPUTER -Credential $cred -ScriptBlock {param($FileName) Trace-Command NativeCommandParameterBinder -Expression { & cmd.exe /c "$LOCAL_DIR\$FileName"}} -Authentication negotiate -ArgumentList $FileName -AsJob -JobName $CUSTOM_JOB_NAME >> $NULL

    While ($(Get-Job -Name "*$INC*").State -contains "Running") {
        $IP_RUNNING = $(Get-Job -State "Running").Location
        Write-Host "Executando na máquina : "
        Write-Host "$IP_RUNNING"
        Start-Sleep -s 10
    }

    $FINAL_STATE = $(Get-Job -Name "*.$INC*").State

    If ( $FINAL_STATE -contains "NotStarted" -or $FINAL_STATE -contains "Failed" -or $FINAL_STATE -contains "Stopped" -or $FINAL_STATE -contains "Blocked" -or $FINAL_STATE -contains "Suspended" -or $FINAL_STATE -contains "Disconnected" -or $FINAL_STATE -contains "Suspending" -or $FINAL_STATE -contains "Stopping") {
        return "RESULT: NOK"
    }

    return "RESULT: OK"

} else {
    return "RESULT: NOK"
}
