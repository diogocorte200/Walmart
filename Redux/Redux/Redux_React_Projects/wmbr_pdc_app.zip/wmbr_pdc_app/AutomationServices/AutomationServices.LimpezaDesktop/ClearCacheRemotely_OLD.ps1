﻿# .\ClearCacheRemotely.ps1
#	"LEUS71609550783"
#	"br\wnprimo"
#	"D4rkn!ght"
#	"\\brnts850\data15"
#	"\HDInstall\SOFTWARE\C\CC_job para limpar arquivos temporários\ClearCacheRemotely\ClearCacheBatch"
#	"ClearCacheBatch.bat"

param (
    [Parameter(Mandatory=$true)][string]$RemoteMachine = $Args[0],
	[Parameter(Mandatory=$true)][string]$user = $Args[1],
	[Parameter(Mandatory=$true)][string]$pass = $Args[2],
	[Parameter(Mandatory=$true)][string]$OrigShare = $Args[3],
	[Parameter(Mandatory=$true)][string]$OrigFolder = $Args[4],
	[Parameter(Mandatory=$true)][string]$FileName = $Args[5]
)

cls

Try {
    #$RemoteMachine = "LEUS71609550783"
    #$user = "br\wnprimo"
    #$pass = "D4rkn!ght"
    #$OrigShare = "\\brnts850\data15"
	#$OrigFolder = "\HDInstall\SOFTWARE\C\CC_job para limpar arquivos temporários\ClearCacheRemotely\ClearCacheBatch"
	#$FileName = "ClearCacheBatch.bat"

    $OrigDrive = "X:"
    $DestDrive = "Y:"
    $OrigFile = "$OrigFolder\$FileName"
    $DestFolder = "$DestDrive\ClearCacheBatch"
    $LocalFile = "C:\ClearCacheBatch\$FileName"

	net use * /d /y

    $net = new-object -ComObject WScript.Network

    If ((test-path "$OrigDrive")) { $net.RemoveNetworkDrive("$OrigDrive", $true) }
    $net.MapNetworkDrive("$OrigDrive", "$OrigShare", $false, "$user", "$pass")

    If ((test-path "$DestDrive")) { $net.RemoveNetworkDrive("$DestDrive", $true) }
    $net.MapNetworkDrive("$DestDrive", "\\$RemoteMachine\c$", $false, "$user", "$pass")

    New-Item -ItemType Directory -Force -Path "$DestFolder" |out-null
    Copy-Item "$OrigDrive$OrigFile" -Destination "$DestFolder" |out-null

    If ((test-path "$OrigDrive")) { $net.RemoveNetworkDrive("$OrigDrive", $true) }
    If ((test-path "$DestDrive")) { $net.RemoveNetworkDrive("$DestDrive", $true) }

    $secureString = ConvertTo-SecureString -AsPlainText -Force -String $pass
    $encryptedString = ConvertFrom-SecureString -SecureString $secureString
    $secureString = ConvertTo-SecureString -String $encryptedString

    $cred = $null
    $cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $user, $secureString
    Invoke-Command -ComputerName $RemoteMachine -ScriptBlock {param($FileName) Trace-Command NativeCommandParameterBinder -Expression { & cmd.exe /c "$LocalFile"}} -Credential $cred -ArgumentList $FileName -AsJob -JobName $RemoteMachine >> $NULL

    While ($(Get-Job -Name "$RemoteMachine").State -contains "Running") {
        #$IP_RUNNING = $(Get-Job -State "Running").Location
        #Write-Host "Executando na máquina : "
        #Write-Host "$IP_RUNNING"
        Start-Sleep -s 10
    }

    return "RESULT: OK"
}
Catch [Exception] {
   write-host $_.Exception.Message
   return "RESULT: NOK"
}