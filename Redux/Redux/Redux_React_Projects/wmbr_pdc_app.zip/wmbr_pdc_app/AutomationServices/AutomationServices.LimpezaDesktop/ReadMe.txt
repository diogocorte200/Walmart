﻿
TO INSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe "E:\SERVICES\AutomationServices\AutomationServices.LimpezaDesktop.exe"

TO UNINSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /u "E:\SERVICES\AutomationServices\AutomationServices.LimpezaDesktop.exe"


CHANGE FOLDERS TO FIT YOUR ENVIRONMENT

