﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Security;
using AutomationServices.Common;
using System.Globalization;
using System.Threading;

namespace AutomationServices.LimpezaDesktop
{
    public class LimpezaDesktop
    {
        private string logfolder;
        private string perguntaLimpeza;
        private string perguntaMaquina;
        private string mensagemLimpezaOk;
        private string mensagemLimpezaNok;
        private string batchName;
        private string batchOriginalShare;
        private string batchOriginalFolder;
        private string domain;
        private string user;
        private string password;
        private string fila_automation;
        private string fila_servicedesk;
        private string artigo;
        private string servicenowUsername;
        private int quantidadeTentativas;
        private int horasEntreTentativas;
        private bool desconsiderarTentativasFinalDeSemana;
        public int[] hors;
        public int[] mins;
        public int hor_atual;
        public int min_atual;
        public int hor_executado;
        public int min_executado;
        public string ServiceName;

        public LimpezaDesktop()
        {
            logfolder = AppDomain.CurrentDomain.BaseDirectory + "log\\" + (string.IsNullOrEmpty(ConfigurationManager.AppSettings["LimpezaDesktop_PastaLog"]) ? string.Empty : ConfigurationManager.AppSettings["LimpezaDesktop_PastaLog"] + "\\");
            perguntaLimpeza = ConfigurationManager.AppSettings["LimpezaDesktop_Pergunta_Limpeza"];
            perguntaMaquina = ConfigurationManager.AppSettings["LimpezaDesktop_Pergunta_Maquina"];
            mensagemLimpezaOk = ConfigurationManager.AppSettings["LimpezaDesktop_Mensagem_Limpeza_Ok"];
            mensagemLimpezaNok = ConfigurationManager.AppSettings["LimpezaDesktop_Mensagem_Limpeza_Nok"];
            batchName = ConfigurationManager.AppSettings["LimpezaDesktop_BatchName"];
            batchOriginalShare = ConfigurationManager.AppSettings["LimpezaDesktop_ShareBatchOriginal"];
            batchOriginalFolder = ConfigurationManager.AppSettings["LimpezaDesktop_PastaBatchOriginal"];
            domain = ConfigurationManager.AppSettings["LimpezaDesktop_Domain"];
            user = ConfigurationManager.AppSettings["LimpezaDesktop_User"];
            password = ConfigurationManager.AppSettings["LimpezaDesktop_Password"];
            fila_automation = ConfigurationManager.AppSettings["LimpezaDesktop_Fila_Automation"];
            fila_servicedesk = ConfigurationManager.AppSettings["LimpezaDesktop_Fila_ServiceDesk"];
            artigo = ConfigurationManager.AppSettings["LimpezaDesktop_Artigo"];
            servicenowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
            quantidadeTentativas = Convert.ToInt32(ConfigurationManager.AppSettings["LimpezaDesktop_QuantidadeTentativas"].ToString());
            horasEntreTentativas = Convert.ToInt32(ConfigurationManager.AppSettings["LimpezaDesktop_HorasEntreTentativas"].ToString());
            desconsiderarTentativasFinalDeSemana = ConfigurationManager.AppSettings["LimpezaDesktop_DesconsiderarTentativasFinalDeSemana"].ToUpper().Equals("TRUE");
            hors = string.IsNullOrEmpty(ConfigurationManager.AppSettings["LimpezaDesktop_HorasExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["LimpezaDesktop_HorasExecucao"].Split(','), Convert.ToInt32);
            mins = string.IsNullOrEmpty(ConfigurationManager.AppSettings["LimpezaDesktop_MinutosExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["LimpezaDesktop_MinutosExecucao"].Split(','), Convert.ToInt32);
            hor_executado = -1;
            min_executado = -1;
        }

        public void DoWork(bool IsDebug)
        {
            if (this.hors.Contains(this.hor_atual) && !this.hor_atual.Equals(this.hor_executado) && this.mins.Contains(this.min_atual) && !this.min_atual.Equals(this.min_executado))
            {
                this.hor_executado = this.hor_atual;
                this.min_executado = this.min_atual;

                List<Chamado> chamados = ServiceNow.RecuperaChamadosAbertos(this.fila_automation, this.artigo);

                if (chamados.Count > 0)
                {
                    if (IsDebug)
                    {
                        foreach (Chamado chamado in chamados)
                        {
                            Processa(chamado);
                        }
                    }
                    else
                    {
                        List<Thread> workerThreads = new List<Thread>();
                        foreach (Chamado chamado in chamados)
                        {
                            Thread thread = new Thread(() => Processa(chamado));
                            workerThreads.Add(thread);
                            thread.Start();
                        }
                        foreach (Thread thread in workerThreads)
                        {
                            thread.Join();
                        }
                    }
                }
                else
                {
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "NENHUM INCIDENTE ENCONTRADO", true);
                }
            }
        }

        private DateTime AddHoursCustom(DateTime inicial, int horas, bool desconsiderarTentativasFinalDeSemana)
        {
            DateTime final = inicial;

            if (desconsiderarTentativasFinalDeSemana)
            {
                int contador = 0;
                while (contador <= horas)
                {
                    final = final.AddHours(horas);
                    if (final.DayOfWeek.Equals(DayOfWeek.Monday) || final.DayOfWeek.Equals(DayOfWeek.Tuesday) || final.DayOfWeek.Equals(DayOfWeek.Wednesday) || final.DayOfWeek.Equals(DayOfWeek.Thursday) || final.DayOfWeek.Equals(DayOfWeek.Friday))
                    {
                        contador++;
                    }
                }
            }
            else
            {
                final = inicial.AddHours(horas);
            }

            return final;
        }

        public void Processa(Chamado chamado)
        {
            // recupera dados do chamado para efetuar a limpeza
            Dados dados = RecuperaDados(chamado);

            if (dados.valido)
            {
                AssumeChamado(chamado.sys_id);

                foreach (Limpeza limpeza in dados.maquinas.Where(m => !m.limpeza && !m.atingiu_limite))
                {
                    if (IsAlive(limpeza.maquina))
                    {
                        // limpeza
                        string dominuser = string.Format(@"{0}\{1}", this.domain, this.user);
                        CommandLine cl = new CommandLine();
                        string command = string.Format(@"PowerShell .\ClearCacheRemotely.ps1 '{0}' '{1}' '{2}' '{3}' '{4}' '{5}' '{6}'", chamado.number, limpeza.maquina, dominuser, this.password, this.batchOriginalShare, this.batchOriginalFolder, this.batchName);
                        string map = AppDomain.CurrentDomain.BaseDirectory;
                        string retorno = cl.Execute(command, map);
                        bool result = retorno.ToUpper().Contains("RESULT: OK");

                        if (result)
                        {
                            IncluiComentarioChamado(chamado.sys_id, string.Format(this.mensagemLimpezaOk, limpeza.maquina));
                            limpeza.limpeza = true;
                            limpeza.pendente = false;
                        }
                        else
                        {
                            if (DateTime.Now >= AddHoursCustom(limpeza.ultima_tentativa, this.horasEntreTentativas, this.desconsiderarTentativasFinalDeSemana))
                            {
                                IncluiComentarioChamado(chamado.sys_id, string.Format(this.mensagemLimpezaNok, limpeza.maquina));
                                limpeza.limpeza = false;
                                limpeza.tentativas = limpeza.tentativas + 1;
                                limpeza.atingiu_limite = limpeza.tentativas >= this.quantidadeTentativas;
                                limpeza.pendente = !limpeza.atingiu_limite;
                                limpeza.ultima_tentativa = DateTime.Now;
                            }
                        }
                    }
                }

                if (dados.maquinas.Count(m => m.limpeza).Equals(dados.maquinas.Count))
                {
                    // resolve o chamado
                    ResolveChamado(chamado.sys_id);
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - RESOLVIDO", chamado.number), true);
                }
                else
                {
                    if (dados.maquinas.Count(m => m.pendente).Equals(0))
                    {
                        // redireciona chamado
                        string mensagem = "Limpeza executada com sucesso ou número de tentativas atingido.";
                        RedirecionaChamado(chamado.sys_id, fila_servicedesk, mensagem, null);
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, mensagem), true);
                    }
                }
            }
            else
            {
                // atualiza o chamado informando que os dados não são válidos e por isso o chamado não será atendido de forma automática, direcionando para a fila manual
                RedirecionaChamado(chamado.sys_id, fila_servicedesk, dados.mensagem, null);
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, dados.mensagem), true);
            }
        }

        public Dados RecuperaDados(Chamado chamado)
        {
            Dados dados = new Dados();
            dados.limpeza = RecuperarValorEntre(chamado.description, this.perguntaLimpeza, this.perguntaLimpeza).ToUpper().Trim().Equals("SIM");
            dados.maquinas = new List<Limpeza>();
            string[] maqs = RecuperarValorEntre(chamado.description, this.perguntaMaquina, this.perguntaMaquina).ToUpper().Trim().Replace(" ", "").Replace(";", ",").Split(',');
            foreach(string maq in maqs)
            {
                Limpeza lmp = new Limpeza();
                lmp.maquina = maq;
                lmp.limpeza = chamado.comments_and_work_notes.Contains(string.Format(mensagemLimpezaOk, maq));
                string mensagem = "(Work notes) " + string.Format(mensagemLimpezaNok, maq);
                lmp.tentativas = (chamado.comments_and_work_notes.Length - chamado.comments_and_work_notes.Replace(mensagem, "").Length) / mensagem.Length;
                int pos = chamado.comments_and_work_notes.LastIndexOf(mensagem);
                if (pos > -1)
                {
                    string parcial = chamado.comments_and_work_notes.Substring(0, pos);
                    pos = parcial.LastIndexOf("-");
                    parcial = parcial.Substring(pos - 20, 19);
                    lmp.ultima_tentativa = DateTime.ParseExact(parcial, "MM-dd-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                }
                lmp.atingiu_limite = lmp.tentativas >= this.quantidadeTentativas;
                lmp.pendente = !lmp.limpeza && !lmp.atingiu_limite;
                dados.maquinas.Add(lmp);
            }

            if (dados.limpeza)
            {
                if (dados.maquinas.Count.Equals(0))
                {
                    dados.valido = false;
                    dados.mensagem = "Nenhuma máquina foi informada para limpeza, e por esse motivo o chamado não pode ser tratado de forma automática.";
                }
                else
                {
                    dados.valido = true;
                    dados.mensagem = string.Empty;
                }
            }
            else
            {
                dados.valido = false;
                dados.mensagem = "O usuário não informou que deseja fazer a limpeza do desktop, e por esse motivo o chamado não pode ser tratado de forma automática.";
            }

            return dados;
        }

        public string RecuperarValorEntre(string texto, string inicial, string final)
        {
            string resultado = string.Empty;

            int posicao_inicial = texto.IndexOf(inicial, StringComparison.InvariantCultureIgnoreCase);
            if (posicao_inicial.Equals(-1))
            {
                return resultado;
            }
            else
            {
                posicao_inicial += inicial.Length;
            }

            int posicao_final = texto.IndexOf(string.IsNullOrEmpty(final) ? System.Environment.NewLine : final, posicao_inicial, StringComparison.InvariantCultureIgnoreCase);
            if (posicao_final < posicao_inicial)
            {
                posicao_final = texto.Length;
            }

            if (posicao_inicial >= 0 && posicao_final >= 0 && posicao_final > posicao_inicial)
            {
                resultado = texto.Substring(posicao_inicial, posicao_final - posicao_inicial);
            }
            return resultado;
        }

        public void ResolveChamado(string sys_id)
        {
            Chamado chamado = new Chamado();
            chamado.sys_id = sys_id;
            chamado.comments = "Limpeza de desktop efetuada com sucesso.";
            chamado.work_notes = "Limpeza de desktop efetuada com sucesso.";
            chamado.state = "6";
            chamado.incident_state = "6";
            chamado.resolved_at = DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");

            bool resolve = ServiceNow.AtualizaChamado(chamado);
        }

        public void RedirecionaChamado(string sys_id, string group, string message, string priority)
        {
            Chamado chamado = new Chamado();
            chamado.sys_id = sys_id;
            if (!string.IsNullOrEmpty(message)) chamado.comments = message;
            if (!string.IsNullOrEmpty(message)) chamado.work_notes = message;
            if (!string.IsNullOrEmpty(group)) chamado.assignment_group = group;
            if (!string.IsNullOrEmpty(priority)) chamado.priority = priority;
            chamado.assigned_to = string.Empty;

            bool resolve = ServiceNow.AtualizaChamado(chamado);
        }

        public void AssumeChamado(string sys_id)
        {
            Chamado chamado = new Chamado();
            chamado.sys_id = sys_id;
            chamado.state = "2";
            chamado.incident_state = "2";
            chamado.assigned_to = servicenowUsername;

            bool resolve = ServiceNow.AtualizaChamado(chamado);
        }

        public void IncluiComentarioChamado(string sys_id, string message)
        {
            Chamado chamado = new Chamado();
            chamado.sys_id = sys_id;
            if (!string.IsNullOrEmpty(message)) chamado.comments = message;
            if (!string.IsNullOrEmpty(message)) chamado.work_notes = message;

            bool resolve = ServiceNow.AtualizaChamado(chamado);
        }

        public bool IsAlive(string machine)
        {
            bool retorno = false;

            try
            {
                Ping ping = new Ping();
                PingReply pingReply = ping.Send(machine);
                retorno = pingReply.Status == IPStatus.Success;
            }
            catch (Exception)
            {
                retorno = false;
            }
            return retorno;
        }

    }

    public class Dados
    {
        public bool limpeza { get; set; }
        public List<Limpeza> maquinas { get; set; }
        public bool valido { get; set; }
        public string mensagem { get; set; }
    }

    public class Limpeza
    {
        public string maquina { get; set; }
        public bool limpeza { get; set; }
        public int tentativas { get; set; }
        public DateTime ultima_tentativa { get; set; }
        public bool atingiu_limite { get; set; }
        public bool pendente { get; set; }
    }

}
