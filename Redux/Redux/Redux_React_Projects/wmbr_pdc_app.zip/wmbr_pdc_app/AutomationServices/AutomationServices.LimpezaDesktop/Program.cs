﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.LimpezaDesktop
{
    static class Program
    {
        static void Main()
        {
            if (IsDebug())
            {
                ServiceLimpezaDesktop service = new ServiceLimpezaDesktop(IsDebug());
                service.DoWork();
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new ServiceLimpezaDesktop(IsDebug()) };
                ServiceBase.Run(ServicesToRun);
            }
        }

        public static bool IsDebug()
        {
            bool retorno = true;
            #if (!DEBUG)
                retorno = false;
            #endif
            return retorno;
        }

    }
}
