﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;

namespace AutomationServices.Common
{
    public class Log
    {
        public static void Event(string source, string message, bool iserror)
        {
            using (EventLog eventLog = new EventLog("Application"))
            {
                eventLog.Source = source;
                eventLog.WriteEntry(message, iserror ? EventLogEntryType.Error : EventLogEntryType.Information);
            }
        }

        public static void Files(string folder, string file, string message, bool timestamp = true)
        {
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            File.AppendAllText(folder + file, (timestamp ? DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - " : string.Empty) + message + Environment.NewLine);
        }
    }
}
