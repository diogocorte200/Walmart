﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using System.Collections;
using System.Collections.Specialized;

namespace AutomationServices.Common
{
    public class Request
    {
        public static string ExecutarMenuAtendimento(MenuAtendimento menu, NameValueCollection param)
        {
            var result = "";
            try
            {
                var client = new WebClient();
                var method = "POST";
                client.Credentials = new NetworkCredential(menu.UsuarioMenuAtendimento, menu.SenhaMenuAtendimento);
                var response_data = client.UploadValues(menu.UrlMenuAtendimento, method, param);
                result = UnicodeEncoding.UTF8.GetString(response_data);
            }
            catch (Exception)
            {

                throw;
            }


            return result;
        }

       
    }
}
