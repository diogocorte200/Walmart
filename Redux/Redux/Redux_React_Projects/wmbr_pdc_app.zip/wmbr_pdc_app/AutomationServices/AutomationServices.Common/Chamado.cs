﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.Common
{
    public class Chamado
    {
        public string sys_id { get; set; }
        public string number { get; set; }
        public string short_description { get; set; }
        public string description { get; set; }
        public string caller_id { get; set; }
        public string caller_id_user_name { get; set; }
        public string caller_id_name { get; set; }
        public string caller_id_email { get; set; }
        public string assignment_group { get; set; }
        public string u_ci_class_name { get; set; }
        public string u_serial_number { get; set; }
        public string u_knowledge_id { get; set; }
        public string work_notes { get; set; }
        public string comments { get; set; }
        public string assigned_to { get; set; }
        public string state { get; set; }
        public string priority { get; set; }
        public string incident_state { get; set; }
        public string resolved_by { get; set; }
        public string resolved_at { get; set; }
        public string comments_and_work_notes { get; set; }
        public string reopened_time { get; set; }
        public string u_department_id { get; set; }
        public string erro { get; set; }

    }
}
