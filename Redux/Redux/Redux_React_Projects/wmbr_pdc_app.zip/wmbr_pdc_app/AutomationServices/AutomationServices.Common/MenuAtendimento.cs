﻿namespace AutomationServices.Common
{
    public class MenuAtendimento
    {
        public string UrlMenuAtendimento { get; set; }
        public string UsuarioMenuAtendimento { get; set; }
        public string SenhaMenuAtendimento { get; set; }
    }
}
