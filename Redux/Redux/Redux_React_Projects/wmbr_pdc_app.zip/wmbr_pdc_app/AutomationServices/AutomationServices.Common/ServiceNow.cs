﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Dynamic;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AutomationServices.Common
{
    public class ServiceNow
    {
        public static string ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
        public static string ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
        public static string ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
        public static string ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
        public static int ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);

        public static List<Chamado> RecuperaChamadosAbertos(string fila, string artigo)
        {
            List<Chamado> chamados = new List<Chamado>();

            try
            {
                string api = "/api/now/table/incident?GET&sysparm_display_value=true&sysparm_fields=u_department.id,sys_id,number,description,caller_id.user_name,caller_id.name,caller_id.email,comments_and_work_notes,reopened_time,state&sysparm_query=assignment_group=" + fila + "^u_knowledge_id.numberIN" + artigo + "^stateNOT IN6,7,8";
                //string api = "/api/now/table/incident?GET&sysparm_display_value=true&sysparm_fields=u_department.id,sys_id,number,description,caller_id.user_name,caller_id.name,caller_id.email,comments_and_work_notes,reopened_time&sysparm_query=assignment_group=" + fila + "^u_knowledge_id.numberIN" + artigo + "^stateNOT IN6,7,8^number=INC8528965";
                //string api = "/api/now/table/incident?GET&sysparm_display_value=true&sysparm_fields=u_department.id,sys_id,number,description,caller_id.user_name,caller_id.name,caller_id.email,comments_and_work_notes,reopened_time,state&&sysparm_query=number=INC8742529";
                string response = CallRestMethodGet(api);
                JObject joResponse = JObject.Parse(response);
                JArray jaResponse = (JArray)joResponse["result"];
                chamados = jaResponse.ToObject<List<Chamado>>();
            }
            catch (Exception)
            {
                throw;
            }

            return chamados;
        }

        public static void CriaChamado(ref Chamado chamado)
        {
            string api = "/api/now/table/incident";
            string json = ChamadoToJson(chamado);
            string response = CallRestMethodPost(api, json);

            JObject joResponse = JObject.Parse(response.ToString());
            JObject ojObject = (JObject)joResponse["result"];
            chamado.sys_id = ((JValue)ojObject.SelectToken("sys_id")).Value.ToString();
            chamado.number = ((JValue)ojObject.SelectToken("number")).Value.ToString();
        }

        public static bool AtualizaChamado(Chamado chamado)
        {
            bool ret = false;

            try
            {
                string api = "/api/now/table/incident";
                string json = ChamadoToJson(chamado);
                string response = CallRestMethodPut(api, json, chamado.sys_id);

                JObject joResponse = JObject.Parse(response.ToString());
                JObject ojObject = (JObject)joResponse["result"];
                chamado.sys_id = ((JValue)ojObject.SelectToken("sys_id")).Value.ToString();
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    ret = true;
                }
            }
            catch (Exception)
            {
                ret = false;
            }

            return ret;
        }

        public static string ChamadoToJson(Chamado chamado)
        {
            string json = string.Empty;

            try
            {
                dynamic o = new ExpandoObject();

                if (!string.IsNullOrEmpty(chamado.short_description))
                    o.short_description = chamado.short_description;

                if (!string.IsNullOrEmpty(chamado.description))
                    o.description = chamado.description;

                if (!string.IsNullOrEmpty(chamado.caller_id))
                    o.caller_id = chamado.caller_id;

                if (!string.IsNullOrEmpty(chamado.assignment_group))
                    o.assignment_group = chamado.assignment_group;

                if (!string.IsNullOrEmpty(chamado.u_ci_class_name))
                    o.u_ci_class_name = chamado.u_ci_class_name;

                if (!string.IsNullOrEmpty(chamado.u_serial_number))
                    o.u_serial_number = chamado.u_serial_number;

                if (!string.IsNullOrEmpty(chamado.u_knowledge_id))
                    o.u_knowledge_id = chamado.u_knowledge_id;

                if (!string.IsNullOrEmpty(chamado.work_notes))
                    o.work_notes = chamado.work_notes;

                if (!string.IsNullOrEmpty(chamado.comments))
                    o.comments = chamado.comments;

                if (!string.IsNullOrEmpty(chamado.assigned_to))
                    o.assigned_to = chamado.assigned_to;

                if (!string.IsNullOrEmpty(chamado.state))
                    o.state = chamado.state;

                if (!string.IsNullOrEmpty(chamado.incident_state))
                    o.incident_state = chamado.incident_state;

                if (!string.IsNullOrEmpty(chamado.resolved_by))
                    o.resolved_by = chamado.resolved_by;

                if (!string.IsNullOrEmpty(chamado.resolved_at))
                    o.resolved_at = chamado.resolved_at;

                json = JsonConvert.SerializeObject(o);

            }
            catch (Exception)
            {

                throw;
            }

            return json;
        }

        public static string PadronizaTexto(string texto)
        {
            string retorno = null;
            if (!string.IsNullOrWhiteSpace(texto))
            {
                retorno = texto.Replace(System.Environment.NewLine, "<br/>").Trim();
            }
            return retorno;
        }

        public static string CallRestMethodGet(string api)
        {
            string response = string.Empty;

            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl + api);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.Accept = "application/json";
                webrequest.ContentType = "application/json";
                webrequest.Method = "GET";
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);
                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    response = reader.ReadToEnd();
                }
                response = response.Replace("caller_id.user_name", "caller_id_user_name");
                response = response.Replace("caller_id.name", "caller_id_name");
                response = response.Replace("caller_id.email", "caller_id_email");
                response = response.Replace("u_department.id", "u_department_id");
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }

        public static string CallRestMethodPost(string api, string jsonpayload)
        {
            string response = string.Empty;

            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl + api);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.Accept = "application/json";
                webrequest.ContentType = "application/json";
                webrequest.Method = "POST";
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamWriter streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                {
                    streamWriter.Write(jsonpayload);
                }

                using (HttpWebResponse webresponse = webrequest.GetResponse() as HttpWebResponse)
                {
                    response = new StreamReader(webresponse.GetResponseStream()).ReadToEnd();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }

        public static string CallRestMethodPut(string api, string jsonpayload, string id)
        {
            string response = string.Empty;

            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl + api + "/" + id);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.Accept = "application/json";
                webrequest.ContentType = "application/json";
                webrequest.Method = "PUT";
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamWriter streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                {
                    streamWriter.Write(jsonpayload);
                }

                using (HttpWebResponse webresponse = webrequest.GetResponse() as HttpWebResponse)
                {
                    response = new StreamReader(webresponse.GetResponseStream()).ReadToEnd();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }

    }

}
