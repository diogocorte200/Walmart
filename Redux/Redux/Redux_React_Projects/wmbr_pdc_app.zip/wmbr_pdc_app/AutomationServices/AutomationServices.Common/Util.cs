﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace AutomationServices.Common
{
    public static class Util
    {
        public static string Saudacao()
        {
            var data = new DateTime();
            data = DateTime.Now;

            if (data.Hour >= 18 && data.Hour <= 24)
                return "Boa noite";

            if (data.Hour >= 12 && data.Hour < 18)
                return "Boa tarde";

            return "Bom dia";
        }
        public static string ObterInformacoesErro(Exception exception)
        {
            return "#LOCAL: " + exception.StackTrace + "  " +
                   "#MÉTODO: " + exception.TargetSite + "  " +
                   "#ERRO: " + exception.Message + "  ";

        }
        public static void GravarLog(Chamado chamado, Email email, string logfolder)
        {
            //var conteudo = RemoverTagsHtml(email.body);
            Log.Files(logfolder, chamado.number + ".log", string.Format("Date: {0}{1}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), Environment.NewLine), false);
            Log.Files(logfolder, chamado.number + ".log", string.Format("From: {0}{1}", email.from, Environment.NewLine), false);
            Log.Files(logfolder, chamado.number + ".log", string.Format("To: {0}{1}", email.to, Environment.NewLine), false);
            Log.Files(logfolder, chamado.number + ".log", string.Format("Subject: {0}{1}", email.subject, Environment.NewLine), false);
            Log.Files(logfolder, chamado.number + ".log", string.Format("{0}", Environment.NewLine), false);
            Log.Files(logfolder, chamado.number + ".log", string.Format("{0}", email.body.Replace("<br/>", Environment.NewLine)), false);
        }
        public static string RecuperarValorEntre(string texto, string inicial, string final)
        {
            string resultado = string.Empty;

            int posicao_inicial = texto.IndexOf(inicial, StringComparison.InvariantCultureIgnoreCase);
            if (posicao_inicial.Equals(-1))
            {
                return resultado;
            }
            else
            {
                posicao_inicial += inicial.Length;
            }

            int posicao_final = texto.IndexOf(string.IsNullOrEmpty(final) ? System.Environment.NewLine : final, posicao_inicial, StringComparison.InvariantCultureIgnoreCase);
            if (posicao_final < posicao_inicial)
            {
                posicao_final = texto.Length;
            }

            if (posicao_inicial >= 0 && posicao_final >= 0 && posicao_final > posicao_inicial)
            {
                resultado = texto.Substring(posicao_inicial, posicao_final - posicao_inicial);
            }
            return resultado;
        }
        public static int GetGMT(string timezone)
        {
            int gmt = 0;
            var timeZone = TimeZoneInfo.FindSystemTimeZoneById(timezone);
            gmt = timeZone.GetUtcOffset(DateTime.Now).Hours;
            return gmt;
        }

    }
}
