﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess;
using Oracle.ManagedDataAccess.Client;
using AutomationServices.Common;

namespace AutomationServices.ResetSenhaP2K
{
    public class ResetSenhaP2K
    {
        private string logfolder;
        private string perguntaReset;
        private string perguntaLoja;
        private string perguntaUsuario;
        private string perguntaNome;
        private string perguntaEmail;
        private string fila_automation;
        private string fila_farma;
        private string artigo;
        private string emailSubjectUsuario;
        private string emailSubjectEscalonamento;
        private string emailEscalonamento;
        private string emailCC;
        private string emailBCC;
        public int[] hors;
        public int[] mins;
        public int hor_atual;
        public int min_atual;
        public int hor_executado;
        public int min_executado;
        public string ServiceName;

        public ResetSenhaP2K()
        {
            logfolder = AppDomain.CurrentDomain.BaseDirectory + "log\\";
            perguntaReset = ConfigurationManager.AppSettings["ResetSenhaP2K_Pergunta_Reset"];
            perguntaLoja = ConfigurationManager.AppSettings["ResetSenhaP2K_Pergunta_Loja"];
            perguntaUsuario = ConfigurationManager.AppSettings["ResetSenhaP2K_Pergunta_Usuario"];
            perguntaNome = ConfigurationManager.AppSettings["ResetSenhaP2K_Pergunta_Nome"];
            perguntaEmail = ConfigurationManager.AppSettings["ResetSenhaP2K_Pergunta_Email"];
            fila_automation = ConfigurationManager.AppSettings["ResetSenhaP2K_Fila_Automation"];
            fila_farma = ConfigurationManager.AppSettings["ResetSenhaP2K_Fila_Farma"];
            artigo = ConfigurationManager.AppSettings["ResetSenhaP2K_Artigo"];
            emailSubjectUsuario = ConfigurationManager.AppSettings["ResetSenhaP2K_Email_Subject_Usuario"];
            emailSubjectEscalonamento = ConfigurationManager.AppSettings["ResetSenhaP2K_Email_Subject_Escalonamento"];
            emailEscalonamento = ConfigurationManager.AppSettings["ResetSenhaP2K_Email_Escalonamento"];
            emailCC = ConfigurationManager.AppSettings["ResetSenhaP2K_Email_CC"];
            emailBCC = ConfigurationManager.AppSettings["ResetSenhaP2K_Email_BCC"];
            hors = string.IsNullOrEmpty(ConfigurationManager.AppSettings["ResetSenhaP2K_HorasExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["ResetSenhaP2K_MinutosExecucao"].Split(','), Convert.ToInt32);
            mins = string.IsNullOrEmpty(ConfigurationManager.AppSettings["ResetSenhaP2K_MinutosExecucao"]) ? Array.ConvertAll<string, int>("0".Split(','), Convert.ToInt32) : Array.ConvertAll<string, int>(ConfigurationManager.AppSettings["ResetSenhaP2K_MinutosExecucao"].Split(','), Convert.ToInt32);
            hor_executado = -1;
            min_executado = -1;
        }

        public void DoWork()
        {
            if ((this.hors.Contains(this.hor_atual) && !this.hor_atual.Equals(this.hor_executado)) || (this.mins.Contains(this.min_atual) && !this.min_atual.Equals(this.min_executado)))
            {
                this.hor_executado = this.hor_atual;
                this.min_executado = this.min_atual;

                List<Chamado> chamados = new List<Chamado>();

                try
                {
                    chamados = ServiceNow.RecuperaChamadosAbertos(this.fila_automation, this.artigo);

                }
                catch (Exception ex)
                {
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "ServiceNow.RecuperaChamadosAbertos - " + ex.Message, true);
                }


                if (chamados.Count > 0)
                {
                    foreach (Chamado chamado in chamados)
                    {
                        Processa(chamado);
                    }
                }
                else
                {
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "NENHUM INCIDENTE ENCONTRADO", true);
                }
            }

        }
        
        public void Processa(Chamado chamado)
        {
            // recupera dados do chamado para efetuar o reset
            Dados dados = RecuperaDados(chamado);

            if (dados.valido)
            {
                if (string.IsNullOrEmpty(dados.email_senha) && string.IsNullOrEmpty(chamado.caller_id_email))
                {
                    // atualiza o chamado informando que não foi informado um email para envio da senha e que o solicitante não tem email no ServiceNow, direcionando para a fila manual
                    string mensagem = "Não foi informado um endereço de email para envio da senha e o solicitante não tem endereço de email cadastrado no ServiceNow, e por esse motivo o chamado não pode ser tratado de forma automática.";
                    RedirecionaChamado(chamado.sys_id, fila_farma, mensagem, null);
                    Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, mensagem), true);
                }
                else
                {
                    // verifica usuário P2K
                    ValidaUsuarioP2K(ref dados);

                    if (dados.usuario)
                    {
                        // efetua o reset de senha
                        Reset(ref dados);

                        if (dados.reset)
                        {
                            // envia o email para o usuário
                            string to = string.Empty;
                            if (!string.IsNullOrEmpty(chamado.caller_id_email))
                                to = chamado.caller_id_email.ToLower();
                            if (!string.IsNullOrEmpty(dados.email_senha) && dados.email_senha.ToLower() != chamado.caller_id_email.ToLower())
                                to += (!string.IsNullOrEmpty(to) ? "; " : string.Empty) + dados.email_senha.ToLower();

                            EnviaEmailUsuario(ref dados, chamado.number, to, this.emailCC, this.emailBCC);

                            if (dados.email)
                            {
                                // resolve o chamado
                                ResolveChamado(chamado.sys_id, to);
                                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - RESOLVIDO", chamado.number), true);
                            }
                            else
                            {
                                // atualiza o chamado informando que houve uma falha ao enviar email com a nova senha, direcionando para a fila manual
                                RedirecionaChamado(chamado.sys_id, fila_farma, dados.mensagem_email, null);
                                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, dados.mensagem_email), true);
                            }
                        }
                        else
                        {
                            // atualiza o chamado informando que houve uma falha ao efetuar o reset automático, direcionando para a fila manual
                            RedirecionaChamado(chamado.sys_id, fila_farma, dados.mensagem_reset, null);
                            Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, dados.mensagem_reset), true);
                        }
                    }
                    else
                    {
                        // atualiza o chamado informando que o usuário P2K não é válido e por isso o chamado não será atendido de forma automática, direcionando para a fila manual
                        RedirecionaChamado(chamado.sys_id, fila_farma, dados.mensagem_usuario, null);
                        Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, dados.mensagem_usuario), true);
                    }
                }
            }
            else
            {
                // atualiza o chamado informando que os dados não são válidos e por isso o chamado não será atendido de forma automática, direcionando para a fila manual
                RedirecionaChamado(chamado.sys_id, fila_farma, dados.mensagem_valido, dados.loja_fechada ? "1" : null);
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", string.Format("{0} - REDIRECIONADO - {1}", chamado.number, dados.mensagem_valido), true);

                if (dados.loja_fechada)
                {
                    // envia o email para o escalonamento e responsáveis
                    EnviaEmailEscalonamento(ref dados, chamado.number, chamado.caller_id_name, chamado.caller_id_user_name, this.emailEscalonamento, this.emailCC, this.emailBCC);
                }
            }
        }

        public void ValidaUsuarioP2K(ref Dados dados)
        {
            try
            {
                UsuarioP2K usuario = GetUsuarioP2K(dados.usuario_p2k);

                if (usuario == null)
                {
                    dados.usuario = false;
                    dados.mensagem_usuario = "Não foi possível recuperar o usuário no P2K, e por esse motivo o chamado não pode ser tratado de forma automática.";
                }
                else
                {
                    int ocorrencias = 0;
                    foreach (string palavra in dados.nome_p2k.Split(' '))
                    {
                        if (usuario.NOME.ToUpper().Contains(palavra.ToUpper()))
                        {
                            ocorrencias++;
                        }
                    }

                    if (ocorrencias > 0)
                    {
                        dados.usuario = true;
                        dados.mensagem_usuario = string.Empty;
                    }
                    else
                    {
                        dados.usuario = false;
                        dados.mensagem_usuario = "O nome do usuário informado não é o cadastrado no P2K, e por esse motivo o chamado não pode ser tratado de forma automática.";
                    }
                }
            }
            catch (Exception ex)
            {
                dados.usuario = false;
                dados.mensagem_usuario = ex.Message;
               // Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "ServiceNow.ValidaUsuarioP2K", true);

            }
        }

        public void ResolveChamado(string sys_id, string to)
        {
            Chamado chamado = new Chamado();
            chamado.sys_id = sys_id;
            chamado.comments = string.Format("Reset de senha no P2K efetuado com sucesso. Um email com a senha provisória e as instruções foi enviado para '{0}'", to);
            chamado.work_notes = string.Format("Reset de senha no P2K efetuado com sucesso. Um email com a senha provisória e as instruções foi enviado para '{0}'", to);
            chamado.state = "6";
            chamado.incident_state = "6";
            chamado.resolved_at = DateTime.Now.ToString("MM-dd-yyyy HH:mm:ss");

            try
            {
                bool resolve = ServiceNow.AtualizaChamado(chamado);
            }
            catch (Exception ex)
            {
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "ServiceNow.ResolveChamado - " + sys_id + " - " + ex.Message, true);
            }
      

        }

        public void RedirecionaChamado(string sys_id, string group, string message, string priority)
        {
            Chamado chamado = new Chamado();
            chamado.sys_id = sys_id;
            if (!string.IsNullOrEmpty(message)) chamado.comments = message;
            if (!string.IsNullOrEmpty(message)) chamado.work_notes = message;
            if (!string.IsNullOrEmpty(group)) chamado.assignment_group = group;
            if (!string.IsNullOrEmpty(priority)) chamado.priority = priority;

            try
            {
                bool resolve = ServiceNow.AtualizaChamado(chamado);
            }
            catch (Exception ex)
            {
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "ServiceNow.RedirecionaChamado - " + sys_id + " - " + ex.Message, true);
            }

           
        }

        public void EnviaEmailUsuario(ref Dados dados, string chamado, string to, string cc, string bcc)
        {
            StringBuilder sb = new StringBuilder();
            Email email = new Email();

            try
            {
                sb.Append("RESET DE SENHA P2K<br/>");
                sb.Append("<br/>");
                sb.AppendFormat("Login: {0}<br/>", dados.usuario_p2k.ToString());
                sb.AppendFormat("Senha Provisória Fornecida pelo Suporte : {0}<br/>", dados.senha_p2k);
                sb.Append("Após receber nova senha, deverá inserir a senha no Portal: https://wmlink/p2k<br/>");
                sb.Append("Aparecerá a mensagem de \"Senha Temporária\", tendo a necessidade de o usuário inserir uma nova senha.<br/>");
                sb.Append("Aparecerá a mensagem \"Senha Alterada com sucesso\"<br/>");
                sb.Append("A senha para o Portal estará atualizada no mesmo momento, para os PDVs e Assistente de Vendas descerá no próximo lote dentro de 2h (DUAS HORAS).<br/>");
                sb.Append("<br/>");
                sb.Append("<br/>");
                sb.Append("Abaixo temos as orientações para reset/troca de senhas no P2K para cada situação:<br/>");
                sb.Append("<br/>");
                sb.Append("1. Caso de senha expirada<br/>");
                sb.Append("<br/>");
                sb.Append("a. Usuário sabe qual é a sua senha mas ela expirou.<br/>");
                sb.Append("b. Usuário deve acessar o Portal P2K: https://wmlink/p2k<br/>");
                sb.Append("c. Apresentará a mensagem de \"Login e/ou Senha expirado\"<br/>");
                sb.Append("d. Usuário deve clicar em OK<br/>");
                sb.Append("e. Inserir nos campos a \"Senha atual\", e a \"Nova Senha\"<br/>");
                sb.Append("<br/>");
                sb.Append("2. Troca de senha ANTES de expirar<br/>");
                sb.Append("<br/>");
                sb.Append("a. Usuário sabe qual é a sua senha e ela ainda está ativa<br/>");
                sb.Append("b. Usuário deve acessar o Portal P2K: https://wmlink/p2k<br/>");
                sb.Append("c. Para o usuário aparecerá a mensagem de que a Senha irá expirar.<br/>");
                sb.Append("d. Clicar no nome do usuário presente no canto superior direito<br/>");
                sb.Append("e. Clicar em \"Alterar Senha\".<br/>");
                sb.Append("f. Inserir nos campos a \"Senha atual\", e a \"Nova Senha\"<br/>");
                sb.Append("<br/>");
                sb.Append("3. Troca de senha porque usuário NÃO lembra qual é a sua senha<br/>");
                sb.Append("<br/>");
                sb.Append("a. Usuário não sabe qual é a sua senha e precisa trocar<br/>");
                sb.Append("b. Usuário deve ligar no helpdesk ramal 5888 e solicitar RESET de senha.<br/>");
                sb.Append("c. Após receber nova senha, deverá inserir a senha no Portal: https://wmlink/p2k<br/>");
                sb.Append("d. Aparecerá a mensagem de \"Senha Temporária\", tendo a necessidade de o usuário inserir uma nova senha.<br/>");
                sb.Append("e. Aparecerá a mensagem \"Senha Alterada com sucesso\"<br/>");
                sb.Append("f. A senha para o Portal estará atualizada no mesmo momento, para os PDVs e Assistente de Vendas descerá no próximo lote dentro de 2h (DUAS HORAS).<br/>");
                sb.Append("<br/>");
                sb.Append("<br/>");
                sb.Append("Lembrando que usuários de CASH OFFICE não precisam esperar o lote ser atualizado.<br/>");

                email.subject = string.Format(this.emailSubjectUsuario, chamado);
                email.to = to;
                email.cc = cc;
                email.bcc = bcc;
                email.body = sb.ToString();
                email.Send();

                dados.email = true;
                dados.mensagem_email = string.Empty;
            }
            catch (Exception ex)
            {
                dados.email = false;
                dados.mensagem_email = ex.Message;
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "ServiceNow.EnviaEmailUsuario" + ex.Message, true);
            }

            if (dados.email)
            {
                Log.Files(logfolder, chamado + ".log", string.Format("Date: {0}{1}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), Environment.NewLine), false);
                Log.Files(logfolder, chamado + ".log", string.Format("From: {0}{1}", email.from, Environment.NewLine), false);
                Log.Files(logfolder, chamado + ".log", string.Format("To: {0}{1}", email.to, Environment.NewLine), false);
                Log.Files(logfolder, chamado + ".log", string.Format("Subject: {0}{1}", email.subject, Environment.NewLine), false);
                Log.Files(logfolder, chamado + ".log", string.Format("{0}", Environment.NewLine), false);
                Log.Files(logfolder, chamado + ".log", string.Format("{0}", email.body.Replace("<br/>", Environment.NewLine)), false);
            }
        }

        public void EnviaEmailEscalonamento(ref Dados dados, string chamado, string name, string username, string to, string cc, string bcc)
        {
            StringBuilder sb = new StringBuilder();
            Email email = new Email();

            try
            {
                sb.Append("RESET DE SENHA P2K - LOJA FECHADA<br/>");
                sb.Append("<br/>");
                sb.AppendFormat("O usuário {0} ({1}) informou que a loja encontra-se fechada, ao solicitar o reset de senha no P2K para o usuário {2}.<br/>", name, username, dados.usuario_p2k);
                sb.Append("Por esse motivo, o chamado {0} teve sua prioridade elevada para \"Crítico\".<br/>");

                email.subject = string.Format(this.emailSubjectEscalonamento, chamado);
                email.to = to;
                email.cc = cc;
                email.bcc = bcc;
                email.body = sb.ToString();
                email.Send();

                dados.email = true;
                dados.mensagem_email = string.Empty;
            }
            catch (Exception ex)
            {
                dados.email = false;
                dados.mensagem_email = ex.Message;
                Log.Files(logfolder, DateTime.Now.ToString("yyyyMMdd") + ".log", "ServiceNow.EnviaEmailEscalonamento" + ex.Message, true);
            }

            if (dados.email)
            {
                Log.Files(logfolder, chamado + "_LOJA_FECHADA.log", string.Format("Date: {0}{1}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), Environment.NewLine), false);
                Log.Files(logfolder, chamado + "_LOJA_FECHADA.log", string.Format("From: {0}{1}", email.from, Environment.NewLine), false);
                Log.Files(logfolder, chamado + "_LOJA_FECHADA.log", string.Format("To: {0}{1}", email.to, Environment.NewLine), false);
                Log.Files(logfolder, chamado + "_LOJA_FECHADA.log", string.Format("Subject: {0}{1}", email.subject, Environment.NewLine), false);
                Log.Files(logfolder, chamado + "_LOJA_FECHADA.log", string.Format("{0}", Environment.NewLine), false);
                Log.Files(logfolder, chamado + "_LOJA_FECHADA.log", string.Format("{0}", email.body.Replace("<br/>", Environment.NewLine)), false);
            }
        }

        public UsuarioP2K GetUsuarioP2K(int codigo)
        {
            UsuarioP2K usuario = new UsuarioP2K();

            string connString = ConfigurationManager.ConnectionStrings["connP2K"].ToString();

            OracleConnection oraConn = new OracleConnection();

            if (oraConn.State != ConnectionState.Open)
            {
                try
                {
                    oraConn.ConnectionString = connString;
                    oraConn.Open();
                }
                catch (Exception ex)
                {
                    string erro = ex.Message;
                }
            }

            if (oraConn.State == ConnectionState.Open)
            {
                try
                {
                    OracleCommand cmd = new OracleCommand();
                    cmd.CommandText = "SELECT * FROM USUARIO WHERE CODIGO_USUARIO = " + codigo.ToString();
                    cmd.Connection = oraConn;
                    OracleDataReader reader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    cmd.Dispose();
                    if (dt.Rows.Count.Equals(0))
                    {
                        return null;
                    }

                    usuario = dt.DataTableToList<UsuarioP2K>().ToList().First();

                }
                catch (Exception)
                {
                    return null;
                }
            }

            return usuario;
        }

        public void Reset(ref Dados dados)
        {
            string connString = ConfigurationManager.ConnectionStrings["connP2K"].ToString();

            OracleConnection oraConn = new OracleConnection();

            if (oraConn.State != ConnectionState.Open)
            {
                try
                {
                    oraConn.ConnectionString = connString;
                    oraConn.Open();
                }
                catch (Exception ex)
                {
                    dados.reset = false;
                    dados.mensagem_reset = ex.Message;
                }
            }

            if (oraConn.State == ConnectionState.Open)
            {
                try
                {
                    string senha = new Random().Next(0, 9999).ToString("D4");

                    OracleCommand cmdUpdate = new OracleCommand();
                    cmdUpdate.CommandText = "UPDATE USUARIO SET DT_FIN_VAL_SENH = SYSDATE + 60, DATA_HORA_ALTR = SYSDATE, IN_PRIMEIRO_ACESSO = 'S', SENHA_CRIPTO = FN_CRIPTOGRAFA_SENHA('" + senha + "') WHERE CODIGO_USUARIO = " + dados.usuario_p2k.ToString();
                    cmdUpdate.Connection = oraConn;
                    cmdUpdate.ExecuteNonQuery();
                    cmdUpdate.Dispose();

                    dados.senha_p2k = senha;
                    dados.reset = true;
                    dados.mensagem_reset = string.Empty;
                }
                catch (Exception ex)
                {
                    dados.reset = false;
                    dados.mensagem_reset = ex.Message;
                }
            }
        }

        public Dados RecuperaDados(Chamado chamado)
        {
            Dados dados = new Dados();

            dados.reset_senha = RecuperarValorEntre(chamado.description, this.perguntaReset, System.Environment.NewLine).ToUpper().Trim().Equals("SIM");
            dados.loja_fechada = RecuperarValorEntre(chamado.description, this.perguntaLoja, System.Environment.NewLine).ToUpper().Trim().Equals("SIM");
            string sCodigo = RecuperarValorEntre(chamado.description, this.perguntaUsuario, System.Environment.NewLine).ToUpper().Trim();
            int iCodigo;
            int.TryParse(sCodigo, out iCodigo);
            dados.usuario_p2k = iCodigo;
            dados.nome_p2k = RecuperarValorEntre(chamado.description, this.perguntaNome, System.Environment.NewLine).ToUpper().Trim();
            dados.email_senha = RecuperarValorEntre(chamado.description, this.perguntaEmail, System.Environment.NewLine).ToLower().Trim();

            if (dados.reset_senha)
            {
                if (dados.loja_fechada)
                {
                    dados.valido = false;
                    dados.mensagem_valido = "O usuário informou que a loja encontra-se fechada, e por esse motivo o chamado não pode ser tratado de forma automática. Devido a isso, a prioridade deste chamado foi elevada para \"Crítico\".";
                }
                else
                {
                    if (dados.usuario_p2k.Equals(null) || dados.usuario_p2k.Equals(0))
                    {
                        dados.valido = false;
                        dados.mensagem_valido = "O usuário não informou um código de usuário corretamente, e por esse motivo o chamado não pode ser tratado de forma automática.";
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(dados.nome_p2k))
                        {
                            dados.valido = false;
                            dados.mensagem_valido = "O usuário não informou um nome corretamente, e por esse motivo o chamado não pode ser tratado de forma automática.";
                        }
                        else
                        {
                            dados.valido = true;
                            dados.mensagem_valido = string.Empty;
                        }
                    }
                }
            }
            else
            {
                dados.valido = false;
                dados.mensagem_valido = "O usuário não informou que deseja fazer o reset de senha do P2K, e por esse motivo o chamado não pode ser tratado de forma automática.";
            }

            return dados;
        }

        public string RecuperarValorEntre(string texto, string inicial, string final)
        {
            string resultado = string.Empty;

            int posicao_inicial = texto.IndexOf(inicial, StringComparison.InvariantCultureIgnoreCase);
            if (posicao_inicial.Equals(-1))
            {
                return resultado;
            }
            else
            {
                posicao_inicial += inicial.Length;
            }

            int posicao_final = texto.IndexOf(string.IsNullOrEmpty(final) ? System.Environment.NewLine : final, posicao_inicial, StringComparison.InvariantCultureIgnoreCase);
            if (posicao_final < posicao_inicial)
            {
                posicao_final = texto.Length;
            }

            if (posicao_inicial >= 0 && posicao_final >= 0 && posicao_final > posicao_inicial)
            {
                resultado = texto.Substring(posicao_inicial, posicao_final - posicao_inicial);
            }
            return resultado;
        }

    }

    public class Dados
    {
        public bool reset_senha { get; set; }
        public bool loja_fechada { get; set; }
        public int usuario_p2k { get; set; }
        public string nome_p2k { get; set; }
        public string email_senha { get; set; }
        public string senha_p2k { get; set; }
        public bool valido { get; set; }
        public string mensagem_valido { get; set; }
        public bool usuario { get; set; }
        public string mensagem_usuario { get; set; }
        public bool reset { get; set; }
        public string mensagem_reset { get; set; }
        public bool email { get; set; }
        public string mensagem_email { get; set; }
    }

    public class UsuarioP2K
    {
        public int CODIGO_USUARIO { get; set; }
        public int DIGITO_VERIF { get; set; }
        public string NOME { get; set; }
        public int TIPO_USUARIO { get; set; }
        public string CODIGO_PERFIL { get; set; }
        public string LOCALIDADE { get; set; }
        public string LINGUA { get; set; }
        public string PADRAO_HORA { get; set; }
        public string PADRAO_DATA { get; set; }
        public string PADRAO_NUMERO { get; set; }
        public string SEPARADOR_DECM { get; set; }
        public string SEPARADOR_GRUPO { get; set; }
        public string PADRAO_INTV { get; set; }
        public string CODIGO_EMPRESA { get; set; }
        public string NUMERO_LOJA { get; set; }
        public int TIPO_CALCULO { get; set; }
        public int SENHA_NUMERICA { get; set; }
        public DateTime DT_FIN_VAL_SENH { get; set; }
        public DateTime DT_CADASTRAMENT { get; set; }
        public DateTime DT_FINAL_VALID { get; set; }
        public int NUMERO_VERSAO { get; set; }
        public DateTime DATA_INICIO_VALIDADE { get; set; }
        public string USUARIO_INCL { get; set; }
        public DateTime DATA_HORA_INCL { get; set; }
        public string USUARIO_ALTR { get; set; }
        public DateTime DATA_HORA_ALTR { get; set; }
        public string SEPARADOR_DECIMAL { get; set; }
        public string IND_SENHA_NUMERICA { get; set; }
        public DateTime DATA_INICIAL_VAL { get; set; }
        public string CODIGO_FUNCAO { get; set; }
        public string SENHA_CRIPTO { get; set; }
        public string VENDEDOR { get; set; }
        public string COD_EMPRESA_DEF { get; set; }
        public string AREA_CAD { get; set; }
        public DateTime DATA_VALIDADE_FUNCIONAL { get; set; }
        public int NUMERO_CARTAO_FUNCIONAL { get; set; }
        public int CODIGO_TOKEN { get; set; }
        public string IN_PRIMEIRO_ACESSO { get; set; }
        public string IND_STATUS { get; set; }
        public DateTime DATA_ULTIMO_ACESSO { get; set; }
        public string NUM_IP_ORIGEM_ULTIMO_ACESSO { get; set; }
    }

}
