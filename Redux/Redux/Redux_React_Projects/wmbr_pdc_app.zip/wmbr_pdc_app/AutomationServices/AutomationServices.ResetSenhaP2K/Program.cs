﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace AutomationServices.ResetSenhaP2K
{
    static class Program
    {
        public static void Main()
        {
            if (IsDebug())
            {
                ServiceResetSenhaP2K service = new ServiceResetSenhaP2K(IsDebug());
                service.DoWork();
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new ServiceResetSenhaP2K(IsDebug()) };
                ServiceBase.Run(ServicesToRun);
            }
        }

        public static bool IsDebug()
        {
            bool retorno = true;
            #if (!DEBUG)
                retorno = false;
            #endif
            return retorno;
        }

    }
}
