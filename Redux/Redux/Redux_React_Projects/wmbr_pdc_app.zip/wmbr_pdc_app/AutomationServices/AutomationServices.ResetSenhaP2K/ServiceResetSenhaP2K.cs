﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutomationServices.Common;
using System.Configuration;

namespace AutomationServices.ResetSenhaP2K
{
    public partial class ServiceResetSenhaP2K : ServiceBase
    {
        private Thread Worker;
        //private AutoResetEvent StopRequest = new AutoResetEvent(false);
        private ManualResetEvent StopRequest = new ManualResetEvent(false);
        private volatile bool _shouldStop;
        private readonly int _timeSleep;
        public bool IsDebug;

        ResetSenhaP2K wResetSenhaP2K = new ResetSenhaP2K();

        public ServiceResetSenhaP2K(bool _IsDebug)
        {
            _timeSleep = Convert.ToInt32(ConfigurationManager.AppSettings["TimeSleep"]);
            this.IsDebug = _IsDebug;
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (!IsDebug)
            {
                Log.Event(this.ServiceName, "Serviço iniciado", false);
                Worker = new Thread(DoWork);
                Worker.Name = this.ServiceName;
                Worker.IsBackground = true;
                Worker.Start();
            }
        }

        protected override void OnStop()
        {
            _shouldStop = true;
        }

        public void DoWork()
        {
            while (!_shouldStop)
            {
                int hor_atual = DateTime.Now.Hour;
                int min_atual = DateTime.Now.Minute;

                wResetSenhaP2K.hor_atual = hor_atual;
                wResetSenhaP2K.min_atual = min_atual;
                wResetSenhaP2K.ServiceName = this.ServiceName;

                if (IsDebug)
                {
                    wResetSenhaP2K.DoWork();
                }
                else
                {
                    Thread wrkResetSenhaP2K = new Thread(wResetSenhaP2K.DoWork);
                    wrkResetSenhaP2K.Start();
                    Thread.Sleep(_timeSleep);
                    wrkResetSenhaP2K.Join();
                }
            }

            if (!IsDebug)
            {
                Worker.Join();
                Log.Event(this.ServiceName, "Serviço finalizado", false);
                StopRequest.Set();
            }
        }

    }
}
