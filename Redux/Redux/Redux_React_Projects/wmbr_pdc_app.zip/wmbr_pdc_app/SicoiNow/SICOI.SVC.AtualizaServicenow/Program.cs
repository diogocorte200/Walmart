﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace SICOI.SVC.AtualizaServicenow
{
    static class Program
    {

        static void Main()
        {
            #if (!DEBUG)

                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
                { 
                    new AtualizaServicenow() 
                };
                ServiceBase.Run(ServicesToRun);

            #else

                AtualizaServicenow service = new AtualizaServicenow();
                service.DoWork();

            #endif
        }

    }
}
