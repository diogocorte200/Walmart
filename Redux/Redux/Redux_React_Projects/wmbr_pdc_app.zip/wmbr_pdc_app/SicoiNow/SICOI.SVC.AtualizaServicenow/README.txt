﻿
TO INSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe "C:\SERVICES\SICOI.SVC.AtualizaServicenow\SICOI.SVC.AtualizaServicenow.exe"

TO UNINSTALL SERVICE:
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /u "C:\SERVICES\SICOI.SVC.AtualizaServicenow\SICOI.SVC.AtualizaServicenow.exe"


CHANGE FOLDERS TO FIT YOUR COMPUTER 