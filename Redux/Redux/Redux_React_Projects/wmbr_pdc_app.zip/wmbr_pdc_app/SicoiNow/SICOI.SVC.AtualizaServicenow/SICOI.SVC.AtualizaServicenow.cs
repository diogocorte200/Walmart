﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using SicoiNow;

namespace SICOI.SVC.AtualizaServicenow
{
    public partial class AtualizaServicenow : ServiceBase
    {
        Thread Worker;
        AutoResetEvent StopRequest = new AutoResetEvent(false);
        private volatile bool _shouldStop;

        public AtualizaServicenow()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Worker = new Thread(DoWork);
            Worker.Start();
        }

        protected override void OnStop()
        {
            _shouldStop = true;
        }

        public void DoWork()
        {
            Util.GravaEvento(this.GetServiceName(), "SERVIÇO INICIADO", false);

            string Conexao = ConfigurationManager.ConnectionStrings["conSICOI"].ConnectionString;
            string Username = ConfigurationManager.AppSettings["Username"];
            string Password = ConfigurationManager.AppSettings["Password"];
            string Domain = ConfigurationManager.AppSettings["Domain"];
            string UrlServiceNow = ConfigurationManager.AppSettings["UrlServiceNow"];
            string ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
            int ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
            int MinutesToRetryOnError = Convert.ToInt32(ConfigurationManager.AppSettings["MinutesToRetryOnError"]);

            int MinutoExecutado = -1;

            while (!_shouldStop)
            {
                Sicoi sicoi = new Sicoi(Conexao);
                ServiceNow serviceNow = new ServiceNow(Username, Password, Domain, UrlServiceNow, ProxyHost, ProxyPort, Conexao);

                bool ServicoAtivo = false;
                bool AtualizaIncidents = false;
                bool AtualizaProblems = false;
                bool AtualizaMajorIncidents = false;
                bool AtualizaRequests = false;
                DateTime UltimaAtualizacao = DateTime.Now;
                int[] MinutoExecucao = null;
                int HorasLimiteConsulta = 0;
                bool AtualizaGMT = false;
                DateTime UltimaAtualizacaoGMT = DateTime.Now.Date;
                string ServicenowTimeZone = string.Empty;
                int ServicenowGMT = 0;
                string SicoiTimeZone = string.Empty;
                int SicoiGMT = 0;
                int QtdLimiteManualRequisicao = 0;

                try
                {
                    sicoi.RecuperaParametros(ref ServicoAtivo, ref AtualizaIncidents, ref AtualizaProblems, ref AtualizaMajorIncidents,
                        ref AtualizaRequests, ref UltimaAtualizacao, ref MinutoExecucao, ref HorasLimiteConsulta, ref AtualizaGMT,
                        ref UltimaAtualizacaoGMT, ref ServicenowTimeZone, ref ServicenowGMT, ref SicoiTimeZone, ref SicoiGMT, ref QtdLimiteManualRequisicao);
                }
                catch (Exception ex)
                {
                    Util.GravaEvento(this.GetServiceName(), ex.Message, true);
                    System.Threading.Thread.Sleep(MinutesToRetryOnError * 60 * 1000);
                }

                //ServicoAtivo = true;

                if (ServicoAtivo && (AtualizaIncidents || AtualizaProblems || AtualizaMajorIncidents || AtualizaRequests))
                {
                    DateTime dtFinal = DateTime.Now;

                    if (MinutoExecucao == null || (MinutoExecucao.Contains(dtFinal.Minute) && !dtFinal.Minute.Equals(MinutoExecutado)))
                    {
                        MinutoExecutado = dtFinal.Minute;

                        if (AtualizaGMT && UltimaAtualizacaoGMT.Date != dtFinal.Date)
                        {
                            sicoi.AtualizaGMT(dtFinal, ServicenowTimeZone, ref ServicenowGMT, SicoiTimeZone, ref SicoiGMT);
                        }

                        DateTime dtInicial = UltimaAtualizacao;

                        if (dtInicial.AddHours(HorasLimiteConsulta) < dtFinal)
                        {
                            dtFinal = dtInicial.AddHours(HorasLimiteConsulta);
                        }

                        sicoi.InsereSqlLogAtualizaRemedy("INÍCIO DO PROCESSO");

                        List<Chamado> incidents = new List<Chamado>();
                        List<Chamado> major_incidents = new List<Chamado>();
                        List<Chamado> requests = new List<Chamado>();
                        List<Problem> problems = new List<Problem>();

                        if (AtualizaIncidents)
                        {
                            #region INCIDENTS

                            sicoi.InsereSqlLogAtualizaRemedy(string.Format("RECUPERAR INCIDENTS DE {0} A {1}", dtInicial.ToString("dd/MM/yyyy HH:mm:ss"), dtFinal.ToString("dd/MM/yyyy HH:mm:ss")));

                            try
                            {
                                List<string> parametrized_incidents = sicoi.ConsultaParametrizados("INC", QtdLimiteManualRequisicao);
                                incidents = serviceNow.ConsultaIncidents(dtInicial, dtFinal, ServicenowGMT, SicoiGMT, parametrized_incidents);

                                if (incidents.Count > 0)
                                {
                                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} INCIDENT(S) RECUPERADO(S) DO ServiceNow", incidents.Count.ToString()));
                                }
                                else
                                    sicoi.InsereSqlLogAtualizaRemedy("NENHUM INCIDENT RECUPERADO DO ServiceNow");
                            }
                            catch (Exception ex)
                            {
                                incidents.Clear();
                                sicoi.InsereSqlLogAtualizaRemedy("ERRO EM serviceNow.ConsultaIncidents", ex.Message);
                            }

                            if (incidents.Count > 0)
                            {
                                int processados = sicoi.GravaIncidents(incidents);
                                sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} INCIDENT(S) ATUALIZADO(S) NO SICOI", processados.ToString()));
                            }

                            #endregion INCIDENTS
                        }

                        if (AtualizaMajorIncidents)
                        {
                            #region MAJOR INCIDENTS

                            sicoi.InsereSqlLogAtualizaRemedy(string.Format("RECUPERAR MAJOR INCIDENTS DE {0} A {1}", dtInicial.ToString("dd/MM/yyyy HH:mm:ss"), dtFinal.ToString("dd/MM/yyyy HH:mm:ss")));

                            try
                            {
                                List<string> parametrized_major_incidents = sicoi.ConsultaParametrizados("MI", QtdLimiteManualRequisicao);
                                major_incidents = serviceNow.ConsultaMajorIncidents(dtInicial, dtFinal, ServicenowGMT, SicoiGMT, parametrized_major_incidents);

                                if (major_incidents.Count > 0)
                                {
                                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} MAJOR INCIDENT(S) RECUPERADO(S) DO ServiceNow", major_incidents.Count.ToString()));
                                }
                                else
                                    sicoi.InsereSqlLogAtualizaRemedy("NENHUM MAJOR INCIDENT RECUPERADO DO ServiceNow");
                            }
                            catch (Exception ex)
                            {
                                major_incidents.Clear();
                                sicoi.InsereSqlLogAtualizaRemedy("ERRO EM serviceNow.ConsultaMajorIncidents", ex.Message);
                            }

                            if (major_incidents.Count > 0)
                            {
                                int processados = sicoi.GravaIncidents(major_incidents);
                                sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} MAJOR INCIDENT(S) ATUALIZADO(S) NO SICOI", processados.ToString()));
                            }

                            #endregion MAJOR INCIDENTS
                        }

                        if (AtualizaRequests)
                        {
                            #region REQUESTS

                            sicoi.InsereSqlLogAtualizaRemedy(string.Format("RECUPERAR REQUESTS DE {0} A {1}", dtInicial.ToString("dd/MM/yyyy HH:mm:ss"), dtFinal.ToString("dd/MM/yyyy HH:mm:ss")));

                            try
                            {
                                List<string> parametrized_requests = sicoi.ConsultaParametrizados("REQ", QtdLimiteManualRequisicao);
                                requests = serviceNow.ConsultaRequests(dtInicial, dtFinal, ServicenowGMT, SicoiGMT, parametrized_requests);

                                if (requests.Count > 0)
                                {
                                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} REQUEST(S) RECUPERADO(S) DO ServiceNow", requests.Count.ToString()));
                                }
                                else
                                    sicoi.InsereSqlLogAtualizaRemedy("NENHUM REQUEST RECUPERADO DO ServiceNow");
                            }
                            catch (Exception ex)
                            {
                                requests.Clear();
                                sicoi.InsereSqlLogAtualizaRemedy("ERRO EM serviceNow.ConsultaRequests", ex.Message);
                            }

                            if (requests.Count > 0)
                            {
                                int processados = sicoi.GravaIncidents(requests);
                                sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} REQUEST(S) ATUALIZADO(S) NO SICOI", processados.ToString()));
                            }

                            #endregion REQUESTS
                        }

                        if (AtualizaProblems)
                        {
                            #region PROBLEMS

                            sicoi.InsereSqlLogAtualizaRemedy(string.Format("RECUPERAR PROBLEMS DE {0} A {1}", dtInicial.ToString("dd/MM/yyyy HH:mm:ss"), dtFinal.ToString("dd/MM/yyyy HH:mm:ss")));

                            try
                            {
                                List<string> parametrized_problems = sicoi.ConsultaParametrizados("PRB", QtdLimiteManualRequisicao);
                                problems = serviceNow.ConsultaProblems(dtInicial, dtFinal, ServicenowGMT, SicoiGMT, parametrized_problems);

                                if (requests.Count > 0)
                                {
                                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} PROBLEM(S) RECUPERADO(S) DO ServiceNow", problems.Count.ToString()));
                                }
                                else
                                    sicoi.InsereSqlLogAtualizaRemedy("NENHUM PROBLEM RECUPERADO DO ServiceNow");
                            }
                            catch (Exception ex)
                            {
                                problems.Clear();
                                sicoi.InsereSqlLogAtualizaRemedy("ERRO EM serviceNow.ConsultaProblems", ex.Message);
                            }

                            if (problems.Count > 0)
                            {
                                int processados = sicoi.GravaProblems(problems);
                                sicoi.InsereSqlLogAtualizaRemedy(string.Format("{0} PROBLEM(S) ATUALIZADO(S) NO SICOI", processados.ToString()));
                            }

                            #endregion PROBLEMS
                        }

                        if (incidents.Count + major_incidents.Count + requests.Count + problems.Count > 0)
                        {
                            try
                            {
                                sicoi.AtualizaUltimaExecucao(dtFinal);
                            }
                            catch (Exception ex)
                            {
                                sicoi.InsereSqlLogAtualizaRemedy("ERRO EM sicoi.AtualizaUltimaExecucao", ex.Message);
                            }

                            sicoi.InsereSqlLogAtualizaRemedy(string.Format("DATA DE ÚLTIMA ATUALIZAÇÃO DEFINIDA PARA {0}", dtFinal.ToString("dd/MM/yyyy HH:mm:ss")));
                        }

                        sicoi.InsereSqlLogAtualizaRemedy("TÉRMINO DO PROCESSO");
                    }
                }
            }

            Util.GravaEvento(this.GetServiceName(), "SERVIÇO FINALIZADO", false);

            #if (!DEBUG)
                StopRequest.Set();
                Worker.Join();
            #endif
        }

    }
}
