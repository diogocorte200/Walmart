﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SicoiNow
{
    public class Chamado
    {
        public string Entry_Id { get; set; }
        public DateTime? Create_Date { get; set; }
        public string Create_Time { get; set; }
        public string CreateDate { get; set; }
        public string Assigned_To { get; set; }
        public string Assigned_Team { get; set; }
        public string Requestor_Impact { get; set; }
        public string Problem_Type { get; set; }
        public string Problem_Details { get; set; }
        public string Serial_NBR { get; set; }
        public string Status { get; set; }
        public string Closed_By { get; set; }
        public DateTime? Closed_date { get; set; }
        public string Closed_Time { get; set; }
        public string Assigned_Team_NBR { get; set; }
        public DateTime? Modified_date { get; set; }
        public int? Codigo_Frente { get; set; }
        public string Contact_Location { get; set; }
        public string RMA_NBR { get; set; }
        public string Status_Description { get; set; }
        public int? Store_Dept_NBR { get; set; }
        public string Contact_Name { get; set; }
        public string Contact_Phone { get; set; }
        public string Alt_Contact_Phone { get; set; }
        public string Alt_Contact_Name { get; set; }
        public string Contact_User_ID { get; set; }
        public string Related_Rec_ID { get; set; }
        public string DepartmentNumber { get; set; }
        public string SIM_Number { get; set; }
        public string IMEI_Number { get; set; }
        public string PhoneNumberOfDevice { get; set; }
        public string Submitter { get; set; }
        public string Assisted_By { get; set; }
        public DateTime? ETA { get; set; }
        public string Vendor_Name { get; set; }
        public string Problem_Type_NBR { get; set; }

        public List<ChamadoLog> logs { get; set; }

        public bool manual { get; set; }
    }
}
