﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;
using System.Data.SqlClient;
using System.Net;
using System.IO;

namespace SicoiNow
{
    public static class Util
    {
        public static void GravaEvento(string source, string message, bool iserror)
        {
            using (EventLog eventLog = new EventLog("Application"))
            {
                eventLog.Source = source;
                eventLog.WriteEntry(message, iserror ? EventLogEntryType.Error : EventLogEntryType.Information);
            }
        }


        public static int GetGMT(string timezone)
        {
            int gmt = 0;
            var timeZone = TimeZoneInfo.FindSystemTimeZoneById(timezone);
            gmt = timeZone.GetUtcOffset(DateTime.Now).Hours;
            return gmt;
        }


        public static int GetGMT(decimal latitude, decimal logitude)
        {
            DateTime ini = new DateTime(1970, 1, 1, 0, 0, 0);
            int dif = (int)(DateTime.Now - ini).TotalSeconds;

            string cadeiaInicial;
            string cadeiaFinal;
            int inicio;
            int termino;

            string resultado = GET(string.Format("https://maps.googleapis.com/maps/api/timezone/json?location={0},{1}&timestamp={2}", latitude.ToString().Replace(",", "."), logitude.ToString().Replace(",", "."), dif.ToString()));

            int rawOffset;
            cadeiaInicial = "\"rawOffset\" :";
            cadeiaFinal = ",\n";
            inicio = resultado.IndexOf(cadeiaInicial) + cadeiaInicial.Length;
            termino = resultado.IndexOf(cadeiaFinal, inicio);
            rawOffset = Convert.ToInt32(resultado.Substring(inicio, termino - inicio));

            int dstOffset;
            cadeiaInicial = "\"dstOffset\" :";
            cadeiaFinal = ",\n";
            inicio = resultado.IndexOf(cadeiaInicial) + cadeiaInicial.Length;
            termino = resultado.IndexOf(cadeiaFinal, inicio);
            dstOffset = Convert.ToInt32(resultado.Substring(inicio, termino - inicio));

            int Offset = rawOffset + dstOffset;

            return (Offset / 3600);
        }

        public static string GET(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    return reader.ReadToEnd();
                }
            }
            catch (WebException ex)
            {
                WebResponse errorResponse = ex.Response;
                using (Stream responseStream = errorResponse.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.GetEncoding("utf-8"));
                    String errorText = reader.ReadToEnd();
                    // log errorText
                }
                throw;
            }
        }

    }
}
