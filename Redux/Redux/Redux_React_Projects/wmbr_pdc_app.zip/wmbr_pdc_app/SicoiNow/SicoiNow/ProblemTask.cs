﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SicoiNow
{
    public class ProblemTask
    {
        public string problem { get; set; }
        public string number { get; set; }
        public string short_description { get; set; }
        public string description { get; set; }
        public bool? active { get; set; }
        public string state { get; set; }
        public string impact { get; set; }
        public string priority { get; set; }
        public string urgency { get; set; }
        public string opened_by_user { get; set; }
        public string opened_by_name { get; set; }
        public DateTime? opened_at { get; set; }
        public string assignment_group_id { get; set; }
        public string assignment_group_description { get; set; }
        public string assigned_to_user { get; set; }
        public string assigned_to_name { get; set; }
        public string assigned_to_email { get; set; }
        public DateTime? sys_updated_on { get; set; }
        public string sys_class_name { get; set; }
        public string approval { get; set; }
        public DateTime? expected_start { get; set; }
        public DateTime? due_date { get; set; }
        public string escalation { get; set; }
        public string closed_by_user { get; set; }
        public string closed_by_name { get; set; }
        public DateTime? closed_at { get; set; }
    }
}
