﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SicoiNow
{
    public class Problem
    {
        public string number { get; set; }
        public string short_description { get; set; }
        public string u_executive_summary { get; set; }
        public string description { get; set; }
        public string u_knowledge_id { get; set; }
        public string u_knowledge_description { get; set; }
        public string assignment_group_id { get; set; }
        public string assignment_group_description { get; set; }
        public string opened_by { get; set; }
        public DateTime? opened_at { get; set; }
        public DateTime? sys_updated_on { get; set; }
        public string assigned_to { get; set; }
        public bool? active { get; set; }
        public string state { get; set; }
        public string impact { get; set; }
        public string priority { get; set; }
        public string urgency { get; set; }
        public string u_root_cause { get; set; }
        public string u_close_code { get; set; }
        public string u_two_word_root_cause { get; set; }
        public string closed_by { get; set; }
        public DateTime? closed_at { get; set; }

        public List<ProblemTask> tasks { get; set; }

        public bool manual { get; set; }
    }
}
