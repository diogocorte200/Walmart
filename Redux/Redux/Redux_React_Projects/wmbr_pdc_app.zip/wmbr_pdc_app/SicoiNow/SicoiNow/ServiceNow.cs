﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Globalization;

namespace SicoiNow
{
    public class ServiceNow
    {
        private string Username { get; set; }
        private string Password { get; set; }
        private string Domain { get; set; }
        private string UrlServiceNow { get; set; }
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ConexaoSicoi { get; set; }

        public ServiceNow(string Username, string Password, string Domain, string UrlServiceNow, string ProxyHost, int ProxyPort, string ConexaoSicoi)
        {
            this.Username = Username;
            this.Password = Password;
            this.Domain = Domain;
            this.UrlServiceNow = UrlServiceNow;
            this.ProxyHost = ProxyHost;
            this.ProxyPort = ProxyPort;
            this.ConexaoSicoi = ConexaoSicoi;
        }

        public List<Chamado> ConsultaIncidents(DateTime dtInicial, DateTime dtFinal, int ServicenowGMT, int SicoiGMT, List<string> listas = null)
        {
            List<Chamado> result = new List<Chamado>();
            List<Chamado> incidents = new List<Chamado>();

            try
            {
                dtInicial = dtInicial.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);
                dtFinal = dtFinal.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);

                string txtDataInicial = dtInicial.ToString("yyyy-MM-dd");
                string txtHoraInicial = dtInicial.ToString("HH:mm:ss");
                string txtDataFinal = dtFinal.ToString("yyyy-MM-dd");
                string txtHoraFinal = dtFinal.ToString("HH:mm:ss");

                string query = string.Empty;
                string requestUrl = string.Empty;
                string json = string.Empty;

                string url = "api/now/table/incident?GET&sysparm_display_value=true";

                List<string> colunas = new List<string>();
                colunas.Add("number");
                colunas.Add("opened_at");
                colunas.Add("opened_by.user_name");
                colunas.Add("opened_by.name");
                colunas.Add("sys_updated_on");
                colunas.Add("resolved_at");
                colunas.Add("resolved_by.user_name");
                colunas.Add("resolved_by.name");
                colunas.Add("assigned_to.user_name");
                colunas.Add("assigned_to.name");
                colunas.Add("assigned_to.email");
                colunas.Add("assignment_group.sys_id");
                colunas.Add("assignment_group.name");
                colunas.Add("impact");
                colunas.Add("priority");
                colunas.Add("urgency");
                colunas.Add("severity");
                colunas.Add("short_description");
                colunas.Add("description");
                colunas.Add("u_serial_number");
                colunas.Add("u_department.code");
                colunas.Add("u_department.name");
                colunas.Add("state");
                colunas.Add("caller_id.user_name");
                colunas.Add("caller_id.name");
                colunas.Add("caller_id.email");
                colunas.Add("caller_id.phone");
                colunas.Add("caller_id.department.code");
                colunas.Add("caller_id.department.name");
                colunas.Add("u_knowledge_id.number");
                colunas.Add("comments_and_work_notes");
                colunas.Add("u_workaround");

                StringBuilder q1 = new StringBuilder();
                q1.Append(url);
                q1.Append("&sysparm_query=u_department.codeLIKEBR");
                q1.Append("^assignment_group.parent.sys_id!=92dbf613db004700e55df5871d9619b6");
                q1.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q1.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q1.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    incidents.AddRange(ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q2 = new StringBuilder();
                q2.Append(url);
                q2.Append("&sysparm_query=assignment_groupSTARTSWITHBR");
                q1.Append("^assignment_group.parent.sys_id!=92dbf613db004700e55df5871d9619b6");
                q2.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q2.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q2.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    incidents.AddRange(ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q3 = new StringBuilder();
                q3.Append(url);
                q3.Append("&sysparm_query=u_knowledge_id.u_article_owner.nameSTARTSWITHBR");
                q1.Append("^assignment_group.parent.sys_id!=92dbf613db004700e55df5871d9619b6");
                q3.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q3.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q3.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    incidents.AddRange(ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q4 = new StringBuilder();
                q4.Append(url);
                q4.Append("&sysparm_query=u_department.codeLIKEBR");
                q1.Append("^assignment_group.parent.sys_id!=92dbf613db004700e55df5871d9619b6");
                q4.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q4.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q4.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    incidents.AddRange(ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q5 = new StringBuilder();
                q5.Append(url);
                q5.Append("&sysparm_query=assignment_groupSTARTSWITHBR");
                q1.Append("^assignment_group.parent.sys_id!=92dbf613db004700e55df5871d9619b6");
                q5.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q5.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q5.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    incidents.AddRange(ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q6 = new StringBuilder();
                q6.Append(url);
                q6.Append("&sysparm_query=u_knowledge_id.u_article_owner.nameSTARTSWITHBR");
                q1.Append("^assignment_group.parent.sys_id!=92dbf613db004700e55df5871d9619b6");
                q6.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q6.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q6.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    incidents.AddRange(ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q7 = new StringBuilder();
                foreach (string lista in listas)
                {
                    q7.Clear();
                    q7.Append(url);
                    q7.AppendFormat("&sysparm_query=numberIN" + lista);
                    q7.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                    requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q7.ToString());
                    json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                    if (!string.IsNullOrEmpty(json))
                    {
                        DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                        List<Chamado> manual_incidents = ConverteListaIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT);
                        manual_incidents.ForEach(i => i.manual = true);
                        incidents.AddRange(manual_incidents);
                    }
                }

                result.Clear();
                result = incidents.GroupBy(i => new { i.Entry_Id, i.Create_Date, i.Modified_date }).Select(i => i.FirstOrDefault()).ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public List<Chamado> ConsultaMajorIncidents(DateTime dtInicial, DateTime dtFinal, int ServicenowGMT, int SicoiGMT, List<string> listas = null)
        {
            List<Chamado> result = new List<Chamado>();
            List<Chamado> major_incidents = new List<Chamado>();

            try
            {
                dtInicial = dtInicial.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);
                dtFinal = dtFinal.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);

                string txtDataInicial = dtInicial.ToString("yyyy-MM-dd");
                string txtHoraInicial = dtInicial.ToString("HH:mm:ss");
                string txtDataFinal = dtFinal.ToString("yyyy-MM-dd");
                string txtHoraFinal = dtFinal.ToString("HH:mm:ss");

                string query = string.Empty;
                string requestUrl = string.Empty;
                string json = string.Empty;

                string url = "api/now/table/ticket?GET&sysparm_display_value=true";

                List<string> colunas = new List<string>();
                colunas.Add("number");
                colunas.Add("opened_at");
                colunas.Add("opened_by.user_name");
                colunas.Add("opened_by.name");
                colunas.Add("opened_by.email");
                colunas.Add("opened_by.phone");
                colunas.Add("opened_by.department.code");
                colunas.Add("opened_by.department.name");
                colunas.Add("u_source_incident.number");
                colunas.Add("sys_updated_on");
                colunas.Add("closed_at");
                colunas.Add("closed_by.user_name");
                colunas.Add("closed_by.name");
                colunas.Add("assigned_to.user_name");
                colunas.Add("assigned_to.name");
                colunas.Add("assigned_to.email");
                colunas.Add("assignment_group.sys_id");
                colunas.Add("assignment_group.name");
                colunas.Add("impact");
                colunas.Add("priority");
                colunas.Add("urgency");
                colunas.Add("severity");
                colunas.Add("short_description");
                colunas.Add("description");
                colunas.Add("u_source_incident.u_department.code");
                colunas.Add("u_source_incident.u_department.name");
                colunas.Add("state");
                colunas.Add("u_source_incident.caller_id.user_name");
                colunas.Add("u_source_incident.caller_id.name");
                colunas.Add("u_source_incident.caller_id.email");
                colunas.Add("u_source_incident.caller_id.phone");
                colunas.Add("u_source_incident.caller_id.department.code");
                colunas.Add("u_source_incident.caller_id.department.name");
                colunas.Add("u_knowledge_id.number");
                colunas.Add("u_knowledge_id.short_description");
                colunas.Add("comments_and_work_notes");

                StringBuilder q1 = new StringBuilder();
                q1.Append(url);
                q1.Append("&sysparm_query=u_source_incident.u_department.codeLIKEBR");
                q1.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q1.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q1.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    major_incidents.AddRange(ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q2 = new StringBuilder();
                q2.Append(url);
                q2.Append("&sysparm_query=assignment_group.nameSTARTSWITHBR");
                q2.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q2.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q2.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    major_incidents.AddRange(ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q3 = new StringBuilder();
                q3.Append(url);
                q3.Append("&sysparm_query=u_knowledge_id.u_article_owner.nameSTARTSWITHBR");
                q3.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q3.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q3.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    major_incidents.AddRange(ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q4 = new StringBuilder();
                q4.Append(url);
                q4.Append("&sysparm_query=u_source_incident.u_department.codeLIKEBR");
                q4.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q4.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q4.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    major_incidents.AddRange(ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q5 = new StringBuilder();
                q5.Append(url);
                q5.Append("&sysparm_query=assignment_group.nameSTARTSWITHBR");
                q5.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q5.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q5.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    major_incidents.AddRange(ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q6 = new StringBuilder();
                q6.Append(url);
                q6.Append("&sysparm_query=u_knowledge_id.u_article_owner.nameSTARTSWITHBR");
                q6.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q6.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q6.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    major_incidents.AddRange(ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q7 = new StringBuilder();
                foreach (string lista in listas)
                {
                    q7.Clear();
                    q7.Append(url);
                    q7.AppendFormat("&sysparm_query=numberIN" + lista);
                    q7.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                    requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q7.ToString());
                    json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                    if (!string.IsNullOrEmpty(json))
                    {
                        DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                        List<Chamado> manual_majoir_incidents = ConverteListaMajorIncidents(dados.Tables["result"], ServicenowGMT, SicoiGMT);
                        manual_majoir_incidents.ForEach(i => i.manual = true);
                        major_incidents.AddRange(manual_majoir_incidents);
                    }
                }

                result.Clear();
                result = major_incidents.GroupBy(i => new { i.Entry_Id, i.Create_Date, i.Modified_date }).Select(i => i.FirstOrDefault()).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public List<Chamado> ConsultaRequests(DateTime dtInicial, DateTime dtFinal, int ServicenowGMT, int SicoiGMT, List<string> listas = null)
        {
            List<Chamado> result = new List<Chamado>();
            List<Chamado> requests = new List<Chamado>();

            try
            {
                dtInicial = dtInicial.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);
                dtFinal = dtFinal.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);

                string txtDataInicial = dtInicial.ToString("yyyy-MM-dd");
                string txtHoraInicial = dtInicial.ToString("HH:mm:ss");
                string txtDataFinal = dtFinal.ToString("yyyy-MM-dd");
                string txtHoraFinal = dtFinal.ToString("HH:mm:ss");

                string query = string.Empty;
                string requestUrl = string.Empty;
                string json = string.Empty;

                string url = "api/now/table/sc_task?GET&sysparm_display_value=true";

                List<string> colunas = new List<string>();
                colunas.Add("request.number");
                colunas.Add("number");
                colunas.Add("request.opened_at");
                colunas.Add("request.opened_by.user_name");
                colunas.Add("request.opened_by.name");
                colunas.Add("request.opened_by.email");
                colunas.Add("request.opened_by.phone");
                colunas.Add("request.opened_by.department.code");
                colunas.Add("request.opened_by.department.name");
                colunas.Add("sys_updated_on");
                colunas.Add("request.closed_at");
                colunas.Add("request.closed_by.user_name");
                colunas.Add("request.closed_by.name");
                colunas.Add("assigned_to.user_name");
                colunas.Add("assigned_to.name");
                colunas.Add("assigned_to.email");
                colunas.Add("assignment_group.sys_id");
                colunas.Add("assignment_group.name");
                colunas.Add("request.requested_for.user_name");
                colunas.Add("request.requested_for.name");
                colunas.Add("request.requested_for.phone");
                colunas.Add("request.requested_for.department.code");
                colunas.Add("impact");
                colunas.Add("priority");
                colunas.Add("urgency");
                colunas.Add("short_description");
                colunas.Add("description");
                colunas.Add("state");
                colunas.Add("u_knowledge_id.number");
                colunas.Add("comments_and_work_notes");

                StringBuilder q1 = new StringBuilder();
                q1.Append(url);
                q1.Append("&sysparm_query=request.requested_for.department.codeLIKEBR");
                q1.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q1.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q1.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    requests.AddRange(ConverteListaRequests(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q2 = new StringBuilder();
                q2.Append(url);
                q2.Append("&sysparm_query=assignment_groupSTARTSWITHBR");
                q2.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q2.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q2.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    requests.AddRange(ConverteListaRequests(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q3 = new StringBuilder();
                q3.Append(url);
                q3.Append("&sysparm_query=request.requested_for.department.codeLIKEBR");
                q3.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q3.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q3.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    requests.AddRange(ConverteListaRequests(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q4 = new StringBuilder();
                q4.Append(url);
                q4.Append("&sysparm_query=assignment_groupSTARTSWITHBR");
                q4.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q4.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q4.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    requests.AddRange(ConverteListaRequests(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q5 = new StringBuilder();
                foreach (string lista in listas)
                {
                    q5.Clear();
                    q5.Append(url);
                    q5.AppendFormat("&sysparm_query=request.numberIN" + lista);
                    q5.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                    requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q5.ToString());
                    json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                    if (!string.IsNullOrEmpty(json))
                    {
                        DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                        List<Chamado> manual_requests = ConverteListaRequests(dados.Tables["result"], ServicenowGMT, SicoiGMT);
                        manual_requests.ForEach(i => i.manual = true);
                        requests.AddRange(manual_requests);
                    }
                }

                result.Clear();
                result = requests.GroupBy(i => new { i.Entry_Id, i.Create_Date, i.Modified_date }).Select(i => i.FirstOrDefault()).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public List<Problem> ConsultaProblems(DateTime dtInicial, DateTime dtFinal, int ServicenowGMT, int SicoiGMT, List<string> listas = null)
        {
            List<Problem> result = new List<Problem>();
            List<Problem> problems = new List<Problem>();

            try
            {
                dtInicial = dtInicial.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);
                dtFinal = dtFinal.AddHours(SicoiGMT * -1).AddHours(ServicenowGMT);

                string txtDataInicial = dtInicial.ToString("yyyy-MM-dd");
                string txtHoraInicial = dtInicial.ToString("HH:mm:ss");
                string txtDataFinal = dtFinal.ToString("yyyy-MM-dd");
                string txtHoraFinal = dtFinal.ToString("HH:mm:ss");

                string query = string.Empty;
                string requestUrl = string.Empty;
                string json = string.Empty;

                string url = "api/now/table/problem?GET&sysparm_display_value=true";

                List<string> colunas = new List<string>();
                colunas.Add("sys_id");
                colunas.Add("number");
                colunas.Add("short_description");
                colunas.Add("u_executive_summary");
                colunas.Add("description");
                colunas.Add("u_knowledge_id.number");
                colunas.Add("u_knowledge_id.short_description");
                colunas.Add("assignment_group.sys_id");
                colunas.Add("assignment_group.name");
                colunas.Add("opened_by.user_name");
                colunas.Add("opened_by.name");
                colunas.Add("opened_at");
                colunas.Add("sys_updated_on");
                colunas.Add("assigned_to.user_name");
                colunas.Add("assigned_to.name");
                colunas.Add("assigned_to.email");
                colunas.Add("active");
                colunas.Add("state");
                colunas.Add("impact");
                colunas.Add("priority");
                colunas.Add("urgency");
                colunas.Add("u_root_cause");
                colunas.Add("u_close_code");
                colunas.Add("u_two_word_root_cause");
                colunas.Add("closed_by.user_name");
                colunas.Add("closed_by.name");
                colunas.Add("closed_at");

                StringBuilder q1 = new StringBuilder();
                q1.Append(url);
                q1.Append("&sysparm_query=assignment_groupSTARTSWITHBR");
                q1.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q1.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q1.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    problems.AddRange(ConverteListaProblems(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q2 = new StringBuilder();
                q2.Append(url);
                q2.Append("&sysparm_query=u_knowledge_id.u_article_owner.nameSTARTSWITHBR");
                q2.AppendFormat("^opened_atBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q2.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q2.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    problems.AddRange(ConverteListaProblems(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q3 = new StringBuilder();
                q3.Append(url);
                q3.Append("&sysparm_query=assignment_groupSTARTSWITHBR");
                q3.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q3.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q3.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    problems.AddRange(ConverteListaProblems(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q4 = new StringBuilder();
                q4.Append(url);
                q4.Append("&sysparm_query=u_knowledge_id.u_article_owner.nameSTARTSWITHBR");
                q4.AppendFormat("^sys_updated_onBETWEENjavascript:gs.dateGenerate('{0}','{1}')@javascript:gs.dateGenerate('{2}','{3}')", txtDataInicial, txtHoraInicial, txtDataFinal, txtHoraFinal);
                q4.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q4.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    problems.AddRange(ConverteListaProblems(dados.Tables["result"], ServicenowGMT, SicoiGMT));
                }

                StringBuilder q5 = new StringBuilder();
                foreach (string lista in listas)
                {
                    q5.Clear();
                    q5.Append(url);
                    q5.AppendFormat("&sysparm_query=numberIN" + lista);
                    q5.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));
                    requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q5.ToString());
                    json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                    if (!string.IsNullOrEmpty(json))
                    {
                        DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                        List<Problem> manual_problems = ConverteListaProblems(dados.Tables["result"], ServicenowGMT, SicoiGMT);
                        manual_problems.ForEach(i => i.manual = true);
                        problems.AddRange(manual_problems);
                    }
                }

                result.Clear();
                result = problems.GroupBy(i => new { i.number, i.opened_at, i.sys_updated_on }).Select(i => i.FirstOrDefault()).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public List<ProblemTask> ConsultaProblemTasks(string sys_id, int ServicenowGMT, int SicoiGMT)
        {
            List<ProblemTask> tasks = new List<ProblemTask>();

            try
            {
                string query = string.Empty;
                string requestUrl = string.Empty;
                string json = string.Empty;

                StringBuilder q = new StringBuilder();
                q.Append("api/now/table/problem_task");
                q.Append("?GET");
                q.AppendFormat("&sysparm_display_value=true"); // FOR VALUE AND DISPLAY VALUE

                List<string> colunas = new List<string>();
                colunas.Add("problem.number");
                colunas.Add("number");
                colunas.Add("short_description");
                colunas.Add("description");
                colunas.Add("sys_class_name");
                colunas.Add("state");
                colunas.Add("sys_created_by");
                colunas.Add("impact");
                colunas.Add("urgency");
                colunas.Add("active");
                colunas.Add("approval");
                colunas.Add("priority");
                colunas.Add("expected_start");
                colunas.Add("due_date");
                colunas.Add("escalation");
                colunas.Add("opened_at");
                colunas.Add("sys_created_on");
                colunas.Add("sys_updated_on");
                colunas.Add("sys_updated_by");
                colunas.Add("opened_by.user_name");
                colunas.Add("opened_by.name");
                colunas.Add("assignment_group.sys_id");
                colunas.Add("assignment_group.name");
                colunas.Add("assigned_to.user_name");
                colunas.Add("assigned_to.name");
                colunas.Add("assigned_to.email");
                colunas.Add("closed_by.user_name");
                colunas.Add("closed_by.name");
                colunas.Add("closed_at");

                q.AppendFormat("&sysparm_query=problem.sys_id={0}", sys_id);

                q.AppendFormat("&sysparm_fields={0}", String.Join(",", colunas));

                requestUrl = string.Format("{0}/{1}", this.UrlServiceNow, q.ToString());
                json = CallRestMethod(requestUrl, this.ProxyHost, this.ProxyPort, this.Username, this.Password, this.Domain);
                if (!string.IsNullOrEmpty(json))
                {
                    DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                    tasks = ConverteListaTasks(dados.Tables["result"], ServicenowGMT, SicoiGMT);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return tasks;
        }

        public List<Chamado> ConverteListaIncidents(DataTable tabela, int ServicenowGMT, int SicoiGMT)
        {
            List<Chamado> incidents = new List<Chamado>();

            foreach (DataRow registro in tabela.Rows)
            {
                Chamado incident = new Chamado();
                try
                {
                    incident.Entry_Id = PadronizaTexto(registro["number"].ToString());
                    incident.Create_Date = PadronizaDataHoraSicoi(registro["opened_at"].ToString(), ServicenowGMT, SicoiGMT);
                    incident.Create_Time = PadronizaTexto(incident.Create_Date == null ? null : Convert.ToDateTime(incident.Create_Date).ToString("HH:mm"));
                    incident.CreateDate = PadronizaTexto(incident.Create_Date == null ? null : Convert.ToDateTime(incident.Create_Date).ToString("yyyy/MM/dd"));
                    incident.Assigned_To = PadronizaTexto(registro["assigned_to.name"].ToString());
                    incident.Assigned_Team = PadronizaTexto(registro["assignment_group.name"].ToString());
                    incident.Requestor_Impact = PadronizaTexto(registro["priority"].ToString());
                    incident.Problem_Type = PadronizaTexto(registro["short_description"].ToString());
                    incident.Problem_Details = PadronizaTexto(registro["description"].ToString());
                    incident.Serial_NBR = PadronizaTexto(registro["u_serial_number"].ToString());
                    incident.Status = PadronizaTexto(registro["state"].ToString());
                    incident.Closed_By = PadronizaTexto(registro["resolved_by.user_name"].ToString());
                    incident.Closed_date = PadronizaDataHoraSicoi(registro["resolved_at"].ToString(), ServicenowGMT, SicoiGMT);
                    incident.Closed_Time = PadronizaTexto(incident.Closed_date == null ? null : Convert.ToDateTime(incident.Closed_date).ToString("HH:mm"));
                    incident.Assigned_Team_NBR = PadronizaTexto(registro["assignment_group.sys_id"].ToString());
                    incident.Modified_date = PadronizaDataHoraSicoi(registro["sys_updated_on"].ToString(), ServicenowGMT, SicoiGMT);
                    incident.Codigo_Frente = 0;
                    incident.Contact_Location = PadronizaTexto(registro["caller_id.department.code"].ToString());
                    incident.RMA_NBR = null;
                    incident.Status_Description = string.IsNullOrEmpty(PadronizaTexto(registro["u_workaround"].ToString())) ? null : PadronizaTexto(registro["u_workaround"].ToString()).Length <= 250 ? PadronizaTexto(registro["u_workaround"].ToString()) : PadronizaTexto(registro["u_workaround"].ToString()).Substring(0, 250);
                    incident.Store_Dept_NBR = null;
                    incident.Contact_Name = PadronizaTexto(registro["caller_id.name"].ToString());
                    incident.Contact_Phone = PadronizaTexto(registro["caller_id.phone"].ToString());
                    incident.Alt_Contact_Phone = null;
                    incident.Alt_Contact_Name = null;
                    incident.Contact_User_ID = PadronizaTexto(registro["caller_id.user_name"].ToString());
                    incident.Related_Rec_ID = null;
                    incident.DepartmentNumber = PadronizaTexto(registro["u_department.code"].ToString());
                    incident.SIM_Number = null;
                    incident.IMEI_Number = null;
                    incident.PhoneNumberOfDevice = null;
                    incident.Submitter = PadronizaTexto(registro["opened_by.user_name"].ToString());
                    incident.Assisted_By = null;
                    incident.ETA = null;
                    incident.Vendor_Name = null;
                    incident.Problem_Type_NBR = PadronizaTexto(registro["u_knowledge_id.number"].ToString());
                    incident.logs = ListChamadoLogs(registro["number"].ToString(), registro["comments_and_work_notes"].ToString(), ServicenowGMT, SicoiGMT);

                    incidents.Add(incident);
                }
                catch (Exception ex)
                {
                    Sicoi sicoi = new Sicoi(this.ConexaoSicoi);
                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("ERRO EM ServiceNow.ConverteListaIncidents: {0} - {1}", incident.Entry_Id, ex.Message));
                }
            }

            return incidents;
        }

        public List<Chamado> ConverteListaMajorIncidents(DataTable tabela, int ServicenowGMT, int SicoiGMT)
        {
            List<Chamado> major_incidents = new List<Chamado>();

            foreach (DataRow registro in tabela.Rows)
            {
                Chamado major_incident = new Chamado();
                try
                {
                    major_incident.Entry_Id = PadronizaTexto(registro["number"].ToString());
                    major_incident.Create_Date = PadronizaDataHoraSicoi(registro["opened_at"].ToString(), ServicenowGMT, SicoiGMT);
                    major_incident.Create_Time = PadronizaTexto(major_incident.Create_Date == null ? null : Convert.ToDateTime(major_incident.Create_Date).ToString("HH:mm"));
                    major_incident.CreateDate = PadronizaTexto(major_incident.Create_Date == null ? null : Convert.ToDateTime(major_incident.Create_Date).ToString("yyyy/MM/dd"));
                    major_incident.Assigned_To = PadronizaTexto(registro["assigned_to.name"].ToString());
                    major_incident.Assigned_Team = PadronizaTexto(registro["assignment_group.name"].ToString());
                    major_incident.Requestor_Impact = PadronizaTexto(registro["impact"].ToString());
                    major_incident.Problem_Type = PadronizaTexto(registro["u_knowledge_id.short_description"].ToString());
                    major_incident.Problem_Details = PadronizaTexto(registro["description"].ToString());
                    major_incident.Serial_NBR = null;
                    major_incident.Status = PadronizaTexto(registro["state"].ToString());
                    major_incident.Closed_By = PadronizaTexto(registro["closed_by.user_name"].ToString());
                    major_incident.Closed_date = PadronizaDataHoraSicoi(registro["closed_at"].ToString(), ServicenowGMT, SicoiGMT);
                    major_incident.Closed_Time = PadronizaTexto(major_incident.Closed_date == null ? null : Convert.ToDateTime(major_incident.Closed_date).ToString("HH:mm"));
                    major_incident.Assigned_Team_NBR = PadronizaTexto(registro["assignment_group.sys_id"].ToString());
                    major_incident.Modified_date = PadronizaDataHoraSicoi(registro["sys_updated_on"].ToString(), ServicenowGMT, SicoiGMT);
                    major_incident.Codigo_Frente = 0;
                    major_incident.Contact_Location = PadronizaTexto(registro["u_source_incident.caller_id.department.code"].ToString());
                    major_incident.RMA_NBR = null;
                    major_incident.Status_Description = null;
                    major_incident.Store_Dept_NBR = null;
                    major_incident.Contact_Name = PadronizaTexto(registro["u_source_incident.caller_id.name"].ToString());
                    major_incident.Contact_Phone = PadronizaTexto(registro["u_source_incident.caller_id.phone"].ToString());
                    major_incident.Alt_Contact_Phone = null;
                    major_incident.Alt_Contact_Name = null;
                    major_incident.Contact_User_ID = PadronizaTexto(registro["u_source_incident.caller_id.user_name"].ToString());
                    major_incident.Related_Rec_ID = PadronizaTexto(registro["u_source_incident.number"].ToString());
                    major_incident.DepartmentNumber = null;
                    major_incident.SIM_Number = null;
                    major_incident.IMEI_Number = null;
                    major_incident.PhoneNumberOfDevice = null;
                    major_incident.Submitter = PadronizaTexto(registro["opened_by.user_name"].ToString());
                    major_incident.Assisted_By = null;
                    major_incident.ETA = null;
                    major_incident.Vendor_Name = null;
                    major_incident.Problem_Type_NBR = PadronizaTexto(registro["u_knowledge_id.number"].ToString());
                    major_incident.logs = ListChamadoLogs(registro["number"].ToString(), registro["comments_and_work_notes"].ToString(), ServicenowGMT, SicoiGMT);

                    major_incidents.Add(major_incident);
                }
                catch (Exception ex)
                {
                    Sicoi sicoi = new Sicoi(this.ConexaoSicoi);
                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("ERRO EM ServiceNow.ConverteListaMajorIncidents: {0} - {1}", major_incident.Entry_Id, ex.Message));
                }
            }

            return major_incidents;
        }

        public List<Chamado> ConverteListaRequests(DataTable tabela, int ServicenowGMT, int SicoiGMT)
        {
            List<Chamado> requests = new List<Chamado>();

            foreach (DataRow registro in tabela.Rows)
            {
                Chamado request = new Chamado();
                try
                {
                    request.Entry_Id = PadronizaTexto(registro["request.number"].ToString());
                    request.Create_Date = PadronizaDataHoraSicoi(registro["request.opened_at"].ToString(), ServicenowGMT, SicoiGMT);
                    request.Create_Time = PadronizaTexto(request.Create_Date == null ? null : Convert.ToDateTime(request.Create_Date).ToString("HH:mm"));
                    request.CreateDate = PadronizaTexto(request.Create_Date == null ? null : Convert.ToDateTime(request.Create_Date).ToString("yyyy/MM/dd"));
                    request.Assigned_To = PadronizaTexto(registro["assigned_to.name"].ToString());
                    request.Assigned_Team = PadronizaTexto(registro["assignment_group.name"].ToString());
                    request.Requestor_Impact = PadronizaTexto(registro["impact"].ToString());
                    request.Problem_Type = PadronizaTexto(registro["short_description"].ToString());
                    request.Problem_Details = PadronizaTexto(registro["description"].ToString());
                    request.Serial_NBR = null;
                    request.Status = PadronizaTexto(registro["state"].ToString());
                    request.Closed_By = PadronizaTexto(registro["request.closed_by.user_name"].ToString());
                    request.Closed_date = PadronizaDataHoraSicoi(registro["request.closed_at"].ToString(), ServicenowGMT, SicoiGMT);
                    request.Closed_Time = PadronizaTexto(request.Closed_date == null ? null : Convert.ToDateTime(request.Closed_date).ToString("HH:mm"));
                    request.Assigned_Team_NBR = PadronizaTexto(registro["assignment_group.sys_id"].ToString());
                    request.Modified_date = PadronizaDataHoraSicoi(registro["sys_updated_on"].ToString(), ServicenowGMT, SicoiGMT);
                    request.Codigo_Frente = 0;
                    request.Contact_Location = PadronizaTexto(registro["request.requested_for.department.code"].ToString());
                    request.RMA_NBR = null;
                    request.Status_Description = null;
                    request.Store_Dept_NBR = null;
                    request.Contact_Name = PadronizaTexto(registro["request.requested_for.name"].ToString());
                    request.Contact_Phone = PadronizaTexto(registro["request.requested_for.phone"].ToString());
                    request.Alt_Contact_Phone = null;
                    request.Alt_Contact_Name = null;
                    request.Contact_User_ID = PadronizaTexto(registro["request.requested_for.user_name"].ToString());
                    request.Related_Rec_ID = PadronizaTexto(registro["number"].ToString());
                    request.DepartmentNumber = PadronizaTexto(registro["request.requested_for.department.code"].ToString());
                    request.SIM_Number = null;
                    request.IMEI_Number = null;
                    request.PhoneNumberOfDevice = null;
                    request.Submitter = PadronizaTexto(registro["request.opened_by.user_name"].ToString());
                    request.Assisted_By = null;
                    request.ETA = null;
                    request.Vendor_Name = null;
                    request.Problem_Type_NBR = PadronizaTexto(registro["u_knowledge_id.number"].ToString());
                    request.logs = ListChamadoLogs(registro["request.number"].ToString(), registro["comments_and_work_notes"].ToString(), ServicenowGMT, SicoiGMT);

                    requests.Add(request);
                }
                catch (Exception ex)
                {
                    Sicoi sicoi = new Sicoi(this.ConexaoSicoi);
                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("ERRO EM ServiceNow.ConverteListaRequests: {0} - {1}", request.Entry_Id, ex.Message));
                }
            }

            return requests;
        }

        public List<Problem> ConverteListaProblems(DataTable tabela, int ServicenowGMT, int SicoiGMT)
        {
            List<Problem> problems = new List<Problem>();

            foreach (DataRow registro in tabela.Rows)
            {
                Problem problem = new Problem();
                try
                {
                    problem.number = PadronizaTexto(registro["number"].ToString());
                    problem.short_description = PadronizaTexto(registro["short_description"].ToString());
                    problem.u_executive_summary = PadronizaTexto(registro["u_executive_summary"].ToString());
                    problem.description = PadronizaTexto(registro["description"].ToString());
                    problem.u_knowledge_id = PadronizaTexto(registro["u_knowledge_id.number"].ToString());
                    problem.u_knowledge_description = PadronizaTexto(registro["u_knowledge_id.short_description"].ToString());
                    problem.assignment_group_id = PadronizaTexto(registro["assignment_group.sys_id"].ToString());
                    problem.assignment_group_description = PadronizaTexto(registro["assignment_group.name"].ToString());
                    problem.opened_by = PadronizaTexto(registro["opened_by.user_name"].ToString());
                    problem.opened_at = PadronizaDataHoraSicoi(registro["opened_at"].ToString(), ServicenowGMT, SicoiGMT);
                    problem.sys_updated_on = PadronizaDataHoraSicoi(registro["sys_updated_on"].ToString(), ServicenowGMT, SicoiGMT);
                    problem.assigned_to = PadronizaTexto(registro["assigned_to.user_name"].ToString());
                    problem.active = PadronizaBoolean(registro["active"].ToString());
                    problem.state = PadronizaTexto(registro["state"].ToString());
                    problem.impact = PadronizaTexto(registro["impact"].ToString());
                    problem.priority = PadronizaTexto(registro["priority"].ToString());
                    problem.urgency = PadronizaTexto(registro["urgency"].ToString());
                    problem.u_root_cause = PadronizaTexto(registro["u_root_cause"].ToString());
                    problem.u_close_code = PadronizaTexto(registro["u_close_code"].ToString());
                    problem.u_two_word_root_cause = PadronizaTexto(registro["u_two_word_root_cause"].ToString());
                    problem.closed_by = PadronizaTexto(registro["closed_by.user_name"].ToString());
                    problem.closed_at = PadronizaDataHoraSicoi(registro["closed_at"].ToString(), ServicenowGMT, SicoiGMT);
                    problem.tasks = ConsultaProblemTasks(registro["sys_id"].ToString(), ServicenowGMT, SicoiGMT);

                    problems.Add(problem);
                }
                catch (Exception ex)
                {
                    Sicoi sicoi = new Sicoi(this.ConexaoSicoi);
                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("ERRO EM ServiceNow.ConverteListaProblems: {0} - {1}", problem.number, ex.Message));
                }
            }

            return problems;
        }

        public List<ProblemTask> ConverteListaTasks(DataTable tabela, int ServicenowGMT, int SicoiGMT)
        {
            List<ProblemTask> tasks = new List<ProblemTask>();

            foreach (DataRow registro in tabela.Rows)
            {
                ProblemTask task = new ProblemTask();
                try
                {
                    task.problem = PadronizaTexto(registro["problem.number"].ToString());
                    task.number = PadronizaTexto(registro["number"].ToString());
                    task.short_description = PadronizaTexto(registro["short_description"].ToString());
                    task.description = PadronizaTexto(registro["description"].ToString());
                    task.active = PadronizaBoolean(registro["active"].ToString());
                    task.state = PadronizaTexto(registro["state"].ToString());
                    task.impact = PadronizaTexto(registro["impact"].ToString());
                    task.priority = PadronizaTexto(registro["priority"].ToString());
                    task.urgency = PadronizaTexto(registro["urgency"].ToString());
                    task.opened_by_user = PadronizaTexto(registro["opened_by.user_name"].ToString());
                    task.opened_by_name = PadronizaTexto(registro["opened_by.name"].ToString());
                    task.opened_at = PadronizaDataHoraSicoi(registro["opened_at"].ToString(), ServicenowGMT, SicoiGMT);
                    task.assignment_group_id = PadronizaTexto(registro["assignment_group.sys_id"].ToString());
                    task.assignment_group_description = PadronizaTexto(registro["assignment_group.name"].ToString());
                    task.assigned_to_user = PadronizaTexto(registro["assigned_to.user_name"].ToString());
                    task.assigned_to_name = PadronizaTexto(registro["assigned_to.name"].ToString());
                    task.assigned_to_email = PadronizaTexto(registro["assigned_to.email"].ToString());
                    task.sys_updated_on = PadronizaDataHoraSicoi(registro["sys_updated_on"].ToString(), ServicenowGMT, SicoiGMT);
                    task.sys_class_name = PadronizaTexto(registro["sys_class_name"].ToString());
                    task.approval = PadronizaTexto(registro["approval"].ToString());
                    task.expected_start = PadronizaDataHoraSicoi(registro["expected_start"].ToString(), ServicenowGMT, SicoiGMT);
                    task.due_date = PadronizaDataHoraSicoi(registro["due_date"].ToString(), ServicenowGMT, SicoiGMT);
                    task.escalation = PadronizaTexto(registro["escalation"].ToString());
                    task.closed_by_user = PadronizaTexto(registro["closed_by.user_name"].ToString());
                    task.closed_by_name = PadronizaTexto(registro["closed_by.name"].ToString());
                    task.closed_at = PadronizaDataHoraSicoi(registro["closed_at"].ToString(), ServicenowGMT, SicoiGMT);

                    tasks.Add(task);
                }
                catch (Exception ex)
                {
                    Sicoi sicoi = new Sicoi(this.ConexaoSicoi);
                    sicoi.InsereSqlLogAtualizaRemedy(string.Format("ERRO EM ServiceNow.ConverteListaTasks: {0}", ex.Message), task.number);
                }
            }

            return tasks;
        }

        public List<ChamadoLog> ListChamadoLogs(string incident, string info, int ServicenowGMT, int SicoiGMT)
        {
            List<ChamadoLog> logs = new List<ChamadoLog>();
            string[] lines = info.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            string data = string.Empty;
            string texto = string.Empty;
            ChamadoLog log = new ChamadoLog();
            foreach (string line in lines)
            {
                try
                {
                    if (line.Length > 22 && ValidarQuebraData(line.Substring(0, 22)))
                    {
                        if (!string.IsNullOrEmpty(data))
                        {
                            log = new ChamadoLog();
                            log.Entry_Id = incident;
                            //log.Log_Date = DateTime.ParseExact(data, "MM-dd-yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                            log.Log_Date = PadronizaDataHoraSicoi(data, ServicenowGMT, SicoiGMT);
                            log.Log = texto;
                            logs.Add(log);
                        }
                        data = line.Substring(0, 19);
                        texto = line.Substring(22, line.Length - 22);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            texto = texto + "<br/>" + line;
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
            try
            {
                log = new ChamadoLog();
                log.Entry_Id = incident;
                //log.Log_Date = DateTime.ParseExact(data, "MM-dd-yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture); ;
                log.Log_Date = PadronizaDataHoraSicoi(data, ServicenowGMT, SicoiGMT);
                log.Log = texto;
                logs.Add(log);
            }
            catch (Exception)
            {
                throw;
            }

            return logs;
        }

        public bool ValidarQuebraData(string teste)
        {
            bool retorno = false;
            Regex stringDatePattern = new Regex("^[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] - $");
            retorno = stringDatePattern.IsMatch(teste);
            if (retorno)
            {
                DateTime data;
                if (!DateTime.TryParseExact(teste.Substring(0,19), "MM-dd-yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out data))
                {
                    retorno = false;
                }
            }
            return retorno;
        }

        public static string PadronizaTexto(string texto)
        {
            string retorno = null;
            if (!string.IsNullOrWhiteSpace(texto))
            {
                retorno = texto.Replace(System.Environment.NewLine, "<br/>").Trim();
            }
            return retorno;
        }

        public static DateTime? PadronizaDataHora(string texto)
        {
            DateTime? retorno = null;
            if (!string.IsNullOrWhiteSpace(texto) && texto.Length.Equals(19))
            {
                string ano = texto.Trim().Substring(6, 4);
                string mes = texto.Trim().Substring(0, 2);
                string dia = texto.Trim().Substring(3, 2);
                string hora = texto.Trim().Substring(11, 2);
                string minuto = texto.Trim().Substring(14, 2);
                string segundo = texto.Trim().Substring(17, 2);

                string formatado = string.Format("{0}-{1}-{2} {3}:{4}:{5}", ano, mes, dia, hora, minuto, segundo);
                retorno = Convert.ToDateTime(formatado);
            }
            return retorno;
        }

        public static DateTime? PadronizaDataHoraSicoi(string texto, int ServicenowGMT, int SicoiGMT)
        {
            DateTime? retorno = null;
            if (!string.IsNullOrWhiteSpace(texto) && texto.Length.Equals(19))
            {
                string ano = texto.Trim().Substring(6, 4);
                string mes = texto.Trim().Substring(0, 2);
                string dia = texto.Trim().Substring(3, 2);
                string hora = texto.Trim().Substring(11, 2);
                string minuto = texto.Trim().Substring(14, 2);
                string segundo = texto.Trim().Substring(17, 2);

                string formatado = string.Format("{0}-{1}-{2} {3}:{4}:{5}", ano, mes, dia, hora, minuto, segundo);
                retorno = Convert.ToDateTime(formatado).AddHours(ServicenowGMT * -1).AddHours(SicoiGMT);

            }
            return retorno;
        }

        public static bool? PadronizaBoolean(string texto)
        {
            bool? retorno = null;
            if (!string.IsNullOrWhiteSpace(texto))
            {
                retorno = texto.Trim().ToUpper().Equals("TRUE") || texto.Trim().ToUpper().Equals("VERDADEIRO");
            }
            return retorno;
        }

        public static string CallRestMethod(string url, string proxyHost, int proxyPort, string username, string password, string domain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(url);
                webrequest.Proxy = new WebProxy(proxyHost, proxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Proxy.Credentials = new NetworkCredential(username, password, domain);
                webrequest.Credentials = new NetworkCredential(username, password);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("Erro: {0}", ex.Message));
            }

            return source;
        }

    }
}
