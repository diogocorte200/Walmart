﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SicoiNow
{
    public class ChamadoLog
    {
        public string Entry_Id { get; set; }
        public DateTime? Log_Date { get; set; }
        public string Log { get; set; }
    }
}
