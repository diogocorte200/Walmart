﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SicoiNow
{
    public class Sicoi
    {
        private string Conexao { get; set; }

        public Sicoi(string Conexao)
        {
            this.Conexao = Conexao;
        }

        public string ComandoAtualizaChamado(Chamado incident)
        {
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("MERGE TBL_Chamados_Remedy T ");
            sb.Append("USING (SELECT ");
            sb.Append(PadronizaTexto(incident.Entry_Id) + " [Entry-Id],");
            sb.Append(PadronizaDataHora(incident.Create_Date) + " [Create Date],");
            sb.Append(PadronizaTexto(incident.Create_Time) + " [Create Time],");
            sb.Append(PadronizaTexto(incident.CreateDate) + " [Create-Date],");
            sb.Append(PadronizaTexto(incident.Assigned_To) + " [Assigned-To],");
            sb.Append(PadronizaTexto(incident.Assigned_Team) + " [Assigned-Team],");
            sb.Append(PadronizaTexto(incident.Requestor_Impact) + " [Requestor  Impact],");
            sb.Append(PadronizaTexto(incident.Problem_Type) + " [Problem Type],");
            sb.Append(PadronizaTexto(incident.Problem_Details) + " [Problem Details],");
            sb.Append(PadronizaTexto(incident.Serial_NBR) + " [Serial #],");
            sb.Append(PadronizaTexto(incident.Status) + " [Status],");
            sb.Append(PadronizaTexto(incident.Closed_By) + " [Closed By],");
            sb.Append(PadronizaDataHora(incident.Closed_date) + " [Closed date],");
            sb.Append(PadronizaTexto(incident.Closed_Time) + " [Closed Time],");
            sb.Append(PadronizaTexto(incident.Assigned_Team_NBR) + " [Assigned Team #],");
            sb.Append(PadronizaDataHora(incident.Modified_date) + " [Modified-date],");
            sb.Append(PadronizaInt(incident.Codigo_Frente) + " [Codigo_Frente],");
            sb.Append(PadronizaTexto(incident.Contact_Location) + " [Contact_Location],");
            sb.Append(PadronizaTexto(incident.RMA_NBR) + " [RMA#],");
            sb.Append(PadronizaTexto(incident.Status_Description) + " [Status Description],");
            sb.Append(PadronizaInt(incident.Store_Dept_NBR) + " [Store_Dept_NBR],");
            sb.Append(PadronizaTexto(incident.Contact_Name) + " [Contact_Name],");
            sb.Append(PadronizaTexto(incident.Contact_Phone) + " [Contact_Phone],");
            sb.Append(PadronizaTexto(incident.Alt_Contact_Phone) + " [Alt_Contact_Phone],");
            sb.Append(PadronizaTexto(incident.Alt_Contact_Name) + " [Alt_Contact_Name],");
            sb.Append(PadronizaTexto(incident.Contact_User_ID) + " [Contact_User_ID],");
            sb.Append(PadronizaTexto(incident.Related_Rec_ID) + " [Related Rec. ID],");
            sb.Append(PadronizaTexto(incident.DepartmentNumber) + " [DepartmentNumber],");
            sb.Append(PadronizaTexto(incident.SIM_Number) + " [SIM_Number],");
            sb.Append(PadronizaTexto(incident.IMEI_Number) + " [IMEI_Number],");
            sb.Append(PadronizaTexto(incident.PhoneNumberOfDevice) + " [PhoneNumberOfDevice],");
            sb.Append(PadronizaTexto(incident.Submitter) + " [Submitter],");
            sb.Append(PadronizaTexto(incident.Assisted_By) + " [Assisted By],");
            sb.Append(PadronizaDataHora(incident.ETA) + " [ETA],");
            sb.Append(PadronizaTexto(incident.Vendor_Name) + " [Vendor Name],");
            sb.Append(PadronizaTexto(incident.Problem_Type_NBR) + " [Problem Type #]");
            sb.Append(") AS S ");
            sb.Append("ON (S.[Entry-Id] = T.[Entry-Id]) ");
            sb.Append("WHEN NOT MATCHED BY TARGET THEN INSERT ");
            sb.Append("(");
            sb.Append("[Entry-Id],");
            sb.Append("[Create Date],");
            sb.Append("[Create Time],");
            sb.Append("[Create-Date],");
            sb.Append("[Assigned-To],");
            sb.Append("[Assigned-Team],");
            sb.Append("[Requestor  Impact],");
            sb.Append("[Problem Type],");
            sb.Append("[Problem Details],");
            sb.Append("[Serial #],");
            sb.Append("[Status],");
            sb.Append("[Closed By],");
            sb.Append("[Closed date],");
            sb.Append("[Closed Time],");
            sb.Append("[Assigned Team #],");
            sb.Append("[Modified-date],");
            sb.Append("[Codigo_Frente],");
            sb.Append("[Contact_Location],");
            sb.Append("[RMA#],");
            sb.Append("[Status Description],");
            sb.Append("[Store_Dept_NBR],");
            sb.Append("[Contact_Name],");
            sb.Append("[Contact_Phone],");
            sb.Append("[Alt_Contact_Phone],");
            sb.Append("[Alt_Contact_Name],");
            sb.Append("[Contact_User_ID],");
            sb.Append("[Related Rec. ID],");
            sb.Append("[DepartmentNumber],");
            sb.Append("[SIM_Number],");
            sb.Append("[IMEI_Number],");
            sb.Append("[PhoneNumberOfDevice],");
            sb.Append("[Submitter],");
            sb.Append("[Assisted By],");
            sb.Append("[ETA],");
            sb.Append("[Vendor Name],");
            sb.Append("[Problem Type #]");
            sb.Append(") ");
            sb.Append("VALUES ");
            sb.Append("(");
            sb.Append("S.[Entry-Id],");
            sb.Append("S.[Create Date],");
            sb.Append("S.[Create Time],");
            sb.Append("S.[Create-Date],");
            sb.Append("S.[Assigned-To],");
            sb.Append("S.[Assigned-Team],");
            sb.Append("S.[Requestor  Impact],");
            sb.Append("S.[Problem Type],");
            sb.Append("S.[Problem Details],");
            sb.Append("S.[Serial #],");
            sb.Append("S.[Status],");
            sb.Append("S.[Closed By],");
            sb.Append("S.[Closed date],");
            sb.Append("S.[Closed Time],");
            sb.Append("S.[Assigned Team #],");
            sb.Append("S.[Modified-date],");
            sb.Append("S.[Codigo_Frente],");
            sb.Append("S.[Contact_Location],");
            sb.Append("S.[RMA#],");
            sb.Append("S.[Status Description],");
            sb.Append("S.[Store_Dept_NBR],");
            sb.Append("S.[Contact_Name],");
            sb.Append("S.[Contact_Phone],");
            sb.Append("S.[Alt_Contact_Phone],");
            sb.Append("S.[Alt_Contact_Name],");
            sb.Append("S.[Contact_User_ID],");
            sb.Append("S.[Related Rec. ID],");
            sb.Append("S.[DepartmentNumber],");
            sb.Append("S.[SIM_Number],");
            sb.Append("S.[IMEI_Number],");
            sb.Append("S.[PhoneNumberOfDevice],");
            sb.Append("S.[Submitter],");
            sb.Append("S.[Assisted By],");
            sb.Append("S.[ETA],");
            sb.Append("S.[Vendor Name],");
            sb.Append("S.[Problem Type #]");
            sb.Append(") ");
            sb.Append("WHEN MATCHED THEN UPDATE ");
            sb.Append("SET ");
            sb.Append("T.[Entry-Id] = S.[Entry-Id],");
            sb.Append("T.[Create Date]	= S.[Create Date],");
            sb.Append("T.[Create Time] = S.[Create Time],");
            sb.Append("T.[Create-Date] = S.[Create-Date],");
            sb.Append("T.[Assigned-To] = S.[Assigned-To],");
            sb.Append("T.[Assigned-Team] = S.[Assigned-Team],");
            sb.Append("T.[Requestor  Impact] = S.[Requestor  Impact],");
            sb.Append("T.[Problem Type] = S.[Problem Type],");
            sb.Append("T.[Problem Details] = S.[Problem Details],");
            sb.Append("T.[Serial #] = S.[Serial #],");
            sb.Append("T.[Status] = S.[Status],");
            sb.Append("T.[Closed By] = S.[Closed By],");
            sb.Append("T.[Closed date] = S.[Closed date],");
            sb.Append("T.[Closed Time] = S.[Closed Time],");
            sb.Append("T.[Assigned Team #] = S.[Assigned Team #],");
            sb.Append("T.[Modified-date] = S.[Modified-date],");
            sb.Append("T.[Codigo_Frente] = S.[Codigo_Frente],");
            sb.Append("T.[Contact_Location] = S.[Contact_Location],");
            sb.Append("T.[RMA#] = S.[RMA#],");
            sb.Append("T.[Status Description] = S.[Status Description],");
            sb.Append("T.[Store_Dept_NBR] = S.[Store_Dept_NBR],");
            sb.Append("T.[Contact_Name] = S.[Contact_Name],");
            sb.Append("T.[Contact_Phone] = S.[Contact_Phone],");
            sb.Append("T.[Alt_Contact_Phone] = S.[Alt_Contact_Phone],");
            sb.Append("T.[Alt_Contact_Name] = S.[Alt_Contact_Name],");
            sb.Append("T.[Contact_User_ID] = S.[Contact_User_ID],");
            sb.Append("T.[Related Rec. ID] = S.[Related Rec. ID],");
            sb.Append("T.[DepartmentNumber] = S.[DepartmentNumber],");
            sb.Append("T.[SIM_Number] = S.[SIM_Number],");
            sb.Append("T.[IMEI_Number] = S.[IMEI_Number],");
            sb.Append("T.[PhoneNumberOfDevice] = S.[PhoneNumberOfDevice],");
            sb.Append("T.[Submitter] = S.[Submitter],");
            sb.Append("T.[Assisted By] = S.[Assisted By],");
            sb.Append("T.[ETA] = S.[ETA],");
            sb.Append("T.[Vendor Name] = S.[Vendor Name],");
            sb.Append("T.[Problem Type #] = S.[Problem Type #]");
            sb.Append(";");
            return sb.ToString();
        }

        public string ComandoLimpaChamadoLog(string incident)
        {
            if (string.IsNullOrEmpty(incident)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("DELETE FROM TBL_Chamados_Remedy_Log WHERE [Entry-Id] = " + PadronizaTexto(incident));
            return sb.ToString();
        }

        public string ComandoLimpaProblemTask(string problem)
        {
            if (string.IsNullOrEmpty(problem)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("DELETE FROM TBL_Problems_Tasks WHERE [problem] = " + PadronizaTexto(problem));
            return sb.ToString();
        }

        public string ComandoInsereChamadoLog(ChamadoLog log)
        {
            if (string.IsNullOrEmpty(log.Entry_Id)) return string.Empty;
            if (log.Log_Date == null) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("INSERT INTO TBL_Chamados_Remedy_Log ");
            sb.Append("([Entry-Id], [DATA_LOG], [LOG]) VALUES (" + PadronizaTexto(log.Entry_Id) + ", " + PadronizaDataHora(log.Log_Date) + ", " + PadronizaTexto(log.Log) + ")");
            return sb.ToString();
        }

        public string ComandoInsereProblemTask(ProblemTask task)
        {
            if (string.IsNullOrEmpty(task.problem)) return string.Empty;
            if (string.IsNullOrEmpty(task.number)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("INSERT INTO TBL_Problems_Tasks ");
            sb.Append("(");
            sb.Append("[problem],");
            sb.Append("[number],");
            sb.Append("[short_description],");
            sb.Append("[description],");
            sb.Append("[active],");
            sb.Append("[state],");
            sb.Append("[impact],");
            sb.Append("[priority],");
            sb.Append("[urgency],");
            sb.Append("[opened_by_user],");
            sb.Append("[opened_by_name],");
            sb.Append("[opened_at],");
            sb.Append("[assignment_group_id],");
            sb.Append("[assignment_group_description],");
            sb.Append("[assigned_to_user],");
            sb.Append("[assigned_to_name],");
            sb.Append("[assigned_to_email],");
            sb.Append("[sys_updated_on],");
            sb.Append("[sys_class_name],");
            sb.Append("[approval],");
            sb.Append("[expected_start],");
            sb.Append("[due_date],");
            sb.Append("[escalation],");
            sb.Append("[closed_by_user],");
            sb.Append("[closed_by_name],");
            sb.Append("[closed_at]");
            sb.Append(") ");
            sb.Append("VALUES (");
            sb.Append(PadronizaTexto(task.problem) + ",");
            sb.Append(PadronizaTexto(task.number) + ",");
            sb.Append(PadronizaTexto(task.short_description) + ",");
            sb.Append(PadronizaTexto(task.description) + ",");
            sb.Append(PadronizaBoolean(task.active) + ",");
            sb.Append(PadronizaTexto(task.state) + ",");
            sb.Append(PadronizaTexto(task.impact) + ",");
            sb.Append(PadronizaTexto(task.priority) + ",");
            sb.Append(PadronizaTexto(task.urgency) + ",");
            sb.Append(PadronizaTexto(task.opened_by_user) + ",");
            sb.Append(PadronizaTexto(task.opened_by_name) + ",");
            sb.Append(PadronizaDataHora(task.opened_at) + ",");
            sb.Append(PadronizaTexto(task.assignment_group_id) + ",");
            sb.Append(PadronizaTexto(task.assignment_group_description) + ",");
            sb.Append(PadronizaTexto(task.assigned_to_user) + ",");
            sb.Append(PadronizaTexto(task.assigned_to_name) + ",");
            sb.Append(PadronizaTexto(task.assigned_to_email) + ",");
            sb.Append(PadronizaDataHora(task.sys_updated_on) + ",");
            sb.Append(PadronizaTexto(task.sys_class_name) + ",");
            sb.Append(PadronizaTexto(task.approval) + ",");
            sb.Append(PadronizaDataHora(task.expected_start) + ",");
            sb.Append(PadronizaDataHora(task.due_date) + ",");
            sb.Append(PadronizaTexto(task.escalation) + ",");
            sb.Append(PadronizaTexto(task.closed_by_user) + ",");
            sb.Append(PadronizaTexto(task.closed_by_name) + ",");
            sb.Append(PadronizaDataHora(task.closed_at) + ")");
            return sb.ToString();
        }

        public string ComandoAtualizaProblem(Problem problem)
        {
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("MERGE TBL_Problems T ");
            sb.Append("USING (SELECT ");
            sb.Append(PadronizaTexto(problem.number) + " [number],");
            sb.Append(PadronizaTexto(problem.short_description) + " [short_description],");
            sb.Append(PadronizaTexto(problem.u_executive_summary) + " [u_executive_summary],");
            sb.Append(PadronizaTexto(problem.description) + " [description],");
            sb.Append(PadronizaTexto(problem.u_knowledge_id) + " [u_knowledge_id],");
            sb.Append(PadronizaTexto(problem.u_knowledge_description) + " [u_knowledge_description],");
            sb.Append(PadronizaTexto(problem.assignment_group_id) + " [assignment_group_id],");
            sb.Append(PadronizaTexto(problem.assignment_group_description) + " [assignment_group_description],");
            sb.Append(PadronizaTexto(problem.opened_by) + " [opened_by],");
            sb.Append(PadronizaDataHora(problem.opened_at) + " [opened_at],");
            sb.Append(PadronizaDataHora(problem.sys_updated_on) + " [sys_updated_on],");
            sb.Append(PadronizaTexto(problem.assigned_to) + " [assigned_to],");
            sb.Append(PadronizaBoolean(problem.active) + " [active],");
            sb.Append(PadronizaTexto(problem.state) + " [state],");
            sb.Append(PadronizaTexto(problem.impact) + " [impact],");
            sb.Append(PadronizaTexto(problem.priority) + " [priority],");
            sb.Append(PadronizaTexto(problem.urgency) + " [urgency],");
            sb.Append(PadronizaTexto(problem.u_root_cause) + " [u_root_cause],");
            sb.Append(PadronizaTexto(problem.u_close_code) + " [u_close_code],");
            sb.Append(PadronizaTexto(problem.u_two_word_root_cause) + " [u_two_word_root_cause],");
            sb.Append(PadronizaTexto(problem.closed_by) + " [closed_by],");
            sb.Append(PadronizaDataHora(problem.closed_at) + " [closed_at]");
            sb.Append(") AS S ");
            sb.Append("ON (S.[number] = T.[number]) ");
            sb.Append("WHEN NOT MATCHED BY TARGET THEN INSERT ");
            sb.Append("(");
            sb.Append("[number],");
            sb.Append("[short_description],");
            sb.Append("[u_executive_summary],");
            sb.Append("[description],");
            sb.Append("[u_knowledge_id],");
            sb.Append("[u_knowledge_description],");
            sb.Append("[assignment_group_id],");
            sb.Append("[assignment_group_description],");
            sb.Append("[opened_by],");
            sb.Append("[opened_at],");
            sb.Append("[sys_updated_on],");
            sb.Append("[assigned_to],");
            sb.Append("[active],");
            sb.Append("[state],");
            sb.Append("[impact],");
            sb.Append("[priority],");
            sb.Append("[urgency],");
            sb.Append("[u_root_cause],");
            sb.Append("[u_close_code],");
            sb.Append("[u_two_word_root_cause],");
            sb.Append("[closed_by],");
            sb.Append("[closed_at]");
            sb.Append(") ");
            sb.Append("VALUES ");
            sb.Append("(");
            sb.Append("S.[number],");
            sb.Append("S.[short_description],");
            sb.Append("S.[u_executive_summary],");
            sb.Append("S.[description],");
            sb.Append("S.[u_knowledge_id],");
            sb.Append("S.[u_knowledge_description],");
            sb.Append("S.[assignment_group_id],");
            sb.Append("S.[assignment_group_description],");
            sb.Append("S.[opened_by],");
            sb.Append("S.[opened_at],");
            sb.Append("S.[sys_updated_on],");
            sb.Append("S.[assigned_to],");
            sb.Append("S.[active],");
            sb.Append("S.[state],");
            sb.Append("S.[impact],");
            sb.Append("S.[priority],");
            sb.Append("S.[urgency],");
            sb.Append("S.[u_root_cause],");
            sb.Append("S.[u_close_code],");
            sb.Append("S.[u_two_word_root_cause],");
            sb.Append("S.[closed_by],");
            sb.Append("S.[closed_at]");
            sb.Append(") ");
            sb.Append("WHEN MATCHED THEN UPDATE ");
            sb.Append("SET ");
            sb.Append("T.[number] = S.[number],");
            sb.Append("T.[short_description] = S.[short_description],");
            sb.Append("T.[u_executive_summary] = S.[u_executive_summary],");
            sb.Append("T.[description] = S.[description],");
            sb.Append("T.[u_knowledge_id] = S.[u_knowledge_id],");
            sb.Append("T.[u_knowledge_description] = S.[u_knowledge_description],");
            sb.Append("T.[assignment_group_id] = S.[assignment_group_id],");
            sb.Append("T.[assignment_group_description] = S.[assignment_group_description],");
            sb.Append("T.[opened_by] = S.[opened_by],");
            sb.Append("T.[opened_at] = S.[opened_at],");
            sb.Append("T.[sys_updated_on] = S.[sys_updated_on],");
            sb.Append("T.[assigned_to] = S.[assigned_to],");
            sb.Append("T.[active] = S.[active],");
            sb.Append("T.[state] = S.[state],");
            sb.Append("T.[impact] = S.[impact],");
            sb.Append("T.[priority] = S.[priority],");
            sb.Append("T.[urgency] = S.[urgency],");
            sb.Append("T.[u_root_cause] = S.[u_root_cause],");
            sb.Append("T.[u_close_code] = S.[u_close_code],");
            sb.Append("T.[u_two_word_root_cause] = S.[u_two_word_root_cause],");
            sb.Append("T.[closed_by] = S.[closed_by],");
            sb.Append("T.[closed_at] = S.[closed_at]");
            sb.Append(";");
            return sb.ToString();
        }

        public string ComandoAtualizaGrupo(Chamado incident)
        {
            if (string.IsNullOrEmpty(incident.Assigned_Team_NBR)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("MERGE R8_CTM_Support_Group T USING (SELECT " + PadronizaTexto(incident.Assigned_Team_NBR) + " [SupportGroupID], " + PadronizaTexto(incident.Assigned_Team) + " [SupportGroupName]) AS S ");
            sb.Append("ON (S.[SupportGroupID] = T.[SupportGroupID]) ");
            sb.Append("WHEN NOT MATCHED BY TARGET THEN ");
            sb.Append("INSERT ([DatIncReg], [SupportGroupID], [SupportGroupName]) VALUES (GETDATE(), S.[SupportGroupID], S.[SupportGroupName]) ");
            sb.Append("WHEN MATCHED AND S.[SupportGroupName] != T.[SupportGroupName] THEN ");
            sb.Append("UPDATE SET T.[DatAltReg] = GETDATE(), T.[QtdAltReg] = T.[QtdAltReg]+1, T.[SupportGroupName] = S.[SupportGroupName];");
            return sb.ToString();
        }

        public string ComandoAtualizaGrupo(Problem problem)
        {
            if (string.IsNullOrEmpty(problem.assignment_group_id)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("MERGE R8_CTM_Support_Group T USING (SELECT " + PadronizaTexto(problem.assignment_group_id) + " [SupportGroupID], " + PadronizaTexto(problem.assignment_group_description) + " [SupportGroupName]) AS S ");
            sb.Append("ON (S.[SupportGroupID] = T.[SupportGroupID]) ");
            sb.Append("WHEN NOT MATCHED BY TARGET THEN ");
            sb.Append("INSERT ([DatIncReg], [SupportGroupID], [SupportGroupName]) VALUES (GETDATE(), S.[SupportGroupID], S.[SupportGroupName]) ");
            sb.Append("WHEN MATCHED AND S.[SupportGroupName] != T.[SupportGroupName] THEN ");
            sb.Append("UPDATE SET T.[DatAltReg] = GETDATE(), T.[QtdAltReg] = T.[QtdAltReg]+1, T.[SupportGroupName] = S.[SupportGroupName];");
            return sb.ToString();
        }

        public string ComandoAtualizaTemplate(Chamado incident)
        {
            if (string.IsNullOrEmpty(incident.Problem_Type_NBR)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("MERGE R8_HPD_Template T USING (SELECT " + PadronizaTexto(incident.Problem_Type_NBR) + " [HPD_Template_ID], " + PadronizaTexto(incident.Problem_Type) + " [Template_Name]) AS S ");
            sb.Append("ON (S.[HPD_Template_ID] = T.[HPD_Template_ID]) ");
            sb.Append("WHEN NOT MATCHED BY TARGET THEN ");
            sb.Append("INSERT ([DatIncReg], [HPD_Template_ID], [InstanceID], [Template_Name]) VALUES (GETDATE(), S.[HPD_Template_ID], S.[HPD_Template_ID], S.[Template_Name]) ");
            sb.Append("WHEN MATCHED AND S.[Template_Name] != T.[Template_Name] THEN ");
            sb.Append("UPDATE SET T.[DatAltReg] = GETDATE(), T.[QtdAltReg] = T.[QtdAltReg]+1, T.[Template_Name] = S.[Template_Name];");
            return sb.ToString();
        }

        public string ComandoCorrigeGrupo(string id)
        {
            if (string.IsNullOrEmpty(id)) return string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Clear();
            sb.Append("update inc ");
            sb.Append("set inc.[Assigned Team #] = isnull(grp.SupportGroupID, inc.[Assigned Team #]) ");
            sb.Append("from TBL_Chamados_Remedy inc ");
            sb.Append("left join R8_CTM_Support_Group grp on grp.SupportGroupCD = inc.[Assigned Team #] ");
            sb.Append("where inc.[Entry-Id] = " + PadronizaTexto(id));
            return sb.ToString();
        }

        public int GravaIncidents(List<Chamado> incidents)
        {
            int contador = 0;
            SqlConnection DbConnection = new SqlConnection(this.Conexao);
            DbConnection.Open();
            SqlCommand DbCommand = DbConnection.CreateCommand();

            foreach (Chamado incident in incidents)
            {
                try
                {
                    DbCommand.CommandText = ComandoAtualizaChamado(incident);
                    DbCommand.ExecuteNonQuery();

                    DbCommand.CommandText = ComandoCorrigeGrupo(incident.Entry_Id);
                    if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();

                    DbCommand.CommandText = ComandoLimpaChamadoLog(incident.Entry_Id);
                    if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();
                    
                    foreach (ChamadoLog log in incident.logs)
                    {
                        DbCommand.CommandText = ComandoInsereChamadoLog(log);
                        if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();
                    }

                    DbCommand.CommandText = ComandoAtualizaGrupo(incident);
                    if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();

                    DbCommand.CommandText = ComandoAtualizaTemplate(incident);
                    if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();

                    if (incident.manual) GravaRetornoParametrizados(incident.Entry_Id, string.Format("Atualizado com sucesso em {0}.", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));

                    contador++;
                }
                catch (Exception ex)
                {
                    if (incident.manual) GravaRetornoParametrizados(incident.Entry_Id, string.Format("Falha ao atualizar em {0} - {1}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), ex.Message));
                    InsereSqlLogAtualizaRemedy(string.Format("ERRO EM Sicoi.GravaChamados: {0}", ex.Message), incident.Entry_Id);
                }
            }

            DbCommand.Dispose();
            DbConnection.Close();
            DbConnection.Dispose();

            return contador;
        }

        public int GravaProblems(List<Problem> problems)
        {
            int contador = 0;
            SqlConnection DbConnection = new SqlConnection(this.Conexao);
            DbConnection.Open();
            SqlCommand DbCommand = DbConnection.CreateCommand();

            foreach (Problem problem in problems)
            {
                try
                {
                    DbCommand.CommandText = ComandoAtualizaProblem(problem);
                    DbCommand.ExecuteNonQuery();

                    DbCommand.CommandText = ComandoAtualizaGrupo(problem);
                    if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();

                    DbCommand.CommandText = ComandoLimpaProblemTask(problem.number);
                    if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();

                    foreach (ProblemTask task in problem.tasks)
                    {
                        DbCommand.CommandText = ComandoInsereProblemTask(task);
                        if (!string.IsNullOrEmpty(DbCommand.CommandText)) DbCommand.ExecuteNonQuery();
                    }

                    if (problem.manual) GravaRetornoParametrizados(problem.number, string.Format("Atualizado com sucesso em {0}.", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));

                    contador++;
                }
                catch (Exception ex)
                {
                    if (problem.manual) GravaRetornoParametrizados(problem.number, string.Format("Falha ao atualizar em {0} - {1}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), ex.Message));
                    InsereSqlLogAtualizaRemedy(string.Format("ERRO EM Sicoi.GravaProblems: {0}", ex.Message), problem.number);
                }
            }

            DbCommand.Dispose();
            DbConnection.Close();
            DbConnection.Dispose();

            return contador;
        }

        public void GravaRetornoParametrizados(string id, string status)
        {
            SqlConnection DbConnection;
            SqlCommand DbCommand;
            try
            {
                DbConnection = new SqlConnection(this.Conexao);
                DbConnection.Open();
                DbCommand = DbConnection.CreateCommand();
                DbCommand.CommandText = string.Format("UPDATE TBL_Processar_Manual SET status = '{0}' WHERE id = '{1}' AND status IS NULL", status, id);
                DbCommand.ExecuteNonQuery();
                DbCommand.Dispose();
                DbConnection.Close();
                DbConnection.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<string> ConsultaParametrizados(string inicial, int limite)
        {
            List<string> retorno = new List<string>();

            SqlConnection DbConnection;
            SqlCommand DbCommand;
            SqlDataReader DbReader;
            try
            {
                DbConnection = new SqlConnection(this.Conexao);
                DbConnection.Open();
                DbCommand = DbConnection.CreateCommand();
                DbCommand.CommandText = "SELECT id FROM TBL_Processar_Manual WHERE status IS NULL AND id LIKE '" + inicial + "%'";
                DbReader = DbCommand.ExecuteReader();
                int contador = 0;
                string id = string.Empty;
                List<string> lista = new List<string>();
                if (DbReader.HasRows)
                {
                    while (DbReader.Read())
                    {
                        id = DbReader["id"].ToString();
                        if (!string.IsNullOrEmpty(id))
                        {
                            lista.Add(id);
                            contador++;
                            if (contador >= limite)
                            {
                                retorno.Add(string.Join(",", lista.ToArray()));
                                contador = 0;
                                lista.Clear();
                            }
                        }
                    }
                    if (contador > 0 && contador < limite)
                    {
                        retorno.Add(string.Join(",", lista.ToArray()));
                    }
                }
                DbCommand.Dispose();
                DbConnection.Close();
                DbConnection.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return retorno;
        }

        public void RecuperaParametros(ref bool ServicoAtivo, ref bool AtualizaIncidents, ref bool AtualizaProblems,
            ref bool AtualizaMajorIncidents, ref bool AtualizaRequests,ref DateTime UltimaAtualizacao,
            ref int[] MinutoExecucao, ref int HorasLimiteConsulta, ref bool AtualizaGMT, ref DateTime UltimaAtualizacaoGMT,
            ref string ServicenowTimeZone, ref int ServicenowGMT, ref string SicoiTimeZone, ref int SicoiGMT, ref int QtdLimiteManualRequisicao)
        {
            SqlConnection DbConnection;
            SqlCommand DbCommand;
            SqlDataReader DbReader;
            try
            {
                DbConnection = new SqlConnection(this.Conexao);
                DbConnection.Open();
                DbCommand = DbConnection.CreateCommand();
                DbCommand.CommandText = "SELECT TOP 1 SERVICO_ATIVO, ATUALIZA_INCIDENTS, ATUALIZA_PROBLEMS, ATUALIZA_MAJOR_INCIDENTS, ATUALIZA_REQUESTS, DATA_ULTIMA_ATUALIZACAO, MINUTO_EXECUCAO, HORAS_LIMITE_CONSULTA, ATUALIZA_GMT, DATA_ULTIMA_ATUALIZACAO_GMT, SERVICENOW_TIMEZONE, SERVICENOW_GMT, SICOI_TIMEZONE, SICOI_GMT, QTD_LIMITE_MANUAL_REQUISICAO FROM CONTROLE_SERVICO";
                DbReader = DbCommand.ExecuteReader();
                if (DbReader.HasRows)
                {
                    while (DbReader.Read())
                    {
                        ServicoAtivo = Convert.ToBoolean(DbReader["SERVICO_ATIVO"]);
                        AtualizaIncidents = Convert.ToBoolean(DbReader["ATUALIZA_INCIDENTS"]);
                        AtualizaProblems = Convert.ToBoolean(DbReader["ATUALIZA_PROBLEMS"]);
                        AtualizaMajorIncidents = Convert.ToBoolean(DbReader["ATUALIZA_MAJOR_INCIDENTS"]);
                        AtualizaRequests = Convert.ToBoolean(DbReader["ATUALIZA_REQUESTS"]);
                        UltimaAtualizacao = Convert.ToDateTime(DbReader["DATA_ULTIMA_ATUALIZACAO"]);
                        MinutoExecucao = string.IsNullOrEmpty(DbReader["MINUTO_EXECUCAO"].ToString()) ? null : Array.ConvertAll<string, int>(DbReader["MINUTO_EXECUCAO"].ToString().Split(','), Convert.ToInt32);
                        HorasLimiteConsulta = Convert.ToInt32(DbReader["HORAS_LIMITE_CONSULTA"]);
                        AtualizaGMT = Convert.ToBoolean(DbReader["ATUALIZA_GMT"]);
                        UltimaAtualizacaoGMT = Convert.ToDateTime(DbReader["DATA_ULTIMA_ATUALIZACAO_GMT"]);
                        ServicenowTimeZone = string.IsNullOrEmpty(DbReader["SERVICENOW_TIMEZONE"].ToString()) ? null : DbReader["SERVICENOW_TIMEZONE"].ToString();
                        ServicenowGMT = Convert.ToInt32(DbReader["SERVICENOW_GMT"]);
                        SicoiTimeZone = string.IsNullOrEmpty(DbReader["SICOI_TIMEZONE"].ToString()) ? null : DbReader["SICOI_TIMEZONE"].ToString();
                        SicoiGMT = Convert.ToInt32(DbReader["SICOI_GMT"]);
                        QtdLimiteManualRequisicao = Convert.ToInt32(DbReader["QTD_LIMITE_MANUAL_REQUISICAO"]);
                    }
                }
                DbCommand.Dispose();
                DbConnection.Close();
                DbConnection.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsereSqlLogAtualizaRemedy(string pInformacao, string pComplemento = null)
        {
            SqlConnection DbConnection;
            SqlCommand DbCommand;
            try
            {
                DbConnection = new SqlConnection(this.Conexao);
                DbConnection.Open();
                DbCommand = DbConnection.CreateCommand();
                DbCommand.CommandText = string.Format("insert into TBL_Log_Atualiza_Chamados (DtLog, DsLog, DsComplemento) values (getdate(), {0}, {1})", "'SicoiNow: " + pInformacao.Replace("'", "") + "'", string.IsNullOrEmpty(pComplemento) ? "NULL" : "'" + pComplemento.Replace("'", "") + "'");
                DbCommand.ExecuteNonQuery();
                DbCommand.Dispose();
                DbConnection.Close();
                DbConnection.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AtualizaGMT(DateTime UltimaAtualizacaoGMT, string ServicenowTimeZone, ref int ServicenowGMT, string SicoiTimeZone, ref int SicoiGMT)
        {
            SqlConnection DbConnection;
            SqlCommand DbCommand;
            try
            {
                ServicenowGMT = Util.GetGMT(ServicenowTimeZone);
                SicoiGMT = Util.GetGMT(SicoiTimeZone);

                DbConnection = new SqlConnection(this.Conexao);
                DbConnection.Open();
                DbCommand = DbConnection.CreateCommand();
                DbCommand.CommandText = string.Format("update CONTROLE_SERVICO set SERVICENOW_GMT = {0}, SICOI_GMT = {1}, DATA_ULTIMA_ATUALIZACAO_GMT = '{2}'", ServicenowGMT.ToString(), SicoiGMT.ToString(), UltimaAtualizacaoGMT.ToString("yyyy-MM-dd HH:mm:ss"));
                DbCommand.ExecuteNonQuery();
                DbCommand.Dispose();
                DbConnection.Close();
                DbConnection.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AtualizaUltimaExecucao(DateTime ultima)
        {
            SqlConnection DbConnection;
            SqlCommand DbCommand;
            try
            {
                DbConnection = new SqlConnection(this.Conexao);
                DbConnection.Open();
                DbCommand = DbConnection.CreateCommand();
                DbCommand.CommandText = string.Format("update CONTROLE_SERVICO set DATA_ULTIMA_ATUALIZACAO = '{0}'", ultima.ToString("yyyy-MM-dd HH:mm:ss"));
                DbCommand.ExecuteNonQuery();
                DbCommand.Dispose();
                DbConnection.Close();
                DbConnection.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string PadronizaBoolean(bool? info)
        {
            string retorno = "NULL";
            try
            {
                if (info != null)
                {
                    int tmp = Convert.ToBoolean(info) ? 1 : 0;
                    retorno = tmp.ToString();
                }
            }
            catch
            {
                retorno = "NULL";
            }
            return retorno;
        }

        public static string PadronizaInt(int? info)
        {
            string retorno = "NULL";
            try
            {
                if (info != null)
                {
                    retorno = info.ToString();
                }
            }
            catch
            {
                retorno = "NULL";
            }
            return retorno;
        }

        public static string PadronizaTexto(string info)
        {
            string retorno = "NULL";
            if (!string.IsNullOrEmpty(info))
            {
                retorno = "'" + info.ToString().Replace("'", string.Empty) + "'";
            }
            return retorno;
        }

        public static string PadronizaDataHora(DateTime? info)
        {
            string retorno = "NULL";
            try
            {
                if (info != null)
                {
                    DateTime tmp = Convert.ToDateTime(info);
                    if (tmp.Year > 1) retorno = "'" + tmp.Year.ToString("0000") + "-" + tmp.Month.ToString("00") + "-" + tmp.Day.ToString("00") + " " + tmp.Hour.ToString("00") + ":" + tmp.Minute.ToString("00") + ":" + tmp.Second.ToString("00") + "'";
                }
            }
            catch
            {
                retorno = "NULL";
            }
            return retorno;
        }

    }
}
