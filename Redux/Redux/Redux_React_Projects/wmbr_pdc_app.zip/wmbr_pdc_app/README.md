# wmbr_pdc_app - Module 'App', main repo of Brazil Application PDC (Portal de Chamados
More info in this page: [Confluence Page](https://collaboration.wal-mart.com/x/I4CjBg)


--------------
#### GIT Migration history
- old git: https://walmart.visualstudio.com/Tickets%20Portal%20-%20Brazil/_git/Tickets%20Portal%20-%20Brazil
- old svn: https://svn01.wal-mart.com/svn/repos/sicoi

