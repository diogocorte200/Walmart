﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceNowApiInterface.Models;
using ServiceNowApiInterface.Repository;
using Newtonsoft.Json;
using System.Text;

namespace ServiceNowApiInterface.Controllers
{
    public class IncidentController : Controller
    {
        private IncidentRepository repositoryIncident = new IncidentRepository();

        public ActionResult Index()
        {
            return RedirectToAction("Create");
        }

        public ActionResult Create(string tipo)
        {
            if (HomeController.listKB.Count.Equals(0) || HomeController.listCI.Count.Equals(0) || HomeController.listGroup.Count.Equals(0) || HomeController.listUser.Count.Equals(0) || HomeController.listDept.Count.Equals(0))
            {
                return RedirectToAction("Index", "Home");
            }

            Incident incident;

            if (tipo == "clone")
            {
                incident = (Incident)TempData["inc"];

                if (incident == null)
                {
                    incident = new Incident();
                }
                else
                {
                    incident.sys_id = string.Empty;
                    incident.number = string.Empty;
                }
            }
            else
            {
                incident = new Incident();
            }


            if (string.IsNullOrEmpty(incident.AttendantId))
            {
                string msg = "Atendente não encontrado no Service Now";
                return RedirectToAction("Message", new { message = msg });
            }

            return View(incident);
        }

        public string Validate(Incident incident)
        {
            string ret = string.Empty;

            if (string.IsNullOrEmpty(incident.AttendantId))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "O atendente não é válido.";
            }

            if (string.IsNullOrEmpty(incident.CallerId))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "O solicitante não é válido.";
            }

            if (string.IsNullOrEmpty(incident.DepartmentId))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "O departamento não é válido.";
            }

            if (string.IsNullOrEmpty(incident.KnowledgeId))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "O artigo ou item de catálogo não é válido.";
            }

            if (string.IsNullOrEmpty(incident.ShortDescription))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "A descrição resumida não é válida.";
            }

            if (string.IsNullOrEmpty(incident.Description))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "A descrição não é válida.";
            }

            if (string.IsNullOrEmpty(incident.AssignamentGroupId))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "O grupo não é válido.";
            }

            if (string.IsNullOrEmpty(incident.ImpactId) || incident.ImpactId.Equals("0"))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "O impacto não é válido.";
            }

            if (string.IsNullOrEmpty(incident.UrgencyId) || incident.UrgencyId.Equals("0"))
            {
                ret += (string.IsNullOrEmpty(ret) ? string.Empty : System.Environment.NewLine) + "A urgência não é válida.";
            }

            return ret;
        }

        [HttpPost]
        public ActionResult Create(Incident incident)
        {
            incident.Validation = Validate(incident);
            if (!string.IsNullOrEmpty(incident.Validation))
            {
                return View(incident);
            }

            try
            {
                incident.kb = HomeController.listKB.First(x => x.number.ToUpper().Contains(incident.KnowledgeId.ToUpper()));
                incident.caller = HomeController.listUser.First(x => x.user_name.ToUpper().Contains(incident.CallerId.ToUpper()));

                Incident incCriar = new Incident();
                incCriar.sys_id = incident.sys_id;
                incCriar.number = incident.number;
                incCriar.KnowledgeDescription = incident.KnowledgeDescription;
                incCriar.KnowledgeId = incident.KnowledgeId;
                incCriar.ShortDescription = incident.ShortDescription;
                incCriar.Notes = incident.Notes;
                incCriar.Description = incident.Description;
                incCriar.AssignamentGroupDescription = incident.kb.u_assignment_group_name;
                incCriar.AssignamentGroupId = incident.kb.u_assignment_group_sys_id;
                incCriar.CallerName = incident.CallerName;
                incCriar.CallerId = incident.CallerId;
                incCriar.CallerEmail = incident.CallerEmail;
                incCriar.DepartmentName = incident.caller.department_name;
                incCriar.DepartmentId = incident.caller.department_code;
                incCriar.ClassName = incident.ClassName;
                incCriar.AffectedApplication = incident.AffectedApplication;
                incCriar.ImpactId = incident.kb.u_suggested_impact.Split('-')[0].Trim();
                incCriar.UrgencyId = incident.kb.u_suggested_urgency.Split('-')[0].Trim();
                incCriar.AttendantName = incident.AttendantName;
                incCriar.AttendantId = incident.AttendantId;
                incCriar.Comments = incident.Comments;
                incCriar.State = incident.State;
                incCriar.Validation = incident.Validation;
                incCriar.kb = incident.kb;
                incCriar.caller = incident.caller;

                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Chamado criado pelo usuário {0}{1}{2}", incident.AttendantName, System.Environment.NewLine, System.Environment.NewLine);
                sb.AppendFormat("Baseado no {0} - {1}", incident.KnowledgeDescription, System.Environment.NewLine);
                sb.AppendFormat("- Display Number: {0}{1}", incident.kb.display_number, System.Environment.NewLine);
                sb.AppendFormat("- Short Description: {0}{1}", incident.kb.short_description, System.Environment.NewLine);
                sb.AppendFormat("- CI Class: {0}{1}", incident.kb.u_ci_class, System.Environment.NewLine);
                sb.AppendFormat("- Suggested Impact: {0}{1}", incident.kb.u_suggested_impact, System.Environment.NewLine);
                sb.AppendFormat("- Suggested Urgency: {0}{1}", incident.kb.u_suggested_urgency, System.Environment.NewLine);
                sb.AppendFormat("- Assignment Group: {0}{1}", incident.kb.u_assignment_group_name, System.Environment.NewLine);
                sb.AppendFormat("- Affected Application: {0}{1}", incident.kb.u_affected_application_name, System.Environment.NewLine);
                sb.AppendFormat("- Resolution: {0}{1}", System.Environment.NewLine, StripTagsCharArray(incident.kb.text));
                incCriar.Comments = sb.ToString();

                Incident incCriado = repositoryIncident.Create(incCriar);
                string msg = string.Empty;

                if (!string.IsNullOrEmpty(incCriado.number))
                {
                    incident.sys_id = incCriado.sys_id;
                    incident.number = incCriado.number;
                    Incident incAtualizado = repositoryIncident.Update(incident);
                    if (!string.IsNullOrEmpty(incCriado.number))
                    {
                        msg = string.Format("Foi criado o incidente {0}", incCriado.number);
                        LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
                    }
                    else
                    {
                        msg = "Ocorreu uma falha ao atualizar o incidente.";
                        LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
                    }
                }
                else
                {
                    msg = "Ocorreu uma falha ao criar o incidente.";
                    LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
                }

                TempData["inc"] = incident;
                return RedirectToAction("Message", new { message = msg });
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.Create - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);

                msg = "Ocorreu uma falha ao criar o incidente. " + System.Environment.NewLine + ex.Message;
                return RedirectToAction("Message", new { message = msg });
            }
        }

        public static string StripTagsCharArray(string source)
        {
            char[] array = new char[source.Length];
            int arrayIndex = 0;
            bool inside = false;

            for (int i = 0; i < source.Length; i++)
            {
                char let = source[i];
                if (let == '<')
                {
                    inside = true;
                    continue;
                }
                if (let == '>')
                {
                    inside = false;
                    continue;
                }
                if (!inside)
                {
                    array[arrayIndex] = let;
                    arrayIndex++;
                }
            }
            return new string(array, 0, arrayIndex);
        }

        public ActionResult Message(string message)
        {
            Incident inc = (Incident)TempData["inc"];
            if (inc == null)
            {
                inc = new Incident();
            }
            inc.Message = message;
            TempData["inc"] = inc;

            return View(inc);
        }

        [HttpPost]
        public ActionResult Message()
        {
            Incident inc = (Incident)TempData["inc"];
            TempData["inc"] = inc;
            return RedirectToAction("Create");
        }

        public bool IsNumeric(string text)
        {
            bool retorno = false;
            Int32 test;
            if (Int32.TryParse(text, out test))
            {
                retorno = true;
            }
            return retorno;
        }

        public JsonResult GetKnowledgeBaseValues(string text)
        {
            string json = "{}";

            try
            {
                List<Description> resultado = new List<Description>();
                List<KnowledgeBase> resultadoKbId = HomeController.listKB;
                List<KnowledgeBase> resultadoKbDescription = HomeController.listKB;
                List<CatalogItem> resultadoCaDescription = HomeController.listCI;

                if (text.Trim().Length.Equals(9) && text.Trim().Substring(0, 2).ToUpper().Equals("KB") && IsNumeric(text.Trim().Substring(2, 7)))
                {
                    resultadoKbId = resultadoKbId.Where(x => x.number.ToUpper().Contains(text.Trim().ToUpper())).ToList();
                    foreach (KnowledgeBase kb in resultadoKbId)
                    {
                        Description ds = new Description();
                        ds.number = kb.number;
                        ds.description = kb.short_description;
                        ds.type = "KB";
                        ds.link = string.Empty;
                        resultado.Add(ds);
                    }
                }
                else
                {
                    string[] words = text.Split(' ');
                    if (words[0].Trim().Length.Equals(9) && words[0].Trim().Substring(0, 2).ToUpper().Equals("KB") && IsNumeric(words[0].Trim().Substring(2, 7)))
                    {
                        resultadoKbId = resultadoKbId.Where(x => x.number.ToUpper().Contains(words[0].Trim().ToUpper())).ToList();
                        foreach (KnowledgeBase kb in resultadoKbId)
                        {
                            Description ds = new Description();
                            ds.number = kb.number;
                            ds.description = kb.short_description;
                            ds.type = "KB";
                            ds.link = string.Empty;
                            resultado.Add(ds);
                        }
                    }
                    else
                    {
                        foreach (string word in words)
                        {
                            resultadoKbDescription = resultadoKbDescription.Where(x => x.short_description.ToUpper().Contains(word.ToUpper())).ToList();
                            resultadoCaDescription = resultadoCaDescription.Where(x => x.name.ToUpper().Contains(word.ToUpper())).ToList();
                        }
                        foreach (KnowledgeBase kb in resultadoKbDescription)
                        {
                            Description ds = new Description();
                            ds.number = kb.number;
                            ds.description = kb.short_description;
                            ds.type = "KB";
                            ds.link = string.Empty;
                            resultado.Add(ds);
                        }

                        foreach (CatalogItem ca in resultadoCaDescription)
                        {
                            Description ds = new Description();
                            ds.number = ca.sys_id;
                            ds.description = ca.name;
                            ds.type = "CI";
                            ds.link = ca.link;
                            resultado.Add(ds);
                        }
                    }
                }
                json = JsonConvert.SerializeObject(resultado, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetKnowledgeBaseValues - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { list = json }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetGroupValues(string text)
        {
            string json = "{}";

            try
            {
                List<Group> resultado = new List<Group>();
                List<Group> resultadoId = HomeController.listGroup;
                List<Group> resultadoDescription = HomeController.listGroup;

                string[] words = text.Split(' ');
                foreach (string word in words)
                {
                    resultadoId = resultadoId.Where(x => x.sys_id.ToUpper().Contains(word.ToUpper())).ToList();
                    resultadoDescription = resultadoDescription.Where(x => x.name.ToUpper().Contains(word.ToUpper())).ToList();
                }
                resultado.AddRange(resultadoId);
                resultado.AddRange(resultadoDescription);
                json = JsonConvert.SerializeObject(resultado, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetGroupValues - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { list = json }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCallerValues(string text)
        {
            string json = "{}";

            try
            {
                List<User> resultado = new List<User>();
                List<User> resultadoId = HomeController.listUser;
                List<User> resultadoDescription = HomeController.listUser;

                string[] words = text.Split(' ');
                foreach (string word in words)
                {
                    resultadoId = resultadoId.Where(x => x.user_name.ToUpper().Contains(word.ToUpper())).ToList();
                    resultadoDescription = resultadoDescription.Where(x => x.name.ToUpper().Contains(word.ToUpper())).ToList();
                }
                resultado.AddRange(resultadoId);
                resultado.AddRange(resultadoDescription);
                json = JsonConvert.SerializeObject(resultado, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetCallerValues - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { list = json }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDepartmentValues(string text)
        {
            string json = "{}";

            try
            {
                List<Department> resultado = new List<Department>();
                List<Department> resultadoId = HomeController.listDept;
                List<Department> resultadoDescription = HomeController.listDept;

                string[] words = text.Split(' ');
                foreach (string word in words)
                {
                    resultadoId = resultadoId.Where(x => x.Code.ToUpper().Contains(word.ToUpper())).ToList();
                    resultadoDescription = resultadoDescription.Where(x => x.Name.ToUpper().Contains(word.ToUpper())).ToList();
                }
                resultado.AddRange(resultadoId);
                resultado.AddRange(resultadoDescription);
                resultado = resultado.GroupBy(dp => dp.Code).Select(dp => dp.First()).ToList();
                json = JsonConvert.SerializeObject(resultado, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetDepartmentValues - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { list = json }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetKnowledgeBaseDetails(string number)
        {
            string json = "{}";

            try
            {
                KnowledgeBase kb = HomeController.listKB.First(x => x.number.ToUpper().Contains(number.ToUpper()));
                json = JsonConvert.SerializeObject(kb, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetKnowledgeBaseDetails - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { kb = json }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCatalogItemDetails(string number)
        {
            string json = "{}";

            try
            {
                CatalogItem ci = HomeController.listCI.First(x => x.sys_id.ToUpper().Contains(number.ToUpper()));
                json = JsonConvert.SerializeObject(ci, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetCatalogItemDetails - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { ci = json }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCallerDetails(string caller)
        {
            string json = "{}";

            try
            {
                User us = HomeController.listUser.First(x => x.user_name.ToUpper().Contains(caller.ToUpper()));
                json = JsonConvert.SerializeObject(us, Formatting.Indented);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Controllers.IncidentController.GetCallerDetails - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return Json(new { us = json }, JsonRequestBehavior.AllowGet);
        }

    }
}
