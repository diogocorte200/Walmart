﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.Routing;
using ServiceNowApiInterface.Models;
using ServiceNowApiInterface.Repository;

namespace ServiceNowApiInterface.Controllers
{
    public class HomeController : Controller
    {
        KnowledgeBaseRepository repositoryKB = new KnowledgeBaseRepository();
        CatalogItemRepository repositoryCI = new CatalogItemRepository();
        GroupRepository repositoryGroup = new GroupRepository();
        UserRepository repositoryUser = new UserRepository();
        DepartmentRepository repositoryDept = new DepartmentRepository();

        public static List<KnowledgeBase> listKB = new List<KnowledgeBase>();
        public static List<CatalogItem> listCI = new List<CatalogItem>();
        public static List<Group> listGroup = new List<Group>();
        public static List<User> listUser = new List<User>();
        public static List<Department> listDept = new List<Department>();

        public string GetAttendantId()
        {
            string retorno = string.Empty;

            string user = System.Web.HttpContext.Current.Request["LOGON_USER"];
            if (user.Contains("\\"))
            {
                user = user.Split('\\')[1];
            }
            if (string.IsNullOrEmpty(user)) user = "pmassa";
            User LoginUser = repositoryUser.GetUserByLogin(user);
            retorno = LoginUser.user_name;

            return retorno;
        }

        public ActionResult Index(Home home, string area)
        {
            ModelState.Clear();

            area = string.IsNullOrEmpty(area) ? string.Empty : area;

            if (area.Equals("ALL") || area.Equals("KB"))
            {
                home.KnowledgeBases = string.Empty;
                listKB.Clear();
            }
            if (area.Equals("ALL") || area.Equals("CI"))
            {
                home.CatalogItems = string.Empty;
                listCI.Clear();
            }
            if (area.Equals("ALL") || area.Equals("GP"))
            {
                home.Groups = string.Empty;
                listGroup.Clear();
            }
            if (area.Equals("ALL") || area.Equals("US"))
            {
                home.Users = string.Empty;
                listUser.Clear();
            }
            if (area.Equals("ALL") || area.Equals("DP"))
            {
                home.Departments = string.Empty;
                listDept.Clear();
            }

            if (string.IsNullOrEmpty(home.LoginUserId) || string.IsNullOrEmpty(home.LoginUserName))
            {
                string user = System.Web.HttpContext.Current.Request["LOGON_USER"];
                if (user.Contains("\\"))
                {
                    user = user.Split('\\')[1];
                }
                if (string.IsNullOrEmpty(user)) user = "pmassa";
                User LoginUser = repositoryUser.GetUserByLogin(user);
                if (string.IsNullOrEmpty(LoginUser.user_name))
                {
                    string msg = "Atendente não encontrado no Service Now";
                    return RedirectToAction("Message", "Incident", new { message = msg });
                }
                home.LoginUserId = LoginUser.user_name;
                home.LoginUserName = LoginUser.display;
                home.Message = "Recuperando lista de artigos. Aguarde.";
                return View(home);
            }

            if (string.IsNullOrEmpty(home.KnowledgeBases))
            {
                if (listKB.Count.Equals(0))
                {
                    listKB = repositoryKB.GetAllKnowledgeBases();
                }
                home.KnowledgeBases = string.Format("{0} artigos recuperados.", listKB.Count.ToString());
                home.Message = "Recuperando lista de itens de catálogo. Aguarde.";
                return View(home);
            }

            if (string.IsNullOrEmpty(home.CatalogItems))
            {
                if (listCI.Count.Equals(0))
                {
                    listCI = repositoryCI.GetAllCatalogItem();
                }
                home.CatalogItems = string.Format("{0} itens de catálogo recuperados.", listCI.Count.ToString());
                home.Message = "Recuperando lista de grupos. Aguarde.";
                return View(home);
            }

            if (string.IsNullOrEmpty(home.Groups))
            {
                if (listGroup.Count.Equals(0))
                {
                    listGroup = repositoryGroup.GetAllGroups();
                }
                home.Groups = string.Format("{0} grupos recuperados.", listGroup.Count.ToString());
                home.Message = "Recuperando lista de usuários. Aguarde.";
                return View(home);
            }

            if (string.IsNullOrEmpty(home.Users))
            {
                if (listUser.Count.Equals(0))
                {
                    listUser = repositoryUser.GetAllUsers();
                }
                home.Users = string.Format("{0} usuários recuperados.", listUser.Count.ToString());
                home.Message = "Recuperando lista de departamentos. Aguarde.";
                return View(home);
            }

            if (string.IsNullOrEmpty(home.Departments))
            {
                if (listDept.Count.Equals(0))
                {
                    listDept = repositoryDept.GetAllDepartments();
                }
                home.Departments = string.Format("{0} departamentos recuperados.", listDept.Count.ToString());
                home.Message = "Redirecionando para tela de criação de incidente. Aguarde.";
                return View(home);
            }

            return RedirectToAction("Create", "Incident");

        }

    }
}