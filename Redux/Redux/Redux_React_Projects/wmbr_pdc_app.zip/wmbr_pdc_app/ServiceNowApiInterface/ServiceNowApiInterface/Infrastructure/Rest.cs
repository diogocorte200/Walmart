﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace ServiceNowApiInterface.Infrastructure
{
    public class Rest
    {
        public string Call(string method, string url, string jsonPayLoad, string ProxyHost, int ProxyPort, string ServiceNowUsername, string ServiceNowPassword)
        {
            string response = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(url);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.Accept = "application/json";
                webrequest.ContentType = "application/json";
                webrequest.Method = method;
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                if (!string.IsNullOrEmpty(jsonPayLoad))
                {
                    using (StreamWriter streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                    {
                        streamWriter.Write(jsonPayLoad);
                    }
                }

                using (HttpWebResponse webresponse = webrequest.GetResponse() as HttpWebResponse)
                {
                    response = new StreamReader(webresponse.GetResponseStream()).ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

    }
}