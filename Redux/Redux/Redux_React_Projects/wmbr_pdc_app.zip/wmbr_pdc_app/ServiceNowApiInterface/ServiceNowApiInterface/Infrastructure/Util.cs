﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceNowApiInterface.Infrastructure
{
    public static class Util
    {
        public static string RetornarVersaoSistema()
        {
            string versao = string.Empty;
            try
            {
                versao = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
            catch (Exception)
            {
                versao = "NÃO IDENTIFICADA";
            }

            return versao;
        }
    }
}