﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceNowApiInterface.Controllers;
using System.Text;

namespace ServiceNowApiInterface.Models
{
    public class Incident
    {
        public string sys_id { get; set; }
        public string number { get; set; }

        [Display(Name = "Artigo")] 
        public string KnowledgeDescription { get; set; }
        public string KnowledgeId { get; set; }
        public SelectList ddlKbFiltered { get; set; }

        [Display(Name = "Descrição Resumida")]
        public string ShortDescription { get; set; }

        [Display(Name = "Descrição"), AllowHtml]
        public string Description { get; set; }

        [Display(Name = "Anotações"), AllowHtml]
        public string Notes { get; set; }

        [Display(Name = "Grupo")]
        public string AssignamentGroupDescription { get; set; }
        public string AssignamentGroupId { get; set; }
        public SelectList ddlAgFiltered { get; set; }

        [Display(Name = "Solicitante")]
        public string CallerName { get; set; }
        public string CallerId { get; set; }
        public SelectList ddlCallerFiltered { get; set; }

        [Display(Name = "Email Solicitante")]
        public string CallerEmail { get; set; }

        [Display(Name = "Departamento")]
        public string DepartmentName { get; set; }
        public string DepartmentId { get; set; }
        public SelectList ddlDepartmentFiltered { get; set; }

        [Display(Name = "Classe")]
        public string ClassName { get; set; }

        [Display(Name = "Aplicação")]
        public string AffectedApplication { get; set; }

        [Display(Name = "Impacto")]
        public string ImpactId { get; set; }
        public SelectList ddlImpact { get; set; }

        [Display(Name = "Urgência")]
        public string UrgencyId { get; set; }
        public SelectList ddlUrgency { get; set; }

        [Display(Name = "Atendente")]
        public string AttendantName { get; set; }
        public string AttendantId { get; set; }

        public string Comments { get; set; }
        
        public string State { get; set; }

        public KnowledgeBase kb { get; set; }
        public User caller { get; set; }

        public string Validation { get; set; }

        public string Message { get; set; }


        //public SelectList ddlKb { get; set; }
        //public SelectList ddlGroup { get; set; }
        //public SelectList ddlUser { get; set; }

        public Incident()
        {
            List<Impact> lstImpact = new List<Impact>();
            lstImpact.Add(new Impact() { ImpactId = "0", ImpactDescription = "Selecione" });
            lstImpact.Add(new Impact() { ImpactId = "1", ImpactDescription = "High" });
            lstImpact.Add(new Impact() { ImpactId = "2", ImpactDescription = "Medium" });
            lstImpact.Add(new Impact() { ImpactId = "3", ImpactDescription = "Low" });
            this.ddlImpact = new SelectList(lstImpact, "ImpactId", "ImpactDescription");

            List<Urgency> lstUrgency = new List<Urgency>();
            lstUrgency.Add(new Urgency() { UrgencyId = "0", UrgencyDescription = "Selecione" });
            lstUrgency.Add(new Urgency() { UrgencyId = "1", UrgencyDescription = "High" });
            lstUrgency.Add(new Urgency() { UrgencyId = "2", UrgencyDescription = "Medium" });
            lstUrgency.Add(new Urgency() { UrgencyId = "3", UrgencyDescription = "Low" });
            this.ddlUrgency = new SelectList(lstUrgency, "UrgencyId", "UrgencyDescription");

            List<KnowledgeBase> KbFiltered = new List<KnowledgeBase>();
            this.ddlKbFiltered = new SelectList(KbFiltered, "number", "short_description");

            List<Group> AgFiltered = new List<Group>();
            this.ddlAgFiltered = new SelectList(AgFiltered, "sys_id", "name");

            List<User> CallerFiltered = new List<User>();
            this.ddlCallerFiltered = new SelectList(CallerFiltered, "user_name", "name");

            List<Department> DepartmentFiltered = new List<Department>();
            this.ddlDepartmentFiltered = new SelectList(DepartmentFiltered, "Code", "Name");

            this.State = "1";

            string user = System.Web.HttpContext.Current.Request["LOGON_USER"];
            if (user.Contains("\\"))
            {
                user = user.Split('\\')[1];
            }
            if (string.IsNullOrEmpty(user)) user = "pmassa";
            User LoginUser = HomeController.listUser.First(x => x.user_name.ToUpper().Contains(user.ToUpper()));
            if (!string.IsNullOrEmpty(LoginUser.user_name))
            {
                this.AttendantId = LoginUser.user_name;
                this.AttendantName = LoginUser.display;
            }

        }

    }

    public class Impact
    {
        public string ImpactId { get; set; }
        public string ImpactDescription { get; set; }
    }

    public class Urgency
    {
        public string UrgencyId { get; set; }
        public string UrgencyDescription { get; set; }
    }

}