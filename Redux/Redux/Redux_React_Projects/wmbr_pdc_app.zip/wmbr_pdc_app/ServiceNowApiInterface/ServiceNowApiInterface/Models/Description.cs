﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceNowApiInterface.Models
{
    public class Description
    {
        public string number { get; set; }
        public string description { get; set; }
        public string type { get; set; }
        public string link { get; set; }
    }
}