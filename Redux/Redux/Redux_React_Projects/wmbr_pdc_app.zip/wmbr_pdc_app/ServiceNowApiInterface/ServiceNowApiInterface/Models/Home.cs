﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceNowApiInterface.Models
{
    public class Home
    {
        public string KnowledgeBases { get; set; }
        public string CatalogItems { get; set; }
        public string Groups { get; set; }
        public string Users { get; set; }
        public string Departments { get; set; }
        public string Message { get; set; }

        public string LoginUserId { get; set; }
        [Display(Name = "Atendente")] 
        public string LoginUserName { get; set; }
    }
}