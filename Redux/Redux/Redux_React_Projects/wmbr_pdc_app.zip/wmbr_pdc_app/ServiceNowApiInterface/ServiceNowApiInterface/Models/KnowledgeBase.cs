﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceNowApiInterface.Models
{
    public class KnowledgeBase
    {
        public string number { get; set; }
        public string language { get; set; }
        public string u_location { get; set; }
        public string display_number { get; set; }
        public string short_description { get; set; }
        public string article_id { get; set; }
        public string sys_id { get; set; }
        public string text { get; set; }
        public string workflow_state { get; set; }
        public string u_ci_class { get; set; }
        public string u_suggested_impact { get; set; }
        public string u_suggested_urgency { get; set; }
        public string u_assignment_group_sys_id { get; set; }
        public string u_assignment_group_name { get; set; }
        public string u_affected_application_sys_id { get; set; }
        public string u_affected_application_name { get; set; }
    }
}