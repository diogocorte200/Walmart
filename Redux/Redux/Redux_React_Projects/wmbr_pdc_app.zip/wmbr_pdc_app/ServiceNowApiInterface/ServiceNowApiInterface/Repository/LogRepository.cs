﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using ServiceNowApiInterface.Controllers;

namespace ServiceNowApiInterface.Repository
{
    public static class LogRepository
    {
        public static void Events(string source, string message, bool iserror)
        {
            using (EventLog eventLog = new EventLog("Application"))
            {
                eventLog.Source = source;
                eventLog.WriteEntry(message, iserror ? EventLogEntryType.Error : EventLogEntryType.Information);
            }
        }

        public static void Files(string folder, string file, string message, bool timestamp = true, bool attendant = true)
        {
            HomeController homeController = new HomeController();

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            File.AppendAllText(folder + file, (timestamp ? DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - " : string.Empty) + (attendant ? homeController.GetAttendantId() + " - " : string.Empty) + message + Environment.NewLine);
        }
    }
}