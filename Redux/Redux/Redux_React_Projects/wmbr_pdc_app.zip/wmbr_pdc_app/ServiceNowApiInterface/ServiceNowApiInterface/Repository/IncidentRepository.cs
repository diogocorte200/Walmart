﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Configuration;
using ServiceNowApiInterface.Models;
using System.IO;
using System.Text;
using System.Dynamic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ServiceNowApiInterface.Infrastructure;

namespace ServiceNowApiInterface.Repository
{
    public class IncidentRepository
    {
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ProxyUsername { get; set; }
        private string ProxyPassword { get; set; }
        private string ProxyDomain { get; set; }
        private string ServiceNowUrl { get; set; }
        private string ServiceNowUsername { get; set; }
        private string ServiceNowPassword { get; set; }

        public IncidentRepository()
        {
            try
            {
                this.ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
                this.ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
                this.ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
                this.ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
                this.ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];
                this.ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
                this.ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
                this.ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.IncidentRepository.IncidentRepository - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
        }

        public Incident Create(Incident incident)
        {
            Incident ret = new Incident();

            try
            {
                ret = RestIncidentPost(this.ServiceNowUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain, incident);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.IncidentRepository.Create - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
            
            return ret;
        }

        public Incident Update(Incident incident)
        {
            Incident ret = new Incident();

            try
            {
                ret = RestIncidentPut(this.ServiceNowUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain, incident);
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.IncidentRepository.Update - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return ret;
        }
        
        public static Incident RestIncidentPut(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain, Incident incident)
        {
            Incident retorno = new Incident();

            try
            {
                string url = string.Format("{0}/api/now/table/incident/{1}", ServiceNowUrl, incident.sys_id);
                dynamic o = new ExpandoObject();

                if (!string.IsNullOrEmpty(incident.kb.sys_id))
                    o.u_knowledge_id = incident.kb.sys_id;

                if (!string.IsNullOrEmpty(incident.ShortDescription))
                    o.short_description = incident.ShortDescription;

                if (!string.IsNullOrEmpty(incident.Notes) || !string.IsNullOrEmpty(incident.Description))
                    o.description = incident.Notes + System.Environment.NewLine + incident.Description;

                if (!string.IsNullOrEmpty(incident.CallerId))
                    o.caller_id = incident.CallerId;

                if (!string.IsNullOrEmpty(incident.DepartmentId))
                    o.u_department = incident.DepartmentId;

                if (!string.IsNullOrEmpty(incident.AssignamentGroupDescription))
                    o.assignment_group = incident.AssignamentGroupDescription;

                if (!string.IsNullOrEmpty(incident.ClassName))
                    o.u_ci_class_name = incident.ClassName;

                if (!string.IsNullOrEmpty(incident.ImpactId))
                    o.impact = incident.ImpactId;

                if (!string.IsNullOrEmpty(incident.UrgencyId))
                    o.urgency = incident.UrgencyId;

                if (!string.IsNullOrEmpty(incident.Comments))
                    o.comments = incident.Comments;

                if (!string.IsNullOrEmpty(incident.AttendantId))
                    o.u_serial_number = incident.AttendantId;

                if (!string.IsNullOrEmpty(incident.kb.u_affected_application_sys_id))
                    o.u_affected_application = incident.kb.u_affected_application_sys_id;

                string payload = JsonConvert.SerializeObject(o);
                Rest rest = new Rest();
                string response = rest.Call("PUT", url, payload, ProxyHost, ProxyPort, ServiceNowUsername, ServiceNowPassword);
                JObject jsonResponse = JObject.Parse(response.ToString());
                JObject obj = (JObject)jsonResponse["result"];

                retorno.sys_id = ((JValue)obj.SelectToken("sys_id")).Value.ToString();
                retorno.number = ((JValue)obj.SelectToken("number")).Value.ToString();
                //retorno.KnowledgeDescription = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.KnowledgeId = ((JValue)obj.SelectToken("u_knowledge_id.value")).Value.ToString(); // u_knowledge_id.value
                retorno.ShortDescription = ((JValue)obj.SelectToken("short_description")).Value.ToString();
                retorno.Description = ((JValue)obj.SelectToken("description")).Value.ToString();
                //retorno.AssignamentGroupDescription = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.AssignamentGroupId = ((JValue)obj.SelectToken("assignment_group.value")).Value.ToString();
                //retorno.CallerName = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.CallerId = ((JValue)obj.SelectToken("caller_id.value")).Value.ToString();
                //retorno.DepartmentName = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.DepartmentId = ((JValue)obj.SelectToken("u_department.value")).Value.ToString();
                retorno.ClassName = ((JValue)obj.SelectToken("u_ci_class_name")).Value.ToString();
                retorno.AffectedApplication = ((JValue)obj.SelectToken("u_affected_application")).Value.ToString();
                retorno.ImpactId = ((JValue)obj.SelectToken("impact")).Value.ToString();
                retorno.UrgencyId = ((JValue)obj.SelectToken("urgency")).Value.ToString();
                //retorno.AttendantName = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.AttendantId = ((JValue)obj.SelectToken("u_serial_number")).Value.ToString();
                retorno.Comments = ((JValue)obj.SelectToken("comments")).Value.ToString();
                retorno.State = ((JValue)obj.SelectToken("state")).Value.ToString();
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.IncidentRepository.RestIncidentPut - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return retorno;
        }

        public static Incident RestIncidentPost(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain, Incident incident)
        {
            Incident retorno = new Incident();

            try
            {
                string url = string.Format("{0}/api/now/table/incident", ServiceNowUrl);

                dynamic o = new ExpandoObject();

                if (!string.IsNullOrEmpty(incident.kb.sys_id))
                    o.u_knowledge_id = incident.kb.sys_id;

                if (!string.IsNullOrEmpty(incident.ShortDescription))
                    o.short_description = incident.ShortDescription;

                if (!string.IsNullOrEmpty(incident.Notes) || !string.IsNullOrEmpty(incident.Description))
                    o.description = incident.Notes + System.Environment.NewLine + incident.Description;

                if (!string.IsNullOrEmpty(incident.CallerId))
                    o.caller_id = incident.CallerId;

                if (!string.IsNullOrEmpty(incident.DepartmentId))
                    o.u_department = incident.DepartmentId;

                if (!string.IsNullOrEmpty(incident.AssignamentGroupDescription))
                    o.assignment_group = incident.AssignamentGroupDescription;

                if (!string.IsNullOrEmpty(incident.ClassName))
                    o.u_ci_class_name = incident.ClassName;

                if (!string.IsNullOrEmpty(incident.ImpactId))
                    o.impact = incident.ImpactId;

                if (!string.IsNullOrEmpty(incident.UrgencyId))
                    o.urgency = incident.UrgencyId;

                if (!string.IsNullOrEmpty(incident.Comments))
                    o.comments = incident.Comments;

                if (!string.IsNullOrEmpty(incident.AttendantId))
                    o.u_serial_number = incident.AttendantId;

                if (!string.IsNullOrEmpty(incident.kb.u_affected_application_sys_id))
                    o.u_affected_application = incident.kb.u_affected_application_sys_id;

                string payload = JsonConvert.SerializeObject(o);
                Rest rest = new Rest();
                string response = rest.Call("POST", url, payload, ProxyHost, ProxyPort, ServiceNowUsername, ServiceNowPassword);

                JObject jsonResponse = JObject.Parse(response);
                JObject obj = (JObject)jsonResponse["result"];

                retorno.sys_id = ((JValue)obj.SelectToken("sys_id")).Value.ToString();
                retorno.number = ((JValue)obj.SelectToken("number")).Value.ToString();
                //retorno.KnowledgeDescription = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.KnowledgeId = ((JValue)obj.SelectToken("u_knowledge_id.value")).Value.ToString(); // u_knowledge_id.value
                retorno.ShortDescription = ((JValue)obj.SelectToken("short_description")).Value.ToString();
                retorno.Description = ((JValue)obj.SelectToken("description")).Value.ToString();
                //retorno.AssignamentGroupDescription = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.AssignamentGroupId = ((JValue)obj.SelectToken("assignment_group.value")).Value.ToString();
                //retorno.CallerName = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.CallerId = ((JValue)obj.SelectToken("caller_id.value")).Value.ToString();
                //retorno.DepartmentName = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.DepartmentId = ((JValue)obj.SelectToken("u_department.value")).Value.ToString();
                retorno.ClassName = ((JValue)obj.SelectToken("u_ci_class_name")).Value.ToString();
                retorno.AffectedApplication = ((JValue)obj.SelectToken("u_affected_application")).Value.ToString();
                retorno.ImpactId = ((JValue)obj.SelectToken("impact")).Value.ToString();
                retorno.UrgencyId = ((JValue)obj.SelectToken("urgency")).Value.ToString();
                //retorno.AttendantName = ((JValue)obj.SelectToken("xxxxxxxxxxxxx")).Value.ToString();
                retorno.AttendantId = ((JValue)obj.SelectToken("u_serial_number")).Value.ToString();
                retorno.Comments = ((JValue)obj.SelectToken("comments")).Value.ToString();
                retorno.State = ((JValue)obj.SelectToken("state")).Value.ToString();
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.IncidentRepository.RestIncidentPost - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return retorno;
        }

    }
}