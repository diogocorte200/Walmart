﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Web;
using ServiceNowApiInterface.Models;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;

namespace ServiceNowApiInterface.Repository
{
    public class CatalogItemRepository
    {
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ProxyUsername { get; set; }
        private string ProxyPassword { get; set; }
        private string ProxyDomain { get; set; }
        private string ServiceNowUrl { get; set; }
        private string ServiceNowUsername { get; set; }
        private string ServiceNowPassword { get; set; }

        public CatalogItemRepository()
        {
            try
            {
                this.ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
                this.ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
                this.ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
                this.ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
                this.ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];
                this.ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
                this.ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
                this.ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.CatalogItemRepository.CatalogItemRepository - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
        }

        public List<CatalogItem> GetAllCatalogItem()
        {
            List<CatalogItem> list = new List<CatalogItem>();

            try
            {
                string requestUrl = ServiceNowUrl + "/api/now/table/sc_cat_item?GET&sysparm_display_value=true&&sysparm_fields=name,sys_id&sysparm_query=active=true^u_service_ownerSTARTSWITHBR";

                string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);

                if (!string.IsNullOrEmpty(json))
                {
                    JObject joResponse = JObject.Parse(json);
                    dynamic obj = joResponse;
                    foreach (dynamic item in obj.result)
                    {
                        CatalogItem ci = new CatalogItem();
                        ci.name = item.name;
                        ci.sys_id = item.sys_id;
                        ci.link = ServiceNowUrl + "/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D" + item.sys_id;
                        list.Add(ci);
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.CatalogItemRepository.GetAllCatalogItem - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return list;
        }

        public static string CallRestMethod(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Method = "GET";
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.CatalogItemRepository.CallRestMethod - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return source;
        }


    }
}