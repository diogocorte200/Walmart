﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using ServiceNowApiInterface.Models;
using Newtonsoft.Json.Linq;

namespace ServiceNowApiInterface.Repository
{
    public class DepartmentRepository
    {
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ProxyUsername { get; set; }
        private string ProxyPassword { get; set; }
        private string ProxyDomain { get; set; }
        private string ServiceNowUrl { get; set; }
        private string ServiceNowUsername { get; set; }
        private string ServiceNowPassword { get; set; }

        public DepartmentRepository()
        {
            try
            {
                this.ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
                this.ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
                this.ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
                this.ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
                this.ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];
                this.ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
                this.ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
                this.ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.DepartmentRepository.DepartmentRepository - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
        }

        public List<Department> GetAllDepartments()
        {
            List<Department> list = new List<Department>();

            try
            {
                string requestUrl = ServiceNowUrl + "/api/now/table/cmn_department?GET&sysparm_display_value=true&sysparm_fields=id,name&sysparm_query=idENDSWITH.BR";

                string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);

                if (!string.IsNullOrEmpty(json))
                {
                    JObject joResponse = JObject.Parse(json);
                    dynamic obj = joResponse;
                    foreach (dynamic item in obj.result)
                    {
                        Department dept = new Department();
                        dept.Code = item.id;
                        dept.Name = item.name;
                        list.Add(dept);
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.DepartmentRepository.GetAllDepartments - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return list;
        }

        public static string CallRestMethod(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Method = "GET";
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.DepartmentRepository.CallRestMethod - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return source;
        }

    }
}