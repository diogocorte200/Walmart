﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using ServiceNowApiInterface.Models;
using Newtonsoft.Json.Linq;

namespace ServiceNowApiInterface.Repository
{
    public class GroupRepository
    {
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ProxyUsername { get; set; }
        private string ProxyPassword { get; set; }
        private string ProxyDomain { get; set; }
        private string ServiceNowUrl { get; set; }
        private string ServiceNowUsername { get; set; }
        private string ServiceNowPassword { get; set; }

        public GroupRepository()
        {
            try
            {
                this.ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
                this.ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
                this.ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
                this.ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
                this.ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];
                this.ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
                this.ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
                this.ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.GroupRepository.GroupRepository - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
        }

        public List<Group> GetAllGroups()
        {
            List<Group> list = new List<Group>();

            try
            {
                string requestUrl = ServiceNowUrl + "/api/now/table/sys_user_group?GET&sysparm_display_value=true&sysparm_fields=sys_id,name&sysparm_query=active=true^parentIN91085aa54fc67ec0d2d797411310c7fe,92dbf613db004700e55df5871d9619b6";

                string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);

                if (!string.IsNullOrEmpty(json))
                {
                    JObject joResponse = JObject.Parse(json);
                    dynamic obj = joResponse;
                    foreach (dynamic item in obj.result)
                    {
                        Group group = new Group();
                        group.sys_id = item.sys_id;
                        group.name = item.name;
                        list.Add(group);
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.GroupRepository.GetAllGroups - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return list;
        }

        public static string CallRestMethod(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Method = "GET";
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.GroupRepository.CallRestMethod - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return source;
        }

    }
}