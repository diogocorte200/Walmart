﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Web;
using ServiceNowApiInterface.Models;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;

namespace ServiceNowApiInterface.Repository
{
    public class KnowledgeBaseRepository
    {
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ProxyUsername { get; set; }
        private string ProxyPassword { get; set; }
        private string ProxyDomain { get; set; }
        private string ServiceNowUrl { get; set; }
        private string ServiceNowUsername { get; set; }
        private string ServiceNowPassword { get; set; }

        public KnowledgeBaseRepository()
        {
            try
            {
                this.ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
                this.ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
                this.ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
                this.ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
                this.ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];
                this.ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
                this.ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
                this.ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.KnowledgeBaseRepository.KnowledgeBaseRepository - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
        }

        public List<KnowledgeBase> GetAllKnowledgeBases()
        {
            List<KnowledgeBase> list = new List<KnowledgeBase>();

            try
            {
                string[] lstUrgency = { "1", "2", "3" };
                string[] lstImpact = { "1", "2", "3" };

                foreach (string urgency in lstUrgency)
                {
                    foreach (string impact in lstImpact)
                    {
                        string requestUrl = ServiceNowUrl + string.Format("/api/now/table/kb_knowledge?GET&sysparm_display_value=true&sysparm_fields=number,language,u_location,display_number,short_description,article_id,sys_id,text,workflow_state,u_ci_class,u_suggested_impact,u_suggested_urgency,u_assignment_group.sys_id,u_assignment_group.name,u_affected_application.sys_id,u_affected_application.name&sysparm_query=active=true^workflow_stateINpublished,outdated^language=pb^workflow_state=Published^u_suggested_urgency={0}^u_suggested_impact={1}", urgency, impact);

                        string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);

                        if (!string.IsNullOrEmpty(json))
                        {
                            json = json.Replace("u_assignment_group.sys_id", "u_assignment_group_sys_id").Replace("u_assignment_group.name", "u_assignment_group_name").Replace("u_affected_application.sys_id", "u_affected_application_sys_id").Replace("u_affected_application.name", "u_affected_application_name");
                            json = json.Replace("&amp;lt;", "<").Replace("&gt;", ">");

                            JObject joResponse = JObject.Parse(json);
                            dynamic obj = joResponse;
                            foreach (dynamic item in obj.result)
                            {
                                KnowledgeBase kb = new KnowledgeBase();
                                kb.number = item.number;
                                kb.language = item.language;
                                kb.u_location = item.u_location;
                                kb.display_number = item.display_number;
                                kb.short_description = item.short_description;
                                kb.article_id = item.article_id;
                                kb.sys_id = item.sys_id;
                                kb.text = item.text;
                                kb.workflow_state = item.workflow_state;
                                kb.u_ci_class = item.u_ci_class;
                                kb.u_suggested_impact = item.u_suggested_impact;
                                kb.u_suggested_urgency = item.u_suggested_urgency;
                                kb.u_assignment_group_sys_id = item.u_assignment_group_sys_id;
                                kb.u_assignment_group_name = item.u_assignment_group_name;
                                kb.u_affected_application_sys_id = item.u_affected_application_sys_id;
                                kb.u_affected_application_name = item.u_affected_application_name;
                                list.Add(kb);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.KnowledgeBaseRepository.GetAllKnowledgeBases - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\","ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return list;
        }

        public static string CallRestMethod(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Method = "GET";
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.KnowledgeBaseRepository.CallRestMethod - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return source;
        }

    }
}