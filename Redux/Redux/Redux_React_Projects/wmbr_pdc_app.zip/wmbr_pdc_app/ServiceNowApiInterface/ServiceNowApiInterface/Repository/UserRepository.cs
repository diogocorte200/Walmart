﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using ServiceNowApiInterface.Models;
using Newtonsoft.Json.Linq;
using System.Net;
using System.IO;

namespace ServiceNowApiInterface.Repository
{
    public class UserRepository
    {
        private string ProxyHost { get; set; }
        private int ProxyPort { get; set; }
        private string ProxyUsername { get; set; }
        private string ProxyPassword { get; set; }
        private string ProxyDomain { get; set; }
        private string ServiceNowUrl { get; set; }
        private string ServiceNowUsername { get; set; }
        private string ServiceNowPassword { get; set; }

        public UserRepository()
        {
            try
            {
                this.ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
                this.ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
                this.ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
                this.ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
                this.ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];
                this.ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
                this.ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
                this.ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.UserRepository.UserRepository - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }
        }

        public List<User> GetAllUsers()
        {
            List<User> list = new List<User>();

            try
            {
                string[] iniciais = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
                //string[] iniciais = { "p","r" };
                //string[] iniciais = { "p" };

                foreach (string inicial in iniciais)
                {
                    string requestUrl = ServiceNowUrl + "/api/now/table/sys_user?GET&sysparm_display_value=true&sysparm_fields=sys_id,user_name,name,department.id,department.name,email&sysparm_query=active=true^country=BR^nameSTARTSWITH" + inicial;

                    string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);
                    json = json.Replace("department.id", "department_id").Replace("department.name", "department_name");

                    if (!string.IsNullOrEmpty(json))
                    {
                        JObject joResponse = JObject.Parse(json);
                        dynamic obj = joResponse;
                        foreach (dynamic item in obj.result)
                        {
                            User user = new User();
                            user.sys_id = item.sys_id;
                            user.user_name = item.user_name;
                            user.name = item.name;
                            user.display = string.Format("{0} ({1})", user.name, user.user_name);
                            user.department_code = item.department_id;
                            user.department_name = item.department_name;
                            user.email = item.email;
                            list.Add(user);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.UserRepository.GetAllUsers - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return list;
        }

        public User GetUserByLogin(string login)
        {
            User user = new User();

            try
            {
                string requestUrl = ServiceNowUrl + "/api/now/table/sys_user?GET&sysparm_display_value=true&sysparm_fields=sys_id,user_name,name,department.code,department.name,email&sysparm_query=active=true^user_name=" + login;

                string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);
                json = json.Replace("department.code", "department_code").Replace("department.name", "department_name");

                if (!string.IsNullOrEmpty(json))
                {
                    JObject joResponse = JObject.Parse(json);
                    dynamic obj = joResponse;
                    foreach (dynamic item in obj.result)
                    {
                        user.sys_id = item.sys_id;
                        user.user_name = item.user_name;
                        user.name = item.name;
                        user.display = string.Format("{0} ({1})", user.name, user.user_name);
                        user.department_code = item.department_code;
                        user.department_name = item.department_name;
                        user.email = item.email;
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.UserRepository.GetUserByLogin - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return user;
        }

        public static string CallRestMethod(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Method = "GET";
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                string msg = "ServiceNowApiInterface.Repository.UserRepository.CallRestMethod - ERRO: " + ex.Message;
                LogRepository.Files(AppDomain.CurrentDomain.BaseDirectory + "log\\", "ServiceNowApiInterfaceLog_" + DateTime.Now.ToString("yyyyMMdd") + ".log", msg, true, true);
            }

            return source;
        }

    }
}