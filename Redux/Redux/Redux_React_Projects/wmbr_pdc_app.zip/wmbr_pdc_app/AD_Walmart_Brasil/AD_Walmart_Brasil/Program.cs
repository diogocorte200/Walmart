﻿using System;
using System.Text;

namespace AD_Walmart_Brasil
{
    class Program
    {
        public static string atendente_login;
        public static string atendente_id;

        static void Main(string[] args)
        {

            //ServiceNow snowt = new ServiceNow();
            //snowt.CancelaRitm("e24effe8dba9af80cdc832ad7c961903");
            ////snowt.CancelaRitm("e24effe8dba9af80cdc832ad7c961903");



            atendente_login = Environment.UserName;
            ServiceNow snow = new ServiceNow();
            atendente_id = snow.GetUserId(atendente_login);

            int opcPrincipal = 0;
            while (!opcPrincipal.Equals(3))
            {
                opcPrincipal = MenuPrincipal();
                switch (opcPrincipal)
                {
                    case 1:
                        string retAcaoAD = string.Empty;
                        while (!retAcaoAD.Equals("0"))
                        {
                            retAcaoAD = MenuAcaoAD();
                            if (!retAcaoAD.Equals("0"))
                            {
                                Ad ad = new Ad(retAcaoAD);
                                if (ConfirmaAcaoAd(ad))
                                {
                                    if (ad.inativo)
                                    {
                                        string retInativo = string.Empty;
                                        while (retInativo.Equals(string.Empty))
                                        {
                                            retInativo = MenuInatividade(ad);
                                        }
                                        retAcaoAD = "0";
                                    }
                                    else if (ad.expirado && !ad.descricao.ToUpper().Contains("-D") && !ad.descricao.ToUpper().Contains("DISABLED BY INFORMATION SECURITY") && !ad.descricao.ToUpper().Contains("UPDATED BY WMACCTCREATION") && !ad.descricao.ToUpper().Contains("DISABLED BY WMACCTCREATION"))
                                    {
                                        int opcExpirado = 0;
                                        while (!opcExpirado.Equals(4))
                                        {
                                            opcExpirado = MenuExpiracao(ad);
                                            switch (opcExpirado)
                                            {
                                                case 1:
                                                    MostraExpiracaoFerias(ad);
                                                    opcExpirado = 4;
                                                    retAcaoAD = "0";
                                                    break;

                                                case 2:
                                                    MostraExpiracaoSemFerias(ad);
                                                    opcExpirado = 4;
                                                    retAcaoAD = "0";
                                                    break;

                                                case 3:
                                                    MostraExpiracaoTerceiro(ad);
                                                    opcExpirado = 4;
                                                    retAcaoAD = "0";
                                                    break;

                                                default:
                                                    break;
                                            }
                                        }
                                    }
                                    else if (ad.bloqueado && !ad.descricao.ToUpper().Contains("-D") && !ad.descricao.ToUpper().Contains("DISABLED BY INFORMATION SECURITY") && !ad.descricao.ToUpper().Contains("UPDATED BY WMACCTCREATION") && !ad.descricao.ToUpper().Contains("DISABLED BY WMACCTCREATION"))
                                    {
                                        int opcBloqueado = 0;
                                        while (!opcBloqueado.Equals(3))
                                        {
                                            opcBloqueado = MenuBloqueio(ad);
                                            switch (opcBloqueado)
                                            {
                                                case 1:
                                                    MostraDesbloqueio(ad);
                                                    opcBloqueado = 3;
                                                    retAcaoAD = "0";
                                                    break;

                                                case 2:
                                                    MostraDesbloqueioReset(ad);
                                                    opcBloqueado = 3;
                                                    retAcaoAD = "0";
                                                    break;

                                                default:
                                                    break;
                                            }
                                        }
                                    }
                                    else if (ad.descricao.ToUpper().Contains("UPDATED BY WMACCTCREATION"))
                                    {
                                        MostraEmCriacao(ad);
                                    }
                                    else if (ad.descricao.ToUpper().Contains("DISABLED BY WMACCTCREATION"))
                                    {
                                        MostraRemovidoBTV(ad);
                                    }
                                    else if (ad.descricao.ToUpper().Contains("DISABLED BY INFORMATION SECURITY"))
                                    {
                                        MostraRestricaoBTV(ad);
                                    }
                                    else if (ad.desabilitado && !ad.descricao.ToUpper().Contains("-D") && !ad.descricao.ToUpper().Contains("DISABLED BY INFORMATION SECURITY") && !ad.descricao.ToUpper().Contains("UPDATED BY WMACCTCREATION") && !ad.descricao.ToUpper().Contains("DISABLED BY WMACCTCREATION"))
                                    {
                                        MostraDesabilitado(ad);
                                    }
                                    else if (ad.descricao.ToUpper().Contains("-D"))
                                    {
                                        MostraVerificar(ad);
                                    }
                                    else if (!ad.bloqueado && !ad.descricao.ToUpper().Contains("-D") && !ad.descricao.ToUpper().Contains("DISABLED BY INFORMATION SECURITY") && !ad.descricao.ToUpper().Contains("UPDATED BY WMACCTCREATION") && !ad.descricao.ToUpper().Contains("DISABLED BY WMACCTCREATION"))
                                    {
                                        int opcReset = 0;
                                        while (!opcReset.Equals(3))
                                        {
                                            opcReset = MenuReset(ad);
                                            switch (opcReset)
                                            {
                                                case 1:
                                                    MostraReset(ad);
                                                    opcReset = 3;
                                                    retAcaoAD = "0";
                                                    break;

                                                case 2:
                                                    MostraNaoReset(ad);
                                                    opcReset = 3;
                                                    retAcaoAD = "0";
                                                    break;

                                                default:
                                                    break;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        MostraDesconhecido(ad);
                                    }
                                }
                            }
                        }
                        break;

                    case 2:
                        string retGrupos = string.Empty;
                        while (!retGrupos.Equals("0"))
                        {
                            retGrupos = MenuGrupos();
                            if (!retGrupos.Equals("0"))
                            {
                                Ad ad = new Ad(retGrupos);
                                retGrupos = MostraGrupos(ad);
                            }
                        }
                        break;

                    default:
                        break;
                }
            }
        }

        static int MenuPrincipal()
        {
            int opcao = 0;
            while (!opcao.Equals(1) && !opcao.Equals(2) && !opcao.Equals(3))
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine("================ AD Walmart Brasil ================");
                Console.WriteLine();
                Console.WriteLine("1 - Consultar/Desbloquear/Resetar Usuário AD");
                Console.WriteLine("2 - Consultar Grupos do AD");
                Console.WriteLine("3 - Sair");
                Console.WriteLine();
                Console.Write("Digite a opção desejada: ");
                string tecla = Console.ReadLine(); //Console.ReadKey().KeyChar.ToString();
                int.TryParse(tecla, out opcao);
            }
            return opcao;
        }

        static string MenuGrupos()
        {
            string retorno = string.Empty;
            while (!retorno.Trim().Equals("0") && retorno.Trim().Length.Equals(0))
            {
                retorno = string.Empty;
                Console.Clear();
                Console.WriteLine("============= Consultar Grupos do AD ==============");
                Console.WriteLine();
                Console.Write("Informe o usuário ou CPF para consulta (0 para sair): ");
                retorno = Console.ReadLine(); //readLineWithCancel();
            }
            Console.WriteLine("Aguarde a consulta.");
            return retorno;
        }

        static string MostraGrupos(Ad ad)
        {
            string ret = "0";
            Console.Clear();
            Console.WriteLine("============= Consultar Grupos do AD ==============");
            Console.WriteLine();
            if (ad.erro)
            {
                ret = "1";
                Console.WriteLine(ad.mensagem);
            }
            else
            {
                Console.WriteLine("Usuário: {0}", ad.user);
                Console.WriteLine("Nome: {0}", ad.nome);
                Console.WriteLine("CPF: {0}", ad.cpf);
                Console.WriteLine("Email: {0}", ad.email);
                Console.WriteLine("Telefone: {0}", ad.telefone);
                Console.WriteLine("Associado com acesso a Internet: {0}", (ad.acesso_internet ? "SIM" : "NÃO"));
                Console.WriteLine("Associado com acesso a VPN: {0}", (ad.acesso_vpn ? "SIM" : "NÃO"));
            }
            Console.WriteLine();
            Console.Write("Pressione qualquer tecla para voltar.");
            Console.ReadKey();
            return ret;
        }

        static string MenuAcaoAD()
        {
            string retorno = string.Empty;
            while (!retorno.Trim().Equals("0") && retorno.Trim().Length.Equals(0))
            {
                retorno = string.Empty;
                Console.Clear();
                Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
                Console.WriteLine();
                Console.Write("Informe o usuário ou CPF para consulta (0 para sair): ");
                retorno = Console.ReadLine(); //readLineWithCancel();
            }
            Console.WriteLine("Aguarde a consulta.");
            return retorno;
        }

        static bool ConfirmaAcaoAd(Ad ad)
        {
            bool retorno = false;

            int opcao = 0;
            while (!opcao.Equals(1) && !opcao.Equals(2))
            {
                Console.Clear();
                Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
                Console.WriteLine();
                if (ad.erro)
                {
                    opcao = 2;
                    Console.WriteLine(ad.mensagem);
                    Console.WriteLine();
                    Console.Write("Pressione qualquer tecla para voltar.");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Usuário: {0}", ad.user);
                    Console.WriteLine("Nome: {0}", ad.nome);
                    Console.WriteLine("CPF: {0}", ad.cpf);
                    Console.WriteLine();
                    Console.Write("Dados corretos? (1 - Sim / 2 - Não): ");
                    string tecla = Console.ReadLine(); //Console.ReadKey().KeyChar.ToString();
                    int.TryParse(tecla, out opcao);
                }
            }

            retorno = opcao.Equals(1);

            return retorno;
        }

        static string MenuInatividade(Ad ad)
        {
            string retorno = string.Empty;
            while (!retorno.Trim().Equals("0") && retorno.Trim().Length.Equals(0))
            {
                retorno = string.Empty;
                Console.Clear();
                Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
                Console.WriteLine();
                Console.WriteLine("Usuário {0} está desabilitado por inatividade", ad.user);
                Console.WriteLine();
                Console.Write("Informe o CPF para abertura do chamado (0 para sair): ");
                retorno = Console.ReadLine(); //readLineWithCancel();
                long teste = 0;
                if (retorno.Trim().Length == 11 && long.TryParse(retorno.Trim(), out teste))
                {
                    Console.WriteLine("Aguarde abertura do chamado.");

                    ad.cpf = retorno.Trim();

                    ServiceNow snow = new ServiceNow();
                    Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoLoginInativo);
                    string description = artigo.u_issue.Replace("<1>XXX<1>", "<1>SIM<1>").Replace("<2>XXXX<2>", string.Format("<2>{0}<2>", ad.user)).Replace("<3>XXXX<3>", string.Format("<3>{0}<3>", ad.cpf));
                    description = description.Replace("&amp;lt;1&gt;XXX&amp;lt;1&gt;", "<1>SIM<1>").Replace("&amp;lt;2&gt;XXXX&amp;lt;2&gt;", string.Format("<2>{0}<2>", ad.user)).Replace("&amp;lt;3&gt;XXXX&amp;lt;3&gt;", string.Format("<3>{0}<3>", ad.cpf));
                    description = description.Replace("&#34;", "\"");
                    description = description.Replace("Nome completo:", "Nome completo: " + (string.IsNullOrEmpty(ad.nome) ? string.Empty : ad.nome));
                    description = description.Replace("Telefone de contato:", "Telefone de contato: " + (string.IsNullOrEmpty(ad.telefone) ? string.Empty : ad.telefone));
                    description = description.Replace("E-mail (Walmart):", "E-mail (Walmart): " + (string.IsNullOrEmpty(ad.email) ? string.Empty : ad.email));
                    Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaAutomacao, ad.user, artigo.short_description, description);

                    retorno = "0";
                    Console.WriteLine();
                    Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
                    Console.ReadKey();
                }
                else
                {
                    if (!retorno.Equals("0"))
                    {
                        retorno = string.Empty;
                        Console.Write("CPF inválido. Pressione qualquer tecla para voltar.");
                        Console.ReadKey();
                    }
                }
            }
            return retorno;
        }

        static int MenuExpiracao(Ad ad)
        {
            int opcao = 0;
            while (!opcao.Equals(1) && !opcao.Equals(2) && !opcao.Equals(3) && !opcao.Equals(4))
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
                Console.WriteLine();
                Console.WriteLine("Usuário {0} está expirado", ad.user);
                Console.WriteLine();
                Console.WriteLine("1 - Usuário é associado retornando férias");
                Console.WriteLine("2 - Usuário é associado não retornando férias");
                Console.WriteLine("3 - Usuário é Terceiro");
                Console.WriteLine("4 - Voltar");
                Console.WriteLine();
                Console.Write("Digite a opção desejada: ");
                string tecla = Console.ReadLine(); //Console.ReadKey().KeyChar.ToString();
                int.TryParse(tecla, out opcao);
            }
            return opcao;
        }

        static void MostraExpiracaoFerias(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Associado deve entrar em contato com capital humano.");
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Associado deve entrar em contato com o Capital Humano";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraExpiracaoSemFerias(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoLoginExpirado);

                string description = artigo.u_issue;
                description = description.Replace("Nome completo:", string.Format("Nome completo: {0}", (string.IsNullOrEmpty(ad.nome) ? string.Empty : ad.nome)));
                description = description.Replace("Telefone de contato:", string.Format("Telefone de contato: {0}", (string.IsNullOrEmpty(ad.telefone) ? string.Empty : ad.telefone)));
                description = description.Replace("Login de rede (Walmart):", string.Format("Login de rede (Walmart): {0}", (string.IsNullOrEmpty(ad.user) ? string.Empty : ad.user)));
                description = description.Replace("Qual o nome completo?", string.Format("Qual o nome completo? {0}", (string.IsNullOrEmpty(ad.nome) ? string.Empty : ad.nome)));
                description = description.Replace("Qual o CPF do associado?", string.Format("Qual o CPF do associado? {0}", (string.IsNullOrEmpty(ad.cpf) ? string.Empty : ad.cpf)));
                description = description + Environment.NewLine + "Associado informa que não está conseguindo logar.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaInfoSec, ad.user, artigo.short_description, description);

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraExpiracaoTerceiro(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Associado deve entrar em contato com seu gestor.");
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Associado deve entrar em contato com seu gestor para alterar a data de expiração";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }
                
                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static int MenuBloqueio(Ad ad)
        {
            int opcao = 0;
            while (!opcao.Equals(1) && !opcao.Equals(2) && !opcao.Equals(3))
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
                Console.WriteLine();
                Console.WriteLine("Usuário {0} está bloqueado", ad.user);
                Console.WriteLine();
                Console.WriteLine("1 - Desbloquear");
                Console.WriteLine("2 - Desbloquear e resetar senha");
                Console.WriteLine("3 - Voltar");
                Console.WriteLine();
                Console.Write("Digite a opção desejada: ");
                string tecla = Console.ReadLine();  //Console.ReadKey().KeyChar.ToString();
                int.TryParse(tecla, out opcao);
            }
            return opcao;
        }

        static void MostraDesbloqueio(Ad ad)
        {
            ad.Desbloqueio();

            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Usuário {0} foi desbloqueado com sucesso.", ad.user); ;
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Desbloqueio do usuário realizado com sucesso";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraDesbloqueioReset(Ad ad)
        {
            ad.Desbloqueio();
            if (!ad.erro)
            {
                ad.Resetsenha();
            }

            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Usuário {0} foi desbloqueado com sucesso.", ad.user); ;
                Console.WriteLine("A nova senha é {0}", ad.senha);
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Desbloqueio e reset de senha do usuário realizado com sucesso. Nova senha informada por telefone.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraEmCriacao(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Usuário {0} está em criação e deve aguardar.", ad.user);
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Associado está em processo de criação e deve aguardar até o final deste processo.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraRemovidoBTV(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("O acesso do usuario {0} foi removido por BTV provalmente por falta de uso.", ad.user);
                Console.WriteLine("Por favor realizar consulta CPF do associado no IDM para verificar status do associado.");
                Console.WriteLine("- Se status Ativo: Associado deve solicitar acesso novamente.");
                Console.WriteLine("- Se status Férias, Desabilitado ou Demitido: Entrar em contato com Capital Humano para enviar carga para IDM/AD.");
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "O acesso do associado foi removido por BTV, provavelmente por falta de uso.\n.Favor realizar consulta no IDM para verificar status do associado.\n- Se status Ativo: associado deve solicitar acesso novamente.\n- Se status Férias/Desabilitado/Demitido: entrar em contato com Capital Humano para enviar carga para IDM/AD, após usuário ficar ativo no IDM deve solicitar acesso novamente.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraRestricaoBTV(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("O usuário {0} teve restriçãoo de acesso aplicada por BTV. O Associado deve verificar com seu gestor, pois está recebendo e-mail de BTV.", ad.user);
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Restrição de uso aplicada por BTV. O Associado deve verificar com seu gestor, pois está recebendo e-mail de BTV.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraDesabilitado(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("O usuário {0} está desabilitado.", ad.user);
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoLoginDesabilitado);
                string description = artigo.u_issue;
                description = description.Replace("Nome completo:", string.Format("Nome completo: {0}", (string.IsNullOrEmpty(ad.nome) ? string.Empty : ad.nome)));
                description = description.Replace("Telefone de contato:", string.Format("Telefone de contato: {0}", (string.IsNullOrEmpty(ad.telefone) ? string.Empty : ad.telefone)));
                description = description.Replace("Login de rede (Walmart):", string.Format("Login de rede (Walmart): {0}", (string.IsNullOrEmpty(ad.user) ? string.Empty : ad.user)));
                description = description.Replace("Qual o nome completo?", string.Format("Qual o nome completo? {0}", (string.IsNullOrEmpty(ad.nome) ? string.Empty : ad.nome)));
                description = description.Replace("Qual o CPF do associado?", string.Format("Qual o CPF do associado? {0}", (string.IsNullOrEmpty(ad.cpf) ? string.Empty : ad.cpf)));
                description = description + Environment.NewLine + "Associado informa que não está conseguindo logar.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaInfoSec, ad.user, artigo.short_description, description);

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraVerificar(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("O usuário {0} deve entrar em contato com Capital Humano para verificar Carga IDM/AD");
                Console.WriteLine("Atenção: Somente passar esta orientação ao usuário.", ad.user);
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Associado foi orientando a entrar em contato com Capital Humano para verificar a carga IDM/AD.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static int MenuReset(Ad ad)
        {
            int opcao = 0;
            while (!opcao.Equals(1) && !opcao.Equals(2) && !opcao.Equals(3))
            {
                opcao = 0;
                Console.Clear();
                Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
                Console.WriteLine();
                Console.WriteLine("Usuário {0} não está bloqueado.", ad.user);
                Console.WriteLine();
                Console.WriteLine("1 - Resetar a senha");
                Console.WriteLine("2 - Não resetar a senha");
                Console.WriteLine("3 - Voltar");
                Console.WriteLine();
                Console.Write("Digite a opção desejada: ");
                string tecla = Console.ReadLine(); //Console.ReadKey().KeyChar.ToString();
                int.TryParse(tecla, out opcao);
            }
            return opcao;
        }

        static void MostraReset(Ad ad)
        {
            ad.Resetsenha();

            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("A nova senha é {0}", ad.senha);
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Reset de senha do usuário realizado com sucesso. Nova senha informada por telefone.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraNaoReset(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("Aguarde abertura do chamado.");

                ServiceNow snow = new ServiceNow();
                Artigo artigo = snow.GetArtigo(snow.ServiceNowArtigoResetSenhaAD);
                string description = artigo.u_issue.Replace("Qual o CPF?", string.Format("Qual o CPF? {0}{1}Associado informa que não está conseguindo logar.", ad.cpf, Environment.NewLine));
                string comentario = "Usuário decidiu não realizar o reset de sua senha.";
                Chamado chamado = snow.CriaChamado(atendente_login, artigo.sys_id, snow.ServiceNowFilaServiceDesk, ad.user, artigo.short_description, description);
                if (!string.IsNullOrEmpty(chamado.sys_id))
                {
                    chamado = snow.ResolveChamado(chamado.sys_id, null, atendente_login, DateTime.Now, comentario);
                }

                Console.WriteLine();
                Console.Write("O chamado {0} foi registrado no ServiceNow. Pressione qualquer tecla para voltar.", chamado.number);
            }
            Console.ReadKey();
        }

        static void MostraDesconhecido(Ad ad)
        {
            Console.Clear();
            Console.WriteLine("==== Consultar/Desbloquear/Resetar Usuário AD =====");
            Console.WriteLine();
            if (ad.erro)
            {
                Console.WriteLine(ad.mensagem);
                Console.WriteLine();
                Console.Write("Pressione qualquer tecla para voltar.");
            }
            else
            {
                Console.WriteLine("O usuário {0} está com problema desconhecido, por favor abra um chamado para equipe INFOSEC verificar a oportunidade.");
            }
            Console.ReadKey();
        }

        //private static string readLineWithCancel()
        //{
        //    string result = null;

        //    StringBuilder buffer = new StringBuilder();

        //    //The key is read passing true for the intercept argument to prevent
        //    //any characters from displaying when the Escape key is pressed.
        //    ConsoleKeyInfo info = Console.ReadKey(true);
        //    while (info.Key != ConsoleKey.Enter && info.Key != ConsoleKey.Escape)
        //    {
        //        Console.Write(info.KeyChar);
        //        buffer.Append(info.KeyChar);
        //        info = Console.ReadKey(true);
        //    } 

        //    if (info.Key == ConsoleKey.Enter)
        //    {
        //        result = buffer.ToString();
        //    }
        //    else if (info.Key == ConsoleKey.Escape)
        //    {
        //        result = "[ESC]";
        //    }

        //    return result;
        //}

    }
}
