﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AD_Walmart_Brasil
{
    public class Ad
    {
        public string WalmartDomain = ConfigurationManager.AppSettings["WalmartDomain"];
        public string UserAcessAD = ConfigurationManager.AppSettings["UserAcessAD"];
        public string PasswordAcessAD = ConfigurationManager.AppSettings["Password_Acess_AD"];
        public string MensagemInativoAD = ConfigurationManager.AppSettings["MensagemInativoAD"];

        public string user { get; set; }
        public string cpf { get; set; }
        public string nome { get; set; }
        public string nome_primeiro { get; set; }
        public string nome_meio { get; set; }
        public string nome_ultimo { get; set; }
        public string email { get; set; }
        public string telefone { get; set; }
        public string descricao { get; set; }
        public string senha { get; set; }


        public bool desabilitado { get; set; }
        public bool bloqueado { get; set; }
        public bool expirado { get; set; }
        public bool inativo { get; set; }
        public bool acesso_internet { get; set; }
        public bool acesso_vpn { get; set; }

        public bool erro { get; set; }
        public string mensagem { get; set; }


        public Ad(string info)
        {
            this.user = string.Empty;
            this.cpf = string.Empty;
            this.nome = string.Empty;
            this.nome_primeiro = string.Empty;
            this.nome_meio = string.Empty;
            this.nome_ultimo = string.Empty;
            this.email = string.Empty;
            this.telefone = string.Empty;
            this.descricao = string.Empty;
            this.senha = string.Empty;

            this.desabilitado = false;
            this.bloqueado = false;
            this.expirado = false;
            this.inativo = false;
            this.acesso_internet = false;
            this.acesso_vpn = false;

            this.erro = false;
            this.mensagem = string.Empty;

            long teste = 0;
            if (info.Length == 11 && long.TryParse(info, out teste))
            {
                try
                {
                    using (var domainContext = new PrincipalContext(ContextType.Domain, this.WalmartDomain, this.UserAcessAD, this.PasswordAcessAD))
                    {
                        try
                        {
                            int tamanho = domainContext.ConnectedServer.Length;
                        }
                        catch (Exception)
                        {
                            this.erro = true;
                            this.mensagem = "Erro no usuário de autenticação do AD.";
                        }

                        if (!this.erro)
                        {
                            UserPrincipal usr = new UserPrincipal(domainContext);
                            usr.Description = info;
                            PrincipalSearcher sch = new PrincipalSearcher(usr);
                            int qtd = 0;
                            foreach (var found in sch.FindAll())
                            {
                                qtd++;
                                this.user = found.SamAccountName;
                            }

                            if (qtd == 0)
                            {
                                this.erro = true;
                                this.mensagem = "Nenhum usuário encontrado com o CPF informado.";
                            }
                            else if (qtd > 1)
                            {
                                this.erro = true;
                                this.mensagem = "Mais do que um usuário encontrado com o CPF informado.";
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    this.erro = true;
                    this.mensagem = string.Format("Falha ao consultar dados do usuário {0}: {1}", this.user, e.Message);
                }

            }
            else
            {
                if (string.IsNullOrEmpty(info))
                {
                    this.erro = true;
                    this.mensagem = "Não foi informado um usuário ou CPF.";
                }
                else
                {
                    this.user = info;
                }
            }

            if (!this.erro)
            {
                try
                {
                    using (var domainContext = new PrincipalContext(ContextType.Domain, this.WalmartDomain, this.UserAcessAD, this.PasswordAcessAD))
                    {
                        try
                        {
                            int tamanho = domainContext.ConnectedServer.Length;
                        }
                        catch (Exception)
                        {
                            this.erro = true;
                            this.mensagem = "Erro no usuário de autenticação do AD.";
                        }

                        if (!this.erro)
                        {
                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, System.DirectoryServices.AccountManagement.IdentityType.SamAccountName, this.user))
                            {
                                if (foundUser == null)
                                {
                                    this.erro = true;
                                    this.mensagem = string.Format("Usuário {0} não encontrado no AD.", this.user);
                                }
                                else
                                {
                                    this.user = !string.IsNullOrEmpty(foundUser.SamAccountName) ? foundUser.SamAccountName.Trim() : null;
                                    this.cpf = !string.IsNullOrEmpty(foundUser.Description) ? foundUser.Description.Trim().Length.Equals(11) ? foundUser.Description.Trim() : null : null;
                                    this.nome = !string.IsNullOrEmpty(foundUser.DisplayName) ? foundUser.DisplayName.Trim() : null;
                                    this.nome_primeiro = !string.IsNullOrEmpty(foundUser.GivenName) ? foundUser.GivenName.Trim() : null;
                                    this.nome_meio = !string.IsNullOrEmpty(foundUser.MiddleName) ? foundUser.MiddleName.Trim() : null;
                                    this.nome_ultimo = !string.IsNullOrEmpty(foundUser.Surname) ? foundUser.Surname.Trim() : null;
                                    this.email = !string.IsNullOrEmpty(foundUser.EmailAddress) ? foundUser.EmailAddress.ToLower().Trim() : null;
                                    this.telefone = !string.IsNullOrEmpty(foundUser.VoiceTelephoneNumber) ? foundUser.VoiceTelephoneNumber.Trim() : null;
                                    this.descricao = !string.IsNullOrEmpty(foundUser.Description) ? foundUser.Description.Trim() : null;

                                    this.desabilitado = !foundUser.Enabled == true;
                                    this.bloqueado = foundUser.IsAccountLockedOut();
                                    this.expirado = foundUser.AccountExpirationDate != null && Convert.ToDateTime(foundUser.AccountExpirationDate).AddDays(-1) < DateTime.Now.Date;
                                    this.inativo = foundUser.Description.Equals(this.MensagemInativoAD);

                                    var groups = foundUser.GetGroups();
                                    foreach (var group in groups)
                                    {

                                        if (group.Name.Contains("Internet"))
                                        {
                                            this.acesso_internet = true;
                                        }
                                        if (group.Name.Contains("TOKEN") || group.Name.Contains("VPN"))
                                        {
                                            this.acesso_vpn = true;
                                        }
                                        if (this.acesso_internet && this.acesso_vpn)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
                catch (Exception e)
                {
                    this.erro = true;
                    this.mensagem = string.Format("Falha ao consultar dados do usuário {0}: {1}", this.user, e.Message);
                }
            }
        }

        public void Resetsenha()
        {
            using (var domainContext = new PrincipalContext(ContextType.Domain, this.WalmartDomain, this.UserAcessAD, this.PasswordAcessAD))
            {
                try
                {
                    int tamanho = domainContext.ConnectedServer.Length;
                }
                catch (Exception)
                {
                    this.erro = true;
                    this.mensagem = "Erro no usuário de autenticação do AD.";
                }

                if (!this.erro)
                {
                    using (var foundUser = UserPrincipal.FindByIdentity(domainContext, System.DirectoryServices.AccountManagement.IdentityType.SamAccountName, this.user))
                    {
                        if (foundUser == null)
                        {
                            this.erro = true;
                            this.mensagem = string.Format("Usuário {0} não encontrado no AD.", this.user);
                        }
                        else
                        {
                            try
                            {
                                Random randNum = new Random();
                                int num = randNum.Next(0, 999999);
                                string senha = "Wa!mart" + ("000000" + num.ToString()).Substring(num.ToString().Length, 6);
                                foundUser.SetPassword(senha);
                                foundUser.Save();
                                this.senha = senha;
                            }
                            catch (Exception ex)
                            {
                                this.erro = true;
                                this.mensagem = "Erro no reset de senha do AD: " + ex.Message;
                            }
                        }
                    }
                }

            }
        }

        public void Desbloqueio()
        {
            if (this.bloqueado)
            {
                using (var domainContext = new PrincipalContext(ContextType.Domain, this.WalmartDomain, this.UserAcessAD, this.PasswordAcessAD))
                {
                    try
                    {
                        int tamanho = domainContext.ConnectedServer.Length;
                    }
                    catch (Exception)
                    {
                        this.erro = true;
                        this.mensagem = "Erro no usuário de autenticação do AD.";
                    }

                    if (!this.erro)
                    {
                        using (var foundUser = UserPrincipal.FindByIdentity(domainContext, System.DirectoryServices.AccountManagement.IdentityType.SamAccountName, this.user))
                        {
                            if (foundUser == null)
                            {
                                this.erro = true;
                                this.mensagem = string.Format("Usuário {0} não encontrado no AD.", this.user);
                            }
                            else
                            {
                                foundUser.UnlockAccount();
                                this.bloqueado = foundUser.IsAccountLockedOut();
                                foundUser.Save();
                            }
                        }
                    }

                }
            }
            else
            {
                this.erro = true;
                this.mensagem = string.Format("Usuário {0} não está bloqueado.", this.user);
            }
        }

    }
}
