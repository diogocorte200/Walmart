﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Net;
using System.IO;
using System.Data;
using Newtonsoft.Json;
using System.Dynamic;
using Newtonsoft.Json.Linq;

namespace AD_Walmart_Brasil
{
    public class ServiceNow
    {
        public string ServiceNowUrl = ConfigurationManager.AppSettings["ServiceNowUrl"];
        public string ServiceNowUsername = ConfigurationManager.AppSettings["ServiceNowUsername"];
        public string ServiceNowPassword = ConfigurationManager.AppSettings["ServiceNowPassword"];
        public string ProxyHost = ConfigurationManager.AppSettings["ProxyHost"];
        public int ProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);
        public string ProxyUsername = ConfigurationManager.AppSettings["ProxyUsername"];
        public string ProxyPassword = ConfigurationManager.AppSettings["ProxyPassword"];
        public string ProxyDomain = ConfigurationManager.AppSettings["ProxyDomain"];

        public string ServiceNowStatusNovo = ConfigurationManager.AppSettings["ServiceNowStatusNovo"];
        public string ServiceNowStatusResolvido = ConfigurationManager.AppSettings["ServiceNowStatusResolvido"];

        public string ServiceNowClasse = ConfigurationManager.AppSettings["ServiceNowClasse"];

        public string ServiceNowFilaAutomacao = ConfigurationManager.AppSettings["ServiceNowFilaAutomacao"];
        public string ServiceNowFilaServiceDesk = ConfigurationManager.AppSettings["ServiceNowFilaServiceDesk"];
        public string ServiceNowFilaInfoSec = ConfigurationManager.AppSettings["ServiceNowFilaInfoSec"];

        public string ServiceNowArtigoLoginInativo = ConfigurationManager.AppSettings["ServiceNowArtigoLoginInativo"];
        public string ServiceNowArtigoLoginExpirado = ConfigurationManager.AppSettings["ServiceNowArtigoLoginExpirado"];
        public string ServiceNowArtigoLoginDesabilitado = ConfigurationManager.AppSettings["ServiceNowArtigoLoginDesabilitado"];
        public string ServiceNowArtigoResetSenhaAD = ConfigurationManager.AppSettings["ServiceNowArtigoResetSenhaAD"];


        //public void CancelaRitm(string id)
        //{
        //    string requestUrl = string.Format("{0}/api/now/table/task/{1}", this.ServiceNowUrl, id);
        //    CallRestMethodCancel("PUT", requestUrl, ServiceNowUsername, ServiceNowPassword, ProxyHost, ProxyPort, ProxyUsername, ProxyPassword, ProxyDomain);
        //}


        public Chamado CriaChamado(string atendente, string artigo, string grupo, string usuario, string descricao_resumida, string descricao)
        {
            Chamado envio = new Chamado();
            envio.state = this.ServiceNowStatusNovo;
            envio.incident_state = this.ServiceNowStatusNovo;
            envio.short_description = descricao_resumida;
            envio.description = descricao;
            envio.caller_id = usuario;
            envio.assignment_group = grupo;
            envio.u_ci_class_name = this.ServiceNowClasse;
            envio.u_serial_number = atendente;
            envio.u_knowledge_id = artigo;

            string requestUrl = string.Format("{0}/api/now/table/incident", this.ServiceNowUrl);
            Chamado retorno = CallRestMethod("POST", requestUrl, ServiceNowUsername, ServiceNowPassword, ProxyHost, ProxyPort, ProxyUsername, ProxyPassword, ProxyDomain, envio);

            return retorno;
        }

        public Chamado ResolveChamado(string id, string grupo, string atendente, DateTime resolucao, string comentario)
        {
            Chamado envio = new Chamado();
            envio.state = this.ServiceNowStatusResolvido;
            envio.incident_state = this.ServiceNowStatusResolvido;
            envio.assignment_group = grupo;
            envio.assigned_to = atendente;
            //envio.resolved_by = atendente;
            envio.resolved_at = resolucao.ToString("MM-dd-yyyy HH:mm:ss");
            envio.comments = comentario;
            envio.work_notes = comentario;

            string requestUrl = string.Format("{0}/api/now/table/incident/{1}", this.ServiceNowUrl, id);
            Chamado retorno = CallRestMethod("PUT", requestUrl, ServiceNowUsername, ServiceNowPassword, ProxyHost, ProxyPort, ProxyUsername, ProxyPassword, ProxyDomain, envio);

            return retorno;
        }

        public Artigo GetArtigo(string artigo)
        {
            Artigo retorno = new Artigo();

            string requestUrl = string.Format("https://walmartglobal.service-now.com/api/now/table/kb_knowledge?GET&sysparm_display_value=true&sysparm_fields=sys_id,number,short_description,u_issue&sysparm_query=number={0}", artigo);

            string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);

            if (!string.IsNullOrEmpty(json))
            {
                DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                DataRow registro = dados.Tables["result"].Rows[0];
                retorno.sys_id = registro["sys_id"].ToString();
                retorno.number = registro["number"].ToString();
                retorno.short_description = registro["short_description"].ToString();
                retorno.u_issue = registro["u_issue"].ToString();
                retorno.u_issue = retorno.u_issue.Replace("<div>", string.Empty).Replace("</div>", Environment.NewLine);
                retorno.u_issue = retorno.u_issue.Replace("<p>", string.Empty).Replace("</p>", Environment.NewLine);
                retorno.u_issue = retorno.u_issue.Replace("<br>", Environment.NewLine).Replace("<br/>", Environment.NewLine);
            }

            return retorno;
        }

        public string GetUserId(string login)
        {
            string id = string.Empty;

            string requestUrl = string.Format("https://walmartglobal.service-now.com/api/now/table/sys_user?GET&sysparm_display_value=true&sysparm_fields=sys_id&sysparm_query=user_name={0}", login);

            string json = CallRestMethod(requestUrl, this.ServiceNowUsername, this.ServiceNowPassword, this.ProxyHost, this.ProxyPort, this.ProxyUsername, this.ProxyPassword, this.ProxyDomain);

            if (!string.IsNullOrEmpty(json))
            {
                DataSet dados = JsonConvert.DeserializeObject<DataSet>(json);
                DataRow registro = dados.Tables["result"].Rows[0];
                id = registro["sys_id"].ToString();
            }

            return id;
        }

        public static string CallRestMethod(string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        {
            string source = string.Empty;
            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.ContentType = "application/json";
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                using (StreamReader reader = new StreamReader(webrequest.GetResponse().GetResponseStream()))
                {
                    source = reader.ReadToEnd();
                }
            }
            catch (Exception)
            {
                source = string.Empty;
            }

            return source;
        }

        public static Chamado CallRestMethod(string metodo, string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain, Chamado chamado)
        {
            Chamado retorno = new Chamado();

            try
            {
                HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
                webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
                webrequest.Accept = "application/json";
                webrequest.ContentType = "application/json";
                webrequest.Method = metodo;
                webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
                webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

                dynamic o = new ExpandoObject();

                if (!string.IsNullOrEmpty(chamado.short_description))
                    o.short_description = chamado.short_description;

                if (!string.IsNullOrEmpty(chamado.description))
                    o.description = chamado.description;

                if (!string.IsNullOrEmpty(chamado.caller_id))
                    o.caller_id = chamado.caller_id;

                if (!string.IsNullOrEmpty(chamado.assignment_group))
                    o.assignment_group = chamado.assignment_group;

                if (!string.IsNullOrEmpty(chamado.u_ci_class_name))
                    o.u_ci_class_name = chamado.u_ci_class_name;

                if (!string.IsNullOrEmpty(chamado.u_serial_number))
                    o.u_serial_number = chamado.u_serial_number;

                if (!string.IsNullOrEmpty(chamado.u_knowledge_id))
                    o.u_knowledge_id = chamado.u_knowledge_id;

                if (!string.IsNullOrEmpty(chamado.work_notes))
                    o.work_notes = chamado.work_notes;

                if (!string.IsNullOrEmpty(chamado.comments))
                    o.comments = chamado.comments;

                if (!string.IsNullOrEmpty(chamado.assigned_to))
                    o.assigned_to = chamado.assigned_to;

                if (!string.IsNullOrEmpty(chamado.state))
                    o.state = chamado.state;

                if (!string.IsNullOrEmpty(chamado.incident_state))
                    o.incident_state = chamado.incident_state;

                if (!string.IsNullOrEmpty(chamado.resolved_by))
                    o.resolved_by = chamado.resolved_by;

                if (!string.IsNullOrEmpty(chamado.resolved_at))
                    o.resolved_at = chamado.resolved_at;

                using (var streamWriter = new StreamWriter(webrequest.GetRequestStream()))
                {
                    string json = JsonConvert.SerializeObject(o);
                    streamWriter.Write(json);
                }

                using (HttpWebResponse response = webrequest.GetResponse() as HttpWebResponse)
                {
                    var res = new StreamReader(response.GetResponseStream()).ReadToEnd();

                    JObject joResponse = JObject.Parse(res.ToString());
                    JObject ojObject = (JObject)joResponse["result"];

                    retorno.sys_id = ((JValue)ojObject.SelectToken("sys_id")).Value.ToString();
                    retorno.number = ((JValue)ojObject.SelectToken("number")).Value.ToString();
                    //retorno.short_description = ((JValue)ojObject.SelectToken("short_description")).Value.ToString();
                    //retorno.description = ((JValue)ojObject.SelectToken("description")).Value.ToString();
                    //retorno.caller_id = ((JValue)ojObject.SelectToken("caller_id.value")).Value.ToString();
                    //retorno.assignment_group = ((JValue)ojObject.SelectToken("assignment_group.value")).Value.ToString();
                    //retorno.u_ci_class_name = ((JValue)ojObject.SelectToken("u_ci_class_name")).Value.ToString();
                    //retorno.u_serial_number = ((JValue)ojObject.SelectToken("u_serial_number")).Value.ToString();
                    //retorno.u_knowledge_id = ((JValue)ojObject.SelectToken("u_knowledge_id.value")).Value.ToString();
                    //retorno.work_notes = ((JValue)ojObject.SelectToken("work_notes")).Value.ToString();
                    //retorno.comments = ((JValue)ojObject.SelectToken("comments")).Value.ToString();
                    //retorno.assigned_to = ((JValue)ojObject.SelectToken("assigned_to.value")).Value.ToString();
                    //retorno.incident_state = ((JValue)ojObject.SelectToken("incident_state")).Value.ToString();
                    //retorno.resolved_by = ((JValue)ojObject.SelectToken("resolved_by.value")).Value.ToString();
                    //retorno.resolved_at = ((JValue)ojObject.SelectToken("resolved_at")).Value.ToString();
                }

            }
            catch (WebException ex)
            {
                retorno.erro = ((HttpWebResponse)ex.Response).StatusDescription;
            }
            catch (Exception e)
            {
                retorno.erro = e.Message;
            }

            return retorno;
        }


        //public static void CallRestMethodCancel(string metodo, string ServiceNowUrl, string ServiceNowUsername, string ServiceNowPassword, string ProxyHost, int ProxyPort, string ProxyUsername, string ProxyPassword, string ProxyDomain)
        //{
        //    string erro = string.Empty;

        //    try
        //    {
        //        HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ServiceNowUrl);
        //        webrequest.Proxy = new WebProxy(ProxyHost, ProxyPort);
        //        webrequest.Accept = "application/json";
        //        webrequest.ContentType = "application/json";
        //        webrequest.Method = metodo;
        //        webrequest.Proxy.Credentials = new NetworkCredential(ProxyUsername, ProxyPassword, ProxyDomain);
        //        webrequest.Credentials = new NetworkCredential(ServiceNowUsername, ServiceNowPassword);

        //        dynamic o = new ExpandoObject();
        //        o.state = "4";

        //        using (var streamWriter = new StreamWriter(webrequest.GetRequestStream()))
        //        {
        //            string json = JsonConvert.SerializeObject(o);
        //            streamWriter.Write(json);
        //        }

        //        using (HttpWebResponse response = webrequest.GetResponse() as HttpWebResponse)
        //        {
        //            var res = new StreamReader(response.GetResponseStream()).ReadToEnd();

        //            JObject joResponse = JObject.Parse(res.ToString());
        //            JObject ojObject = (JObject)joResponse["result"];

        //        }

        //    }
        //    catch (WebException ex)
        //    {
        //        erro = ((HttpWebResponse)ex.Response).StatusDescription;
        //    }
        //    catch (Exception e)
        //    {
        //        erro = e.Message;
        //    }
        //}



    }

    public class Artigo
    {
        public string sys_id { get; set; }
        public string number { get; set; }
        public string short_description { get; set; }
        public string u_issue { get; set; }
    }

    public class Chamado
    {
        public string sys_id { get; set; }
        public string number { get; set; }
        public string short_description { get; set; }
        public string description { get; set; }
        public string caller_id { get; set; }
        public string assignment_group { get; set; }
        public string u_ci_class_name { get; set; }
        public string u_serial_number { get; set; }
        public string u_knowledge_id { get; set; }
        public string work_notes { get; set; }
        public string comments { get; set; }
        public string assigned_to { get; set; }
        public string state { get; set; }
        public string incident_state { get; set; }
        public string resolved_by { get; set; }
        public string resolved_at { get; set; }

        public string erro { get; set; }
    }

}
